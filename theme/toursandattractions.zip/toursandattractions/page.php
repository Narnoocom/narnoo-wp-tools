<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package toursandattractions
 */

get_header();
$thumbnail = get_the_post_thumbnail_url(NULL, 'page-header');
?>
<!-- breadcrumb start -->
    <section class="order-food-section  pt-0">
        <img src="<?php echo $thumbnail;?>" class="bg-img img-fluid blur-up lazyload" alt="">
        <div class="order-food">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <div class="book-table section-b-space p-0 single-table">
                            <h3>Find more tours and attractions</h3>
                            <div class="table-form">
                                <form>
                                    <div class="row w-100">
                                        <div class="form-group col-md-9">
                                            <input type="text" placeholder="enter your location" class="form-control">
                                        </div>
                                        <div class="search col-md-3">
                                            <a href="#" class="btn btn-rounded color1">Search</a>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- breadcrumb end -->
	<main id="primary" class="site-main">
	
		<?php
		while ( have_posts() ) :
			the_post();

			get_template_part( 'template-parts/content', 'page' );

			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;

		endwhile; // End of the loop.
		?>

	</main><!-- #main -->

<?php
//get_sidebar();
get_footer();
