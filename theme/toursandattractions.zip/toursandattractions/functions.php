<?php
/**
 * toursandattractions functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package toursandattractions
 */
global $narnoo_db_version;
$narnoo_db_version = '1.0';

if( ! class_exists( 'WP_List_Table' ) ) {
	require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

if ( ! defined( '_S_VERSION' ) ) {
	// Replace the version number of the theme on each release.
	define( '_S_VERSION', '1.0.0' );
}

if ( ! function_exists( 'toursandattractions_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function toursandattractions_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on toursandattractions, use a find and replace
		 * to change 'toursandattractions' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'toursandattractions', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus(
			array(
				'menu-1' => esc_html__( 'Primary', 'toursandattractions' ),
			)
		);

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support(
			'html5',
			array(
				'search-form',
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
				'style',
				'script',
			)
		);

		// Set up the WordPress core custom background feature.
		add_theme_support(
			'custom-background',
			apply_filters(
				'toursandattractions_custom_background_args',
				array(
					'default-color' => 'ffffff',
					'default-image' => '',
				)
			)
		);

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support(
			'custom-logo',
			array(
				'height'      => 250,
				'width'       => 250,
				'flex-width'  => true,
				'flex-height' => true,
			)
		);
		//Add category theme image size
		add_image_size( 'category-img', 435, 300, array('center' , 'center') );
		add_image_size( 'theme-img-large', 2455, 740, array('center' , 'center') );
		add_image_size( 'theme-img-medium', 455, 740, array('center' , 'center') );
		add_image_size( 'video-img-medium', 670, 460, array('center' , 'center') );
		add_image_size( 'page-header', 1920, 1280, array('center' , 'center') );

		//add_action( 'admin_menu', 'create_menus', 9 );


	}
endif;
add_action( 'after_setup_theme', 'toursandattractions_setup' );

//Once switched to this theme we will try and create the relevent tables
add_action( 'after_switch_theme', 'narnoo_db_install' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function toursandattractions_content_width() {
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters( 'toursandattractions_content_width', 640 );
}
add_action( 'after_setup_theme', 'toursandattractions_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function toursandattractions_widgets_init() {
	register_sidebar(
		array(
			'name'          => esc_html__( 'Sidebar', 'toursandattractions' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Add widgets here.', 'toursandattractions' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
}
add_action( 'widgets_init', 'toursandattractions_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function toursandattractions_scripts() {
	wp_enqueue_style( 'toursandattractions-style', get_stylesheet_uri(), array(), _S_VERSION );
	wp_style_add_data( 'toursandattractions-style', 'rtl', 'replace' );

	wp_enqueue_script( 'toursandattractions-navigation', get_template_directory_uri() . '/js/navigation.js', array(), _S_VERSION, true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'toursandattractions_scripts' );


/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}

/**
 * Script to manage the themes css main file.
 */
require get_template_directory() . '/inc/stylesheet-manager.php';

/**
 * Script to manage the themes main JS file.
 */
require get_template_directory() . '/inc/script-manager.php';

/**
 * Script to the custom menu.
 */
require get_template_directory() . '/inc/custom_menu_walker.php';


/**
 * Script to manage the footer widgets.
 */
require get_template_directory() . '/inc/footer_manager.php';

/**
 * Script to manage the custom post types.
 */
require get_template_directory() . '/inc/custom_postypes.php';

/**
 * Script to manage the custom meta boxes.
 */
require get_template_directory() . '/inc/custom_meta_box.php';
/**
 * Script to manage the custom pagination.
 */
//require get_template_directory() . '/inc/custom_pagination.php';


/**
 * 
 */
require get_template_directory() . '/inc/ajax_customer_booking_hook.php';

/**
 *
 */
require get_template_directory() . '/inc/ajax_search_hook.php';

/**
 * 
 */
require get_template_directory() . '/inc/ajax_subscribe_hook.php';

/**
 * Script to manage the custom meta boxes.
 */
require get_template_directory() . '/inc/membership-pages.php';
require get_template_directory() . '/inc/subscribers-table.php';
require get_template_directory() . '/inc/plugin-manager.php';

 
function remove_admin_bar() {
	if (!current_user_can('administrator') && !is_admin()) {
	  show_admin_bar(false);
	}
}
add_action('after_setup_theme', 'remove_admin_bar');

/*
DB functions
*/

//CHECK THE CREATE STATEMENT
function narnoo_db_install() {
	global $wpdb;
	global $narnoo_db_version;

	$table_name = $wpdb->prefix . 'product_wishlist';
	
	$charset_collate = $wpdb->get_charset_collate();

	$sql = "CREATE TABLE IF NOT EXISTS `noo_product_wishlist` (
	  `id` int(10) NOT NULL,
	  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	  `user` int(10) NOT NULL,
	  `post` int(10) NOT NULL
	) $charset_collate;";

	$sql_table_2 = "CREATE TABLE IF NOT EXISTS `noo_email_list` (
	  `id` int(11) NOT NULL,
	  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	  `email` varchar(225) NOT NULL
	) $charset_collate;";

	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta( $sql );

	dbDelta( $sql_table_2 );

	add_option( 'narnoo_db_version', $narnoo_db_version );
}

function checkVcEditorContent( $content ){

	$vc_string 	= '[vc_'; // find any part of the string.
	$pos 		= strpos($content, $vc_string);
	if($pos === false){
		return false;
	}else{
		return true;
	}

}

