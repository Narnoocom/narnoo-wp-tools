<?php
/**
 * The template for the home page.
 *
 * Template Name: Login Page
 *
 * @package toursandattractions
 */
if($_POST) 
{  
   
   //We shall SQL escape all inputs  
    $username = $_REQUEST['username'];  
    $password = $_REQUEST['password'];  
    $remember = (!empty( $_REQUEST['rememberme'] ) ) ? $_REQUEST['rememberme'] : false;  
   
    if($remember) $remember = "true";  
    else $remember = "false";  
   
    $login_data = array();  
    $login_data['user_login'] = $username;  
    $login_data['user_password'] = $password;  
    $login_data['remember'] = $remember;  
   
    $user_verify = wp_signon( $login_data, false );   
    

    if ( is_wp_error($user_verify) )
    {  
        echo "<script type='text/javascript'>window.location.href='". home_url()."/login-page/?login=false'</script>";  
     } else
    {   
         $userID = $user_verify->ID;
         wp_set_current_user( $userID );
         echo "<script type='text/javascript'>window.location.href='". home_url('/') ."/profile/'</script>";  
         exit();  
     }  
   
} else 
{  
   
    // No login details entered - you should probably add some more user feedback here, but this does the bare minimum  
   
    //echo "Invalid login details";  
   
} 

get_header();
$thumbnail = get_the_post_thumbnail_url(NULL, 'page-header');
?>

<!-- breadcrumb start -->
    <section class="breadcrumb-section effect-cls pt-0">
        <img src="<?php echo $thumbnail;?>" class="bg-img img-fluid blur-up lazyload" alt="">
        <div class="breadcrumb-content pt-0">
            <div>
                <h2><?php echo get_the_title(); ?></h2>
                <nav aria-label="breadcrumb" class="theme-breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo get_the_title(); ?></li>
                    </ol>
                </nav>
            </div>
        </div>
    </section>
    <!-- breadcrumb end -->

	<main id="primary" class="site-main">

		<?php
		while ( have_posts() ) :
			the_post();

			get_template_part( 'template-parts/membership', 'login' );

		endwhile; // End of the loop.
		?>

	</main><!-- #main -->

<?php
get_footer();
?>
