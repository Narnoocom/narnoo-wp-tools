<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package toursandattractions
 */
/*
* Load relevant style scripts and stylesheets for this page. [start]
*/


get_header();
$header_img     = get_theme_mod( 'destination_header_archive_url' ); 
$args = array(
    'post_type'     => array( 'destinations'),
    'post_status'   => array('publish'),
    'post_parent'   => 0,
    'orderby'       => 'menu_order', 
    'order'         => 'ASC',
    
);
$m_query = new WP_Query( $args ); 
?>
<!-- breadcrumb start -->
    <section class="order-food-section  pt-0">
        <img src="<?php echo $header_img;?>" class="bg-img img-fluid blur-up lazyload" alt="">
        <div class="order-food">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <div class="book-table section-b-space p-0 single-table">
                            <h3>Find more destinations here</h3>
                            <div class="table-form">
                                <form>
                                    <div class="row w-100">
                                <div class="form-group col p-0">
                                    <div class="suggestion_box">
                                        <div class="form-group">
                                            <input type="text" class="form-control open-select" placeholder="Select a Destination">
                                            <div class="selector-box">
                                                <h6 class="title">Our Destinations</h6>
                                                <ul>
                                                <?php  if( $m_query->have_posts() ){ while ( $m_query->have_posts() ) : $m_query->the_post(); ?>

                                                    <li>
                                                        <a href="<?php echo get_the_permalink(); ?>">
                                                            <h5><?php echo get_the_title(); ?></h5>
                                                        </a>
                                                    </li>

                                                <?php   endwhile;  } wp_reset_query(); ?>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- breadcrumb end -->
<main id="primary" class="site-main">

	<?php
		get_template_part( 'template-parts/archive', 'destination' );
	?>

</main><!-- #main -->

<?php
get_footer();
?>
