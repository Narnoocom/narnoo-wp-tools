jQuery(document).ready( function() {

   jQuery(".noo_product_search").click( function(e) {
      e.preventDefault(); 
      filter   = jQuery(this).attr("data-filter");
      loc      = jQuery(this).attr("data-loc");
      type      = jQuery(this).attr("data-type");
      nonce    = jQuery(this).attr("data-nonce");
      jQuery.ajax({
         type : "post",
         dataType : "json",
         url : myAjax.ajaxurl,
         data : {action: "noo_product_search", filter : filter, loc : loc, type : type, nonce: nonce},
         success: function(response) {
            if(response.type == "success") {
               jQuery("#productSearch").html(response.output);
               reload_image_lazyLoad(); //load the image data
            }
            else {
               toast_annoncement_negative("Your search could not be performed");
            }
         }
      });
   });


   jQuery(".noo_product_category_search").click( function(e) {
      e.preventDefault(); 
      filter   = jQuery(this).attr("data-filter");
      noo      = jQuery(this).attr("data-narnoo");
      nonce    = jQuery(this).attr("data-nonce");
      jQuery.ajax({
         type : "post",
         dataType : "json",
         url : myAjax.ajaxurl,
         data : {action: "noo_product_category_search", filter : filter, noo : noo, nonce: nonce},
         success: function(response) {
            if(response.type == "success") {
               jQuery("#productSearch").html(response.output);
               reload_image_lazyLoad(); //load the image data
            }
            else {
               toast_annoncement_negative("Your search could not be performed");
            }
         }
      });
   });

   jQuery(".cls-remove-like").click( function(e) {
      e.preventDefault(); 
      product   = jQuery(this).attr("data-product");
      nonce     = jQuery(this).attr("data-nonce");
      jQuery.ajax({
         type : "post",
         dataType : "json",
         url : myAjax.ajaxurl,
         data : {action: "noo_product_wishlist_remove", product : product, nonce: nonce},
         success: function(response) {
            if(response.type == "success") {
               jQuery(".pro-item-"+product).fadeOut();
            }
            else {
               toast_annoncement_negative("Your product could not be removed from your wishlist");
            }
         }
      });
   });


    jQuery(".product-wishlist-cls").click( function(e) {
      e.preventDefault(); 
      product   = jQuery(this).attr("data-product");
      nonce    = jQuery(this).attr("data-nonce");
      jQuery.ajax({
         type : "post",
         dataType : "json",
         url : myAjax.ajaxurl,
         data : {action: "noo_product_wishlist", product : product, nonce: nonce},
         success: function(response) {
            if(response.type == "success") {
               //jQuery("#productSearch").html(response.output);
               toast_annoncement_positive(response.output);
            }
            else {
               toast_annoncement_negative("Your product could not be added to your wishlist");
            }
         }
      });
   });

   
   //function from AJAX
    function reload_image_lazyLoad() {
        jQuery(".bg-img").parent().addClass('bg-size');
        jQuery(".bg-img.blur-up" ).parent().addClass('blur-up lazyload');
        jQuery('.bg-img').each(function () {

            var el = jQuery(this),
                src = el.attr('src'),
                parent = el.parent();


            parent.css({
                'background-image': 'url(' + src + ')',
                'background-size': 'cover',
                'background-position': 'center',
                'background-repeat': 'no-repeat',
                'display': 'block'
            });

            el.hide();
        });
    }

    //function toast
    function toast_annoncement_positive(data) {
      jQuery.toast({
       text : data,
       bgColor : '#0000FF',
       textColor : '#fff',
       position: 'top-right'

      });
    }

    function toast_annoncement_negative(data) {
      jQuery.toast({
       text : data,
       bgColor : '#FF0000',
       textColor : '#fff',
       position: 'top-right'

      });
    }


   
});