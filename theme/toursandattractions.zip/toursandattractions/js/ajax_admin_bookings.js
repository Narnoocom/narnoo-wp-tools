jQuery(document).ready( function() {

   jQuery("#noo_bookings_load").click( function(e) {
      e.preventDefault(); 
      nonce    = jQuery(this).attr("data-nonce");
      jQuery.ajax({
         type : "post",
         dataType : "json",
         url : myAjax.ajaxurl,
         data : {action: "noo_booking_list", nonce: nonce},
         success: function(response) {
            if(response.type == "success") {
               jQuery("#customer-booking-details").html(response.output);
            }
            else {
               alert("Your action could not be performed at this time");
            }
         }
      });
   });


   jQuery("#customer-booking-details").on("click", '.cls-booking-details-btn' ,function(e) {
      e.preventDefault(); 
      booking     = jQuery(this).attr("data-order-id");
      nonce       = jQuery(this).attr("data-nonce");
      jQuery.ajax({
         type : "post",
         dataType : "json",
         url : myAjax.ajaxurl,
         data : {action: "noo_booking_detail", booking:booking, nonce: nonce},
         success: function(response) {
            if(response.type == "success") {
               jQuery("#customer-booking-details").html(response.output);
            }
            else {
               alert("Your action could not be performed at this time");
            }
         }
      });
   
   });


   
});