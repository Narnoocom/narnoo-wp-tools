jQuery(document).ready( function() {

   jQuery("#noo_email_subscription").click( function(e) {
      e.preventDefault(); 
      email   = jQuery("#emailAddress").val();
      nonce    = jQuery(this).attr("data-nonce");
      jQuery.ajax({
         type : "post",
         dataType : "json",
         url : myAjax.ajaxurl,
         data : {action: "noo_email_subscribe", email : email,nonce: nonce},
         success: function(response) {
            if(response.type == "success") {
               toast_annoncement_positive(response.output);
               jQuery("#emailAddress").val("");
            }
            else {
               toast_annoncement_negative(response.output);
            }
         }
      });
   });



   jQuery("#subscriber-list-dl").click( function(e) {
      e.preventDefault(); 
      nonce    = jQuery(this).attr("data-nonce");
      jQuery.ajax({
         type : "post",
         dataType : "json",
         url : myAjax.ajaxurl,
         data : {action: "noo_email_subscribe_dl", nonce: nonce},
         success: function(response) {
            if(response.type == "success") {
               alert(response.output);
            }
            else {
               alert(response.output);
            }
         }
      });
   });


    //function toast
    function toast_annoncement_positive(data) {
      jQuery.toast({
       text : data,
       bgColor : '#0000FF',
       textColor : '#fff',
       position: 'top-right'

      });
    }

    function toast_annoncement_negative(data) {
      jQuery.toast({
       text : data,
       bgColor : '#FF0000',
       textColor : '#fff',
       position: 'top-right'

      });
    }


   
});