<?php 
/**
* Theme file for our single Narnoo product display
*/

/*
* Load relevant style scripts and stylesheets for this page. [start]
*/
function noo_loadZoomScripts(){

    wp_register_script( 'noo-email-subscription', get_template_directory_uri().'/js/ajax_email_subscription.js', 'jquery', NULL, TRUE );
    wp_localize_script( 'noo-email-subscription', 'myAjax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));  

    wp_enqueue_script("jquery");
    wp_enqueue_script( 'magnify', get_template_directory_uri().'/assets/js/jquery.magnific-popup.js' ,  'jquery' , NULL , TRUE);
    wp_enqueue_script( 'zoom', get_template_directory_uri().'/assets/js/zoom-gallery.js' , 'jquery' , NULL , TRUE );
    wp_enqueue_script( 'wow', get_template_directory_uri().'/assets/js/wow.min.js' ,  'jquery' , NULL , TRUE);
    wp_enqueue_script( 'date-time', get_template_directory_uri().'/assets/js/date-picker.js' ,  array('jquery','bootstrap') , NULL , TRUE);
    wp_enqueue_script( 'noo-email-subscription' );
    
}
add_action( 'wp_enqueue_scripts', 'noo_loadZoomScripts' );
function noo_loadMagnifyStyles(){
    wp_enqueue_style( 'magnify-pop', get_template_directory_uri().'/assets/css/magnific-popup.css' ,  'bootstrap');
    wp_enqueue_style( 'date-time', get_template_directory_uri().'/assets/css/datepicker.min.css' ,  'bootstrap');
}
add_action( 'wp_enqueue_scripts', 'noo_loadMagnifyStyles' );
/*
* Load relevant style scripts and stylesheets for this page. [end]
*/

//Need to resolve the date picker object
$date_script = '<script type="text/javascript">';
$date_script .= "
jQuery( document ).ready(function () {
    jQuery('#datepicker').datepicker({
                uiLibrary: 'bootstrap4'
    });
});
";
$date_script .= '</script>';
//add_action( 'wp_footer', function() use( $date_script ){
  //      echo $date_script;
//});

$subNonce          = wp_create_nonce("noo_email_subscribe_nonce");
$subLink           = admin_url('admin-ajax.php?action=noo_email_subscribe&nonce='.$subNonce);

get_header(); 


global $post;


while ( have_posts() ) : the_post();

$parent_post        = $post->ID;

//Get the stored custom meta data for this product
$category           = get_post_meta($post->ID, 'narnoo_listing_category',    true);
$subcategory        = get_post_meta($post->ID, 'narnoo_listing_subcategory',    true);
$productId          = get_post_meta($post->ID, 'narnoo_product_id',       true); //done
$narnooId           = get_post_meta($post->ID, 'narnoo_operator_id',       true); //done
$minPrice           = get_post_meta($post->ID, 'product_min_price',       true); //done
$bookingLink        = get_post_meta($post->ID, 'product_booking_link',    true); //done
$gallery            = json_decode( get_post_meta($post->ID, 'narnoo_product_gallery',  true) );
$userGallery        = get_post_meta($post->ID, 'narnoo_product_gallery_list',  true); 

$video              = get_post_meta($post->ID, 'narnoo_product_video',    true);
$print              = get_post_meta($post->ID, 'narnoo_product_print',    true);

$duration           = get_post_meta($post->ID, 'narnoo_product_duration',    true); //done
$startTime          = get_post_meta($post->ID, 'narnoo_product_start_time',  true);
$endTime            = get_post_meta($post->ID, 'narnoo_product_end_time',    true);
$transport          = get_post_meta($post->ID, 'narnoo_product_transport',   true); //done
$purchase           = get_post_meta($post->ID, 'narnoo_product_purchase',    true); //done
$health             = get_post_meta($post->ID, 'narnoo_product_health',      true); //done
$packing            = get_post_meta($post->ID, 'narnoo_product_packing',     true); //done
$children           = get_post_meta($post->ID, 'narnoo_product_children',    true); //done
$addition           = get_post_meta($post->ID, 'narnoo_product_additional',  true); //done
$itinerary          = get_post_meta($post->ID, 'product_itinerary',          true); //done
$pickTime           = get_post_meta($post->ID, 'narnoo_product_pick_time',    true); //done
$terms              = get_post_meta($post->ID, 'narnoo_product_terms',          true); //done

//Product Reviews
$reviews              = get_post_meta($post->ID, 'noo_review_product_repeat_group',          true); //done

//Get Widget details
$widgetOperatorId = get_post_meta($post->ID,'noo_widget_operator',    true);
$widgetBookingId  = get_post_meta($post->ID,'noo_widget_product',    true);


?>
 <!-- breadcrumb start -->
    <section class="home_section p-0">
        <div>
            <div class="home home-60">
                <img src="<?php echo the_post_thumbnail_url(array(1800,1800)) ?>" class="img-fluid blur-up lazyload bg-img" alt="">
                <div class="container">
                    <div class="row">
                        <div class="col-md-8 offset-md-2">
                            <div class="home-content pt-0 mix-layout mrg-cls">
                                <div>
                                    <h1><?php the_title(); ?></h1>
                                    <?php if( !empty($minPrice) ) { ?>
                                    <ul class="package-detail">
                                        <li><i class="far fa-calendar-alt"></i>From Price: <?php echo "$".$minPrice; ?>*</li>
                                    </ul>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- breadcrumb end -->   
 <!-- section start -->
    <section class="single-section small-section bg-inner">
        <div class="container">
            <div class="row">
                <div class="col-xl-9 col-lg-8">
                    <div class="description-section tab-section">
                        <div class="menu-top menu-up">
                            <ul class="nav nav-tabs" id="top-tab" role="tablist">
                                <li class="nav-item"><a data-toggle="tab" class="nav-link active" href="#highlight">highlight</a></li>
                                <?php if(!empty($itinerary)) { ?><li class="nav-item"><a data-toggle="tab" class="nav-link" href="#itinerary">itinerary</a></li><?php } ?>
                                <?php if( !empty($duration) || !empty($transport)  || !empty($purchase)  || !empty($health)  || !empty($packing)  || !empty($children) || !empty($additional)  ) { ?><li class="nav-item"><a data-toggle="tab" class="nav-link" href="#details">details</a></li><?php } ?>
                                <?php if( !empty($gallery) || !empty($userGallery)  ) { ?><li class="nav-item"><a data-toggle="tab" class="nav-link" href="#gallery">gallery</a></li><?php } ?>
                               <!-- <li class="nav-item"><a data-toggle="tab" class="nav-link" href="#location">location</a></li> -->
                                <?php if(!empty($reviews)) { ?><li class="nav-item"><a data-toggle="tab" class="nav-link" href="#review">reviews</a></li><?php } ?>
                                <?php if( !empty($terms) ) { ?><li class="nav-item"><a data-toggle="tab" class="nav-link" href="#terms">Terms & Conditions</a></li><?php } ?>
                                
                            </ul>
                        </div>
                        <!-- Booking Widget -->
                        <?php 
                        if(!empty($widgetOperatorId) && !empty($widgetBookingId)){   
                        ?>
                        <div>
                            <?php echo do_shortcode("[narnoo_booking operator_id=".$widgetOperatorId." booking_id=".$widgetBookingId." datepicker_type='single' button_variant='red' button_fill='full' show_pricing='true' ]"); ?>
                        </div>
                        <?php 
                        } 
                        ?>
                        <div class="description-details tab-content" id="top-tabContent">
                            <div class="menu-part about tab-pane fade show active" id="highlight">
                                <div class="about-sec">
                                <?php 
                                the_content();
                                ?>
                                </div>   
                            </div>
                            <?php if(!empty($itinerary)) { ?>
                            <div class="menu-part about accordion tab-pane fade " id="itinerary">
                                <div class="about-sec">
                                <p>
                                <?php 
                                echo $itinerary;
                                ?>
                                </p>
                                </div>
                            </div>
                            <?php } ?>
                            <?php if( !empty($gallery) || !empty($userGallery)  ) { ?>
                            <div class="menu-part tab-pane fade" id="gallery">
                                <div class="container-fluid p-0 ratio3_2">
                                    <div class="row  zoom-gallery">
                                    <?php  foreach ($gallery->images as $img) { ?>
                                            
                                        <div class="col-lg-4 col-sm-6">
                                            <div class="overlay">
                                                <a href="<?php echo $img->xlargeImage; ?>">
                                                    <div class="overlay-background">
                                                        <i class="fa fa-plus" aria-hidden="true"></i>
                                                    </div>
                                                    <img src="<?php echo $img->image400; ?>" alt=""
                                                        class="img-fluid blur-up lazyload bg-img">
                                                </a>
                                            </div>
                                        </div>
                                     <?php   }  ?>
                                    </div>
                                </div>
                            </div>
                            <?php } ?>
                            <?php if( !empty($duration) || !empty($transport)  || !empty($purchase)  || !empty($health)  || !empty($packing)  || !empty($children) || !empty($additional)  ) { ?>
                            <div class="menu-part tab-pane fade" id="details">
                                <div id="accordion" class="accordion-plan">
                                    <?php if(!empty($transport)) { ?>
                                    <!-- Item -->
                                    <div class="card">
                                        <div class="card-header" id="headingOne">
                                            <h5 class="mb-0">
                                                <button class="btn btn-link" data-toggle="collapse"
                                                    data-target="#collapseOne" aria-expanded="true"
                                                    aria-controls="collapseOne">
                                                    Directions
                                                </button>
                                            </h5>
                                        </div>
                                        <div id="collapseOne" class="collapse show" aria-labelledby="headingOne"
                                            data-parent="#accordion">
                                            <div class="card-body">
                                                <?php 
                                                echo $transport;
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Item/ -->
                                    <?php } ?>
                                    <?php if(!empty($packing)) { ?>
                                    <div class="card">
                                        <div class="card-header" id="headingThree">
                                            <h5 class="mb-0">
                                                <button class="btn btn-link collapsed" data-toggle="collapse"
                                                    data-target="#collapseThree" aria-expanded="false"
                                                    aria-controls="collapseThree">
                                                    What to bring
                                                </button>
                                            </h5>
                                        </div>
                                        <div id="collapseThree" class="collapse" aria-labelledby="headingThree"
                                            data-parent="#accordion">
                                            <div class="card-body">
                                                <?php 
                                                echo $packing;
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    <?php if(!empty($health)) { ?>
                                    <div class="card">
                                        <div class="card-header" id="headingTwo">
                                            <h5 class="mb-0">
                                                <button class="btn btn-link collapsed" data-toggle="collapse"
                                                    data-target="#collapseTwo" aria-expanded="false"
                                                    aria-controls="collapseTwo">
                                                    Fitness level
                                                </button>
                                            </h5>
                                        </div>
                                        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo"
                                            data-parent="#accordion">
                                            <div class="card-body">
                                                <?php 
                                                echo $health;
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    <?php if(!empty($children)) { ?>
                                    <div class="card">
                                        <div class="card-header" id="headingFour">
                                            <h5 class="mb-0">
                                                <button class="btn btn-link" data-toggle="collapse"
                                                    data-target="#collapseFour" aria-expanded="true"
                                                    aria-controls="collapseFour">
                                                    Children Information
                                                </button>
                                            </h5>
                                        </div>
                                        <div id="collapseFour" class="collapse" aria-labelledby="headingFour"
                                            data-parent="#accordion">
                                            <div class="card-body">
                                                <?php 
                                                echo $children;
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    <?php if(!empty($addition)) { ?>
                                    <div class="card">
                                        <div class="card-header" id="headingFive">
                                            <h5 class="mb-0">
                                                <button class="btn btn-link collapsed" data-toggle="collapse"
                                                    data-target="#collapseFive" aria-expanded="false"
                                                    aria-controls="collapseFive">
                                                    Additional Information
                                                </button>
                                            </h5>
                                        </div>
                                        <div id="collapseFive" class="collapse" aria-labelledby="headingFive"
                                            data-parent="#accordion">
                                            <div class="card-body">
                                                <?php 
                                                echo $addition;
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                    <?php } ?>
                                </div>
                            </div>
                            <?php } ?>
                           <!-- <div class="menu-part tab-pane fade map" id="location">
                                <iframe
                                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d193595.9147718689!2d-74.11976358820196!3d40.69740344169578!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew%20York%2C%20NY%2C%20USA!5e0!3m2!1sen!2sin!4v1568001991098!5m2!1sen!2sin"
                                    style="border:0;" allowfullscreen=""></iframe>
                            </div>-->
                            <?php if(!empty($reviews)) { ?>
                            <div class="menu-part tab-pane fade review" id="review">
                            <?php foreach ( $reviews as $key => $entry ) { ?>
                                <div class="review-box">

                                    <div class="rating">
                                    <?php if(!empty($entry['narnoo__review_rating'])){ $c=1;?>
                                        <?php while ( $c <= intval($entry['narnoo__review_rating'])) { ?>
                                            <i class="fas fa-star"></i>
                                       <?php  $c++; } ?>
                                    <?php } ?>
                                        <span><?php if(!empty($entry['narnoo__review_title'])) { echo esc_html( $entry['narnoo__review_title'] ); } ?></span>
                                    </div>

                                    <h6>by <?php if(!empty($entry['narnoo__review_name'])) { echo esc_html( $entry['narnoo__review_name'] ); } ?>, <?php if(!empty($entry['narnoo__review_date'])) { echo esc_html( $entry['narnoo__review_date'] ); } ?></h6>
                                    <p><?php if(!empty($entry['narnoo__review_description'])) { echo esc_html( $entry['narnoo__review_description'] ); } ?></p>
                                </div>
                                <?php } ?>
                            </div>
                            <?php } ?>
                            <?php if(!empty($terms)) { ?>
                            <div class="menu-part about accordion tab-pane fade " id="terms">
                                <div class="about-sec">
                                <p>
                                <?php 
                                echo $terms;
                                ?>
                                </p>
                                </div>
                            </div>
                            <?php } ?>
                        </div>
                    </div>

                    <?php 

                    $args = array(
                        'post_type'      => array( 'narnoo_product'),
                        'post_status'    => array('publish'),
                        'post__not_in'   => array( $post->ID ),
                        'meta_query'     => array(
                            array(
                                'key'     => 'narnoo_operator_id',
                                'value'   => $narnooId,
                            )
                        ),
                       );
                    $supplier_products = new WP_Query( $args );

                    if( $supplier_products->have_posts() ){


                    ?>
                    <!-- category 2 start -->
                    <section class="category-sec ratio3_2 section-b-space" style="padding-top:0px">
                        <div class="container">
                            <div class="title-1 title-5">
                                <h2>Suppliers's Additional Products</h2>
                            </div>
                            <div class="row">
                                <div class="col">
                                    <div class="slide-3 arrow-classic">
                                        <?php  while ( $supplier_products->have_posts() ) : $supplier_products->the_post(); ?>
                                        <?php 
                                        $thumbnail  = get_the_post_thumbnail_url();
                                        $minPrice   = get_post_meta(get_the_ID(), 'product_min_price',       true);
                                        ?>
                                        <a href="<?php echo get_the_permalink(); ?>">
                                            <div class="category-box wow fadeInUp">
                                                <div class="img-category">
                                                    <div class="side-effect"></div>
                                                    <div>
                                                        <img src="<?php echo $thumbnail; ?>" alt=""
                                                            class="img-fluid blur-up lazyload bg-img">
                                                    </div>
                                                    <div class="top-bar">
                                                        <h5>From $<?php echo $minPrice; ?></h5>
                                                    </div>
                                                   <!-- <div class="like-cls">
                                                        <i class="fas fa-heart"><span class="effect"></span></i>
                                                    </div> -->
                                                </div>
                                                <div class="content-category">
                                                    <div class="top">
                                                        <h3><?php echo get_the_title(); ?></h3>
                                                    </div>
                                                    <p><?php echo wp_trim_words( wp_strip_all_tags( get_the_content() ), 10, '...' ); ?></p>
                                                </div>
                                            </div>
                                        </a>
                                    <?php endwhile; wp_reset_query();?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <!-- category 2 end -->

                    <?php } ?>
                    <div><small><p>*All prices subject to change based on availability and date</p></small></div>
                </div>
                <style type="text/css">
                .narnoo-boxed-widget {
                    background-color: #ffffff !important; 
                }
                </style>
                <div class="col-xl-3 col-lg-4 ">
                    <div class="sticky-cls-top">
                        <?php
                        if(empty($widgetOperatorId) && empty($widgetBookingId)){
                        ?>

                        <div class="single-sidebar">
                            <div class="selection-section">
                                <h4 class="title">Product Enquiry Form</h4>
                                <!-- Form -->
                                    <form>
                                        <div class="book-btn-section border-top-0">
                                            <div class="detail-top">
                                                <input type="text" id="firstName" class="form-control" placeholder="First name">
                                                <input type="email" id="email" class="form-control" placeholder="Enter your email">
                                                <input type="phone" id="phone" class="form-control" placeholder="Phone Number">
                                            </div>
                                            <div class="selector" style="margin-top:10px">
                                                <input placeholder="Travel Date" class="form-control" id="datepicker" name="travelDate" />
                                            </div>
                                            <div class="detail-bottom" style="margin-top:10px">
                                                <textarea id="enqiry" class="form-control"></textarea>
                                            </div>
                                            <a href="#" class="btn btn-rounded btn-sm color1">start my journey</a>
                                        </div>
                                    <form>
                                 <!-- end form -->
                            </div>
                        </div>

                        <?php } ?>

                        <div class="single-sidebar p-0">
                            <div class="newsletter-sec">
                                <div>
                                    <h4 class="title">always first</h4>
                                    <p>Be the first to find out latest tours and special deals.</p>
                                    <form>
                                        <input type="email" class="form-control" placeholder="Enter your email" id="emailAddress">
                                        <div class="button">
                                            <a id="noo_email_subscription" href="<?php echo $subLink; ?>" class="btn btn-solid" data-nonce="<?php echo $subNonce; ?>">be the first</a>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- section end -->


    <!-- book now section start 
    <div class="book-panel">
        <button data-toggle="modal" data-target="#booknowModal" type="button" class="btn bottom-btn theme-color">book
            now</button>
        <button data-toggle="modal" data-target="#enquiryModal" type="button" class="btn bottom-btn">enquiry</button>
    </div>
     book now section end -->

<?php endwhile; ?>

<?php get_footer(); ?>