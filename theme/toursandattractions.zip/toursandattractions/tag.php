<?php
/**
 * The template for the home page.
 *
 * Template Name: Main Blog List
 *
 * @package toursandattractions
 */
global $post;

get_header();
$header_img     = get_theme_mod( 'latest_header_blog_url' ); 

?>
<!-- breadcrumb start -->
    <section class="breadcrumb-section effect-cls pt-0">
        <img src="<?php echo $header_img;?>" class="bg-img img-fluid blur-up lazyload" alt="">
        <div class="breadcrumb-content pt-0">
            <div>
                <h2>blog</h2>
                <nav aria-label="breadcrumb" class="theme-breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Stories</li>
                    </ol>
                </nav>
            </div>
        </div>
    </section>
    <!-- breadcrumb end -->
    <main id="primary" class="site-main">

		<?php
		//while ( have_posts() ) :
		//	the_post();

			get_template_part( 'template-parts/content', 'blog-tag' );

		//endwhile; // End of the loop.
		?>

	</main><!-- #main -->

<?php
get_footer();
?>
