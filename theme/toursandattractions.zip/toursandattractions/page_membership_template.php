<?php
/**
 * The template for the home page.
 *
 * Template Name: Memberships pages
 *
 * @package toursandattractions
 */


get_header();
$thumbnail = get_the_post_thumbnail_url(NULL, 'page-header');
?>

<!-- breadcrumb start -->
    <section class="breadcrumb-section effect-cls pt-0">
        <img src="<?php echo $thumbnail;?>" class="bg-img img-fluid blur-up lazyload" alt="">
        <div class="breadcrumb-content pt-0">
            <div>
                <h2><?php echo get_the_title(); ?></h2>
            </div>
        </div>
    </section>
    <!-- breadcrumb end -->

	<main id="primary" class="site-main">

		<?php
		while ( have_posts() ) :
			the_post();

			get_template_part( 'template-parts/content', 'membership' );

		endwhile; // End of the loop.
		?>

	</main><!-- #main -->

<?php
get_footer();
?>
