/*-----------------------------------------------------------------------------------

 Template Name:Rica
 Template URI: themes.pixelstrap.com/rica
 Description: This is E-commerce website
 Author: Pixelstrap
 Author URI: https://themeforest.net/user/pixelstrap

 ----------------------------------------------------------------------------------- */
// 01.Loader
// 02.Tap to Top
// 03.Footer
// 04.Menu
// 05.Add to cart quantity Counter
// 06.Quantity
// 07.Image to background
// 08.Category page
// 09.Custom Slick Slider js
// 10.Other js
// 11.Theme setting
// 12.Close box when mouseup
// 13.tooltip
// 14.scrollspy
// 15.toast

(function (jQuery) {
    "use strict";

    
    /*=====================
     1.Loader
     ==========================*/

    jQuery(window).on('load', function () {
        setTimeout(function(){
            jQuery('.loader-wrapper, .skeleton_loader').fadeOut('slow');
        }, 2000);
        jQuery('.loader-wrapper, .skeleton_loader').remove('slow');
    });

    /*=====================
     2.Tap to Top
     ==========================*/

    jQuery(window).on('scroll', function () {
        if (jQuery(this).scrollTop() > 600) {
            jQuery('.tap-top').addClass('top');
        } else {
            jQuery('.tap-top').removeClass('top');
        }
    });

    jQuery('.tap-top').on('click', function () {
        jQuery("html, body").animate({
            scrollTop: 0
        }, 600);
        return false;
    });

    /*=====================
     3. Footer js
     ==========================*

    var contentwidth = jQuery(window).width();
    if ((contentwidth) < '768') {
        jQuery('.footer-title h5').append('<span class="according-menu"><i class="fas fa-chevron-down"></i></span>');
        jQuery('.footer-title').click(function () {
            jQuery('.footer-title').removeClass('active');
            jQuery('.footer-content').slideUp('normal');
            if (jQuery(this).next().is(':hidden') == true) {
                jQuery(this).addClass('active');
                jQuery(this).find('span').replaceWith('<span class="according-menu"><i class="fas fa-chevron-up"></i></span>');
                jQuery(this).next().slideDown('normal');
            } else {
                jQuery(this).find('span').replaceWith('<span class="according-menu"><i class="fas fa-chevron-down"></i></span>');
            }
        });
        jQuery('.footer-content').hide();
    } else {
        jQuery('.footer-content').show();
    }

    /*=====================
     4. Menu js
     ==========================*/

    jQuery(".toggle-nav, .sidebar-toggle").click(function () {
        jQuery('.nav-menu').css("right", "0px");
        jQuery('.menu-overlay').addClass('show');
        jQuery('body').css("overflow", "hidden");
        jQuery('.theme-setting').addClass("back")
    });
    jQuery(".mobile-back").click(function () {
        jQuery('.nav-menu').css("right", "-410px");
        jQuery('.menu-overlay').removeClass('show');
        jQuery('body').css("overflow", "auto");
        jQuery('.theme-setting').removeClass("back")
    });

    jQuery(".cart").click(function () {
        jQuery('.order-cart-right').css("right", "0px");
    });
    jQuery(".back-btn").click(function () {
        jQuery('.order-cart-right').css("right", "-310px");
    });

    jQuery('.header-sidebar .menu-title').append('<span class="according-menu">+</span>');
      jQuery('.header-sidebar .menu-title').click(function () {
            jQuery(this).removeClass('active');
            jQuery(this).next().slideUp('normal');
            if (jQuery(this).next().is(':hidden') == true) {
                jQuery(this).addClass('active');
                jQuery(this).find('span').replaceWith('<span class="according-menu">-</span>');
                jQuery(this).next().slideDown('normal');
            } else {
                jQuery(this).find('span').replaceWith('<span class="according-menu">+</span>');
            }
        });
    jQuery(this).hide();

    var contentwidth = jQuery(window).width();
    if ((contentwidth) < '1200') {
        jQuery('.menu-title').append('<span class="according-menu">+</span>');
        jQuery('.menu-title').click(function () {
            jQuery(this).removeClass('active');
            jQuery(this).next().slideUp('normal');
            if (jQuery(this).next().is(':hidden') == true) {
                jQuery(this).addClass('active');
                jQuery(this).find('span').replaceWith('<span class="according-menu">-</span>');
                jQuery(this).next().slideDown('normal');
            } else {
                jQuery(this).find('span').replaceWith('<span class="according-menu">+</span>');
            }
        });
        jQuery(this).hide();
    }

    var contentwidth = jQuery(window).width();
    if ((contentwidth) < '1200') {
        jQuery('.submenu-title').append('<span class="according-menu">+</span>');
        jQuery('.submenu-title').click(function () {
            jQuery('.submenu-title').removeClass('active');
            jQuery('.submenu-content').slideUp('normal');
            if (jQuery(this).next().is(':hidden') == true) {
                jQuery(this).addClass('active');
                jQuery(this).find('span').replaceWith('<span class="according-menu">-</span>');
                jQuery(this).next().slideDown('normal');
            } else {
                jQuery(this).find('span').replaceWith('<span class="according-menu">+</span>');
            }
        });
        jQuery('.submenu-content').hide();
    }

     /*=====================
     5. Add to cart quantity Counter
     ==========================*/ 

    jQuery("button.add__button").click(function(){
        jQuery(".qty__box").addClass("open");
    });
    jQuery("button.add-button").click(function(){
        jQuery(this).next().addClass("open");
        jQuery(".order-menu-section .qty-input").val('1');
    });
    jQuery('.order-menu-section .qty-right-plus, .order-cart-right .qty-right-plus').on('click',function(){
        var jQueryqty = jQuery(this).siblings(".qty-input");
        var currentVal = parseInt(jQueryqty.val());
        if (!isNaN(currentVal)) {
            jQueryqty.val(currentVal + 1);
        }
    });
    jQuery('.order-menu-section .qty-left-minus, .order-cart-right .qty-left-minus').on('click',function(){
        var jQueryqty = jQuery(this).siblings(".qty-input");
        var _val =  jQuery(jQueryqty).val();
        if(_val == '1') {
            var _removeCls = jQuery(this).parents('.cart_qty');
            jQuery(_removeCls).removeClass("open");
        }
        var currentVal = parseInt(jQueryqty.val());
        if (!isNaN(currentVal) && currentVal > 0) {
            jQueryqty.val(currentVal - 1);
        }
    });

    /*=====================
     6. Quantity js
     ==========================*/

    jQuery('.qty-box .quantity-right-plus').on('click', function () {
        var jQueryqty = jQuery(this).parents(".qty-box").find(".input-number");
        var currentVal = parseInt(jQueryqty.val(), 10);
        if (!isNaN(currentVal)) {
            jQueryqty.val(currentVal + 1);
        }
    });
    jQuery('.qty-box .quantity-left-minus').on('click', function () {
        var jQueryqty = jQuery(this).parents(".qty-box").find(".input-number");
        var currentVal = parseInt(jQueryqty.val(), 10);
        if (!isNaN(currentVal) && currentVal > 1) {
            jQueryqty.val(currentVal - 1);
        }
    });

    /*=====================
     7. Image to background js
     ==========================*/

    jQuery(".bg-top").parent().addClass('b-top'); // background postion top
    jQuery(".bg-bottom").parent().addClass('b-bottom'); // background postion bottom
    jQuery(".bg-center").parent().addClass('b-center'); // background postion center
    jQuery(".bg-left").parent().addClass('b-left'); // background postion left
    jQuery(".bg-right").parent().addClass('b-right'); // background postion right
    jQuery(".bg_size_content").parent().addClass('b_size_content'); // background size content
    jQuery(".bg-img").parent().addClass('bg-size');
    jQuery(".bg-img.blur-up" ).parent().addClass('blur-up lazyload');
    jQuery('.bg-img').each(function () {

        var el = jQuery(this),
            src = el.attr('src'),
            parent = el.parent();


        parent.css({
            'background-image': 'url(' + src + ')',
            'background-size': 'cover',
            'background-position': 'center',
            'background-repeat': 'no-repeat',
            'display': 'block'
        });

        el.hide();
    });

    
    /*=====================
      8 .Category page
      ==========================*/

    jQuery('.collapse-block-title').on('click', function (e) {
        e.preventDefault;
        var speed = 300;
        var thisItem = jQuery(this).parent(),
            nextLevel = jQuery(this).next('.collection-collapse-block-content');
        if (thisItem.hasClass('open')) {
            thisItem.removeClass('open');
            nextLevel.slideUp(speed);
        }
        else {
            thisItem.addClass('open');
            nextLevel.slideDown(speed);
        }
    });
    jQuery('.color-selector ul li').on('click', function (e) {
        jQuery(".color-selector ul li").removeClass("active");
        jQuery(this).addClass("active");
    });
    jQuery('.product-2-layout-view').on('click', function (e) {
        if (jQuery('.product-wrapper-grid').hasClass("list-view")) { }
        else {
            jQuery(".grid-item").each(function( index ) {
                var classList = jQuery(this).attr('class');
                var filterClass = jQuery(this).data('class');
                jQuery(this).removeClass(classList);
                jQuery(this).addClass("col-sm-6 grid-item");
                jQuery(this).addClass(filterClass);
                jQuery('.filter-button-group li.active').trigger( "click" );
            });
        }
    });
    jQuery('.product-3-layout-view').on('click', function (e) {
        if (jQuery('.product-wrapper-grid').hasClass("list-view")) { }
        else {
            jQuery(".grid-item").each(function( index ) {
                var classList = jQuery(this).attr('class');
                var filterClass = jQuery(this).data('class');
                jQuery(this).removeClass(classList);
                jQuery(this).addClass("col-xl-4 col-sm-6 grid-item");
                jQuery(this).addClass(filterClass);
                jQuery('.filter-button-group li.active').trigger( "click" );
            });
        }
    });
    jQuery('.product-4-layout-view').on('click', function (e) {
        if (jQuery('.product-wrapper-grid').hasClass("list-view")) { }
        else {
            jQuery(".grid-item").each(function( index ) {
                var classList = jQuery(this).attr('class');
                var filterClass = jQuery(this).data('class');
                jQuery(this).removeClass(classList);
                jQuery(this).addClass("col-xl-3 col-lg-4 col-sm-6 grid-item");
                jQuery(this).addClass(filterClass);
                jQuery('.filter-button-group li.active').trigger( "click" );
            });
        }
    });

    /*=====================
     9. Custom Slick Slider js
     ==========================*/

    jQuery('.slide-1').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        fade: true,
    });

    jQuery('.classic-slider').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        fade: true,
        dots: true,
        customPaging: function (slider, i) {
            var j = i + 1;
            var thumb = jQuery(slider.jQueryslides[j]).data();
            return '<a class="dot">0' + j + '</a>';
        },
    });

    jQuery('.slide-2').slick({
        infinite: true,
        slidesToShow: 2,
        slidesToScroll: 2,
        responsive: [
            {
                breakpoint: 992,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    });

    jQuery('.slide-3').slick({
        infinite: true,
        speed: 300,
        slidesToShow: 3,
        slidesToScroll: 1,
        autoplay: false,
        autoplaySpeed: 5000,
        responsive: [
            {
                breakpoint: 1200,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    });

    jQuery('.slider-3').slick({
        infinite: true,
        speed: 300,
        slidesToShow: 3,
        slidesToScroll: 1,
        autoplay: false,
        autoplaySpeed: 5000,
        responsive: [
            {
                breakpoint: 1460,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            },
            {
                breakpoint: 767,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    });

    jQuery('.team-slider').slick({
        dots: true,
        infinite: true,
        speed: 300,
        slidesToShow: 3,
        slidesToScroll: 1,
        autoplay: false,
        autoplaySpeed: 5000,
        responsive: [
            {
                breakpoint: 1200,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            },
            {
                breakpoint: 767,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    });

    jQuery('.slide-4').slick({
        infinite: false,
        speed: 300,
        slidesToShow: 4,
        slidesToScroll: 1,
        autoplay: false,
        autoplaySpeed: 5000,
        responsive: [
            {
                breakpoint: 1200,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3
                }
            },
            {
                breakpoint: 991,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            },
            {
                breakpoint: 586,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    });

    jQuery('.category-4').slick({
        infinite: false,
        speed: 300,
        slidesToShow: 4,
        slidesToScroll: 1,
        autoplay: false,
        autoplaySpeed: 5000,
        responsive: [
            {
                breakpoint: 1460,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3
                }
            },
            {
                breakpoint: 1199,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    });

    jQuery('.slider-4').slick({
        infinite: false,
        speed: 300,
        slidesToShow: 4,
        slidesToScroll: 1,
        autoplay: false,
        autoplaySpeed: 5000,
        responsive: [
            {
                breakpoint: 1460,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3
                }
            },
            {
                breakpoint: 992,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            },
            {
                breakpoint: 586,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    });

    jQuery('.slide-5').slick({
        dots: false,
        infinite: true,
        speed: 300,
        slidesToShow: 5,
        slidesToScroll: 5,
        responsive: [
            {
                breakpoint: 1199,
                settings: {
                    slidesToShow: 4,
                    slidesToScroll: 4,
                    infinite: true
                }
            },
            {
                breakpoint: 576,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3
                }
            },
            {
                breakpoint: 420,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            }
        ]
    });

    jQuery('.flight-5').slick({
        dots: false,
        infinite: true,
        speed: 300,
        slidesToShow: 5,
        slidesToScroll: 5,
        autoplay: true,
        autoplaySpeed: 5000,
        responsive: [
            {
                breakpoint: 1366,
                settings: {
                    slidesToShow: 4,
                    slidesToScroll: 4,
                    infinite: true
                }
            },
            {
                breakpoint: 992,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    });

    jQuery('.slide-6').slick({
        dots: false,
        infinite: true,
        speed: 300,
        slidesToShow: 6,
        slidesToScroll: 1,
        responsive: [
            {
                breakpoint: 1367,
                settings: {
                    slidesToShow: 5,
                    slidesToScroll: 5,
                    infinite: true
                }
            },
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 4,
                    slidesToScroll: 4,
                    infinite: true
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3,
                    infinite: true
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            }

        ]
    });

    jQuery('.fare-6').slick({
        dots: false,
        infinite: true,
        speed: 300,
        slidesToShow: 7,
        slidesToScroll: 1,
        responsive: [
            {
                breakpoint: 1367,
                settings: {
                    slidesToShow: 5,
                    slidesToScroll:1,
                    infinite: true
                }
            },
            {
                breakpoint: 767,
                settings: {
                    slidesToShow: 4,
                    slidesToScroll: 1,
                    infinite: true
                }
            },
            {
                breakpoint: 576,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1
                }
            },
            {
                breakpoint: 420,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1
                }
            }
        ]
    });

    jQuery('.center-slider').slick({
        centerMode: true,
        centerPadding: '0',
        slidesToShow: 3,
        responsive: [
            {
                breakpoint: 768,
                settings: {
                    arrows: false,
                    centerMode: true,
                    slidesToShow: 3
                }
            },
            {
                breakpoint: 576,
                settings: {
                    arrows: false,
                    centerMode: true,
                    centerPadding: '40px',
                    slidesToShow: 1
                }
            }
        ]
    });

    jQuery('.center-slider-full').slick({
        centerMode: true,
        centerPadding: '150px',
        slidesToShow: 2  ,
        responsive: [
            {
                breakpoint: 768,
                settings: {
                    arrows: false,
                    centerMode: true,
                    centerPadding: '40px',
                    slidesToShow: 3
                }
            },
            {
                breakpoint: 480,
                settings: {
                    arrows: false,
                    centerMode: true,
                    centerPadding: '40px',
                    slidesToShow: 1
                }
            }
        ]
    });

    jQuery('.center-slider-cab').slick({
        centerMode: true,
        centerPadding: '0',
        slidesToShow: 3,
        responsive: [
            {
                breakpoint: 991,
                settings: {
                    centerPadding: '0',
                }
            },
            {
                breakpoint: 768,
                settings: {
                    arrows: false,
                    centerMode: true,
                    centerPadding: '20px',
                    slidesToShow: 1
                }
            }
        ]
    });

    jQuery('.slider-for').each(function(key, item) {

        var sliderIdName = 'slider' + key;
        var sliderNavIdName = 'sliderNav' + key;

        this.id = sliderIdName;
        jQuery('.slider-nav')[key].id = sliderNavIdName;

        var sliderId = '#' + sliderIdName;
        var sliderNavId = '#' + sliderNavIdName;

        jQuery(sliderId).slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: true,
            fade: true,
            asNavFor: sliderNavId
        });

        jQuery(sliderNavId).slick({
            slidesToShow: 3,
            slidesToScroll: 1,
            asNavFor: sliderId,
            arrows: false,
            dots: false,
            centerMode: true,
            focusOnSelect: true
        });

    });

    jQuery('.slider-image').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: true,
        fade: true,
        asNavFor: '.slider-thumbnail'
    });
    jQuery('.slider-thumbnail').slick({
        slidesToShow: 7,
        slidesToScroll: 1,
        asNavFor: '.slider-image',
        dots: false,
        arrows: false,
        centerMode: true,
        focusOnSelect: true,
        responsive: [
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 5
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 3
                }
            }
        ]
    });

    jQuery('.variable-width').slick({
        dots: false,
        infinite: true,
        speed: 300,
        slidesToShow: 3,
        centerMode: false,
        variableWidth: true
    });

    /*=====================
     10. Other js
     ==========================*/

     var contentwidth = jQuery(window).width();
     if ((contentwidth) > '319') {
         jQuery('.filter-btn').append('<span class="according-menu"></span>');
         jQuery('.filter-btn').click(function () {
             jQuery('.filter-btn').removeClass('active');
             jQuery('.filter-content').slideUp('normal');
             if (jQuery(this).next().is(':hidden') == true) {
                 jQuery(this).addClass('active');
                 jQuery(this).next().slideDown('normal');
             }
         });
         jQuery('.filter-content').hide();
     } else {
         jQuery('.filter-content').show();
     }
 
     jQuery(".car-select li").click(function () {
         jQuery(this).addClass('active').siblings().removeClass('active');
     });
 
     jQuery(".open-select").click(function () {
         jQuery(this).parent().find(".selector-box, .selector-box-flight").addClass("show");
     });
 
     jQuery(".setting a").click(function () {
         jQuery(".setting-open").toggleClass("show");
     });
 
     jQuery(".search-bar i").click(function () {
         jQuery(".form-control-search").toggleClass("open");
     });
 
     // collection filter
     jQuery('.mobile-filter').on('click', function(e) {
         jQuery('.left-sidebar, .top-filter-section').css("left","-1px");
     });
     jQuery('.back-btn').on('click', function(e) {
         jQuery('.left-sidebar, .top-filter-section').css("left","-365px");
     });
 
     jQuery(".respon-filter-btn").click(function(){
         jQuery(".respon-filter-content").toggleClass("show");
     });
 
     jQuery(".view-map").click(function(){
         jQuery(".onclick-map").toggleClass("show");
     });
 
     jQuery(".popup-btn").click(function(){
         jQuery(".sidebar-popup").toggleClass("open");
     });
 
     var width_content = jQuery(window).width();
     if ((width_content) > '991') {
 
         jQuery(".filter-bottom-title").click(function () {
             jQuery(".filter-bottom-content").slideToggle("");
         });
         jQuery(".close-filter-bottom").click(function () {
             jQuery(".filter-bottom-content").slideUp("");
         });
     }
     else {
         jQuery(".filter-bottom-title").click(function () {
             jQuery(".filter-bottom-content").toggleClass("open");
         });
         jQuery(".close-filter-bottom").click(function () {
             jQuery(".filter-bottom-content").removeClass("open");
         });
     }
 
     // fare calender
       jQuery(".fare-calender").click(function(){
         jQuery(".calender-external").addClass("show");
     });
     jQuery(".modify-search").click(function(){
         jQuery(".flight-search-detail").addClass("show");
     });
     jQuery(".responsive-close").click(function(){
         jQuery(".flight-search-detail").removeClass("show");
     });
 
     // flight top filter
     jQuery(".onclick-title h6").click(function(){
         jQuery(this).parent(".onclick-title").toggleClass("show").siblings().removeClass('show');
     });
 
     // round trip selection
     jQuery(".round_trip .detail-bar .detail-wrap").click(function(){
         jQuery(this).addClass('active').siblings().removeClass('active');
     });
 
     // address select js
     jQuery(".address-sec .select-box").click(function(){
         jQuery(this).addClass('active').siblings().removeClass('active');
     });
 
     // resturant menu smooth scroll
     jQuery('.order-menu .nav-pills a').bind('click', function(e) {
         e.preventDefault(); 
 
         var target = jQuery(this).attr("href"); 
         jQuery('html, body').stop().animate({
             scrollTop: jQuery(target).offset().top
         }, 600, function() {
             location.hash = target; 
         });
 
         return false;
     });
 
     // change on select cab layout
     jQuery('input:radio[name=exampleRadios]').change(function() {
         if (this.value == 'option1') {
             document.getElementById('dropdate').style.display ='block';
         }
         else if (this.value == 'option2') {
             document.getElementById('dropdate').style.display ='none';
         }
     });

    /*=====================
     11. Theme setting js
     ==========================*/

    jQuery('#dark:checkbox').change(function(){
    if(jQuery(this).is(":checked")) {
        jQuery('body').addClass('dark');
    } else {
        jQuery('body').removeClass('dark');
    }
    });
    jQuery('#rtl:checkbox').change(function(){
    if(jQuery(this).is(":checked")) {
        jQuery('body').addClass('rtl');
    } else {
        jQuery('body').removeClass('rtl');
    }
    });

})(jQuery);


    /*==============================
     12. Close box when mouseup js
     ==============================*/
    jQuery(document).mouseup(function (e) {
        var container = jQuery(".open-select, .selector-box, .selector-box-flight, .fare-calender, .setting");

        if (!container.is(e.target)
            && container.has(e.target).length === 0) {
            jQuery(".selector-box, .selector-box-flight, .calender-external, .setting-open").removeClass("show");
        }
    });

    /*==============================
     13. tooltip js
     ==============================*/
    jQuery(function () {
        jQuery('[data-toggle="tooltip"]').tooltip()
    });

    /*==============================
     14. scrollspy js
     ==============================*
    jQuery('body').scrollspy({
        target: '#order-menu',
        offset: 70
    });
*/






