<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package toursandattractions
 */
$phone     = get_theme_mod( 'home_contact_phone' ); 
$hours     = get_theme_mod( 'noo_contact_opening_hours' );

$phone      = (!empty($phone)) ? $phone : "Store Phone";
$hours      = (!empty($hours)) ? $hours : "Store Hours";

$title      = get_the_title();
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<!--<section class="section-b-space bg-white">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                	<?php
                       the_content();
					?>
            	</div>
            </div>
        </div>
    </section>-->


<!-- section start -->
    <section class="small-section bg-inner">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="filter-panel right-filter open-cls">
                        <div class="left-filter">
                            <div class="respon-filter-btn ">
                                <h6> filter <i class="fas fa-sort-down"></i></h6>
                                <span class="according-menu"></span>
                            </div>
                            <div class="filters respon-filter-content filter-button-group">
                                <ul>
                                    <li class="active" data-filter="*">All</li>
                                    <li data-filter=".popular">popular</li>
                                    <li data-filter=".latest">latest</li>
                                    <li data-filter=".trend">trend</li>
                                </ul>
                            </div>
                        </div>
                        <div class="right-panel">
                            <a href="javascript:void(0)" class="view-map"><i class="fas fa-search"></i> find tours</a>
                        </div>
                    </div>
                </div>
                <div class="col-xl-12 onclick-map">
                    <div class="book-table single-table bg-inner">
                        <div class="table-form classic-form">
                            <form>
                                <div class="row w-100">
                                    <div class="form-group col p-0">
                                        <input type="text" class="form-control" id="exampleFormControlInput1"
                                            placeholder="Starting from">
                                        <img src="<?php echo get_stylesheet_directory_uri();?>/assets/images/icon/table-no.png" class="img-fluid blur-up lazyload"
                                            alt="">
                                    </div>
                                    <div class="form-group col p-0">
                                        <input type="text" class="form-control" placeholder="Going to">
                                        <img src="<?php echo get_stylesheet_directory_uri();?>/assets/images/icon/table-no.png" class="img-fluid blur-up lazyload"
                                            alt="">
                                    </div>
                                </div>
                                <a href="#" class="btn btn-rounded color1">search</a>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="left-sidebar sticky-cls-top">
                        <div class="back-btn">
                            back
                        </div>
                        <div class="search-bar">
                            <input type="text" placeholder="Search here..">
                            <i class="fas fa-search"></i>
                        </div>
                        <div class="middle-part collection-collapse-block open">
                            <a href="javascript:void(0)" class="section-title collapse-block-title">
                                <h5>search filter</h5>
                                <img src="<?php echo get_stylesheet_directory_uri();?>/assets/images/icon/adjust.png" class="img-fluid blur-up lazyload" alt="">
                            </a>
                            <div class="collection-collapse-block-content ">
                                <!--<div class="filter-block">
                                    <div class="collection-collapse-block open">
                                        <h6 class="collapse-block-title">star category</h6>
                                        <div class="collection-collapse-block-content">
                                            <div class="collection-brand-filter">
                                                <div class="custom-control custom-checkbox collection-filter-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="five">
                                                    <label class="custom-control-label rating" for="five">
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                        <span class="ml-1">(4025)</span>
                                                    </label>
                                                </div>
                                                <div class="custom-control custom-checkbox collection-filter-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="four">
                                                    <label class="custom-control-label rating" for="four">
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                        <i class="far fa-star"></i>
                                                        <span class="ml-1">(2012)</span>
                                                    </label>
                                                </div>
                                                <div class="custom-control custom-checkbox collection-filter-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="three">
                                                    <label class="custom-control-label rating" for="three">
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                        <i class="far fa-star"></i>
                                                        <i class="far fa-star"></i>
                                                        <span class="ml-1">(25)</span>
                                                    </label>
                                                </div>
                                                <div class="custom-control custom-checkbox collection-filter-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="two">
                                                    <label class="custom-control-label rating" for="two">
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                        <i class="far fa-star"></i>
                                                        <i class="far fa-star"></i>
                                                        <i class="far fa-star"></i>
                                                        <span class="ml-1">(1)</span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="filter-block">
                                    <div class="collection-collapse-block open">
                                        <h6 class="collapse-block-title">flights</h6>
                                        <div class="collection-collapse-block-content">
                                            <div class="collection-brand-filter">
                                                <div class="custom-control custom-checkbox collection-filter-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="zara">
                                                    <label class="custom-control-label" for="zara">with flights</label>
                                                </div>
                                                <div class="custom-control custom-checkbox collection-filter-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="vera-moda">
                                                    <label class="custom-control-label" for="vera-moda">without
                                                        flights</label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>-->
                                <?php 
                                $args = array(
                                    'post_type'      => array( 'narnoo_attraction','narnoo_accommodation'), //Can add more
                                    'post_status'    => array('publish'),
                                    'post_parent'    => 0
                                    
                                );
                                $subcategory = new WP_Query( $args );


                                    $nonce = wp_create_nonce("noo_ajax_search_nonce");
                                    $link = admin_url('admin-ajax.php?action=noo_product_search&nonce='.$nonce);
                                    //echo '<a class="user_like" data-nonce="' . $nonce . '" data-post_id="' . $post->ID . '" href="' . $link . '">Like this Post</a>';
                                
                                ?>
                                <div class="filter-block">
                                    <div class="collection-collapse-block open">
                                        <h6 class="collapse-block-title">Sub Category</h6>
                                        <div class="collection-collapse-block-content">
                                            <div class="collection-brand-filter">
                                            <?php while ( $subcategory->have_posts() ) : $subcategory->the_post(); ?>
                                                <div class="custom-control custom-checkbox collection-filter-checkbox">
                                                   <!-- <input type="checkbox" class="custom-control-input" id="<?php echo get_the_title(); ?>"> -->
                                                    <a href="<?php echo $link; ?>" data-nonce="<?php echo $nonce; ?>" data-filter="<?php echo get_the_title(); ?>" data-loc="<?php echo $title; ?>" class="custom-control-label noo_product_search"><?php echo get_the_title(); ?></a>
                                                </div>
                                            <?php  endwhile; wp_reset_query(); ?>   
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="filter-block">
                                    <div class="collection-collapse-block open">
                                        <h6 class="collapse-block-title">budget</h6>
                                        <div class="collection-collapse-block-content">
                                            <div class="wrapper">
                                                <div class="range-slider">
                                                    <input type="text" class="js-range-slider" value="" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                              <!--  <div class="filter-block">
                                    <div class="collection-collapse-block open">
                                        <h6 class="collapse-block-title">trip duration</h6>
                                        <div class="collection-collapse-block-content">
                                            <div class="collection-brand-filter">
                                                <div class="custom-control custom-checkbox collection-filter-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="english">
                                                    <label class="custom-control-label" for="english">upto 3
                                                        nights</label>
                                                </div>
                                                <div class="custom-control custom-checkbox collection-filter-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="sign">
                                                    <label class="custom-control-label" for="sign">4 to 7 nights</label>
                                                </div>
                                                <div class="custom-control custom-checkbox collection-filter-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="italiano">
                                                    <label class="custom-control-label" for="italiano">7 to 11
                                                        nights</label>
                                                </div>
                                                <div class="custom-control custom-checkbox collection-filter-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="suomi">
                                                    <label class="custom-control-label" for="suomi">11 to 15
                                                        nights</label>
                                                </div>
                                                <div class="custom-control custom-checkbox collection-filter-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="espanol">
                                                    <label class="custom-control-label" for="espanol">15 to 21
                                                        nights</label>
                                                </div>
                                                <div class="custom-control custom-checkbox collection-filter-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="french">
                                                    <label class="custom-control-label" for="french">above 21
                                                        nights</label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>-->
                            </div>
                        </div>
                        <div class="bottom-info">
                            <h5><span>i</span> need help</h5>
                            <h4><?php echo $phone; ?></h4>
                            <h6><?php echo $hours; ?></h6>
                        </div>
                    </div>
                </div>
                <!-- product content -->
                <div class="col-lg-9 ratio3_2">
                    <a href="javascript:void(0)" class="mobile-filter border-top-0">
                        <h5>latest filter</h5>
                        <img src="<?php echo get_stylesheet_directory_uri();?>/assets/images/icon/adjust.png" class="img-fluid blur-up lazyload" alt="">
                    </a>
                    <div class="product-wrapper-grid special-section grid-box">
                        <div id="productSearch" class="row content grid">
                           <?php
                                $destination = get_the_title();
                                $args = array(
                                    'post_type'     => array( 'narnoo_product'),
                                    'post_status'   => array('publish'),
                                    'meta_key'      => 'noo_destination_select_id',
                                    'meta_value'    => $destination,
                                    
                                );
                                $d_query = new WP_Query( $args );
                           ?>
                           <?php if( $d_query->have_posts() ){?>
                           <?php while ( $d_query->have_posts() ) : $d_query->the_post();?>
                            <div class="col-xl-4 col-sm-6 latest grid-item wow fadeInUp" data-class="latest">
                                <div class="special-box p-0">
                                    <div class="special-img">
                                    <?php 
                                        $thumbnail = get_the_post_thumbnail_url();
                                    ?>
                                        <a href="<?php echo get_the_permalink( ); ?>">
                                            <img src="<?php echo $thumbnail; ?>"
                                                class="img-fluid blur-up lazyload bg-img" alt="">
                                        </a>
                                        <!--<div class="top-icon">
                                            <a href="#" class="" data-toggle="tooltip" data-placement="top" title=""
                                                data-original-title="Add to Wishlist">
                                                <i class="far fa-heart"></i>
                                            </a>
                                        </div>-->
                                    </div>
                                    <div class="special-content">
                                        <a href="<?php echo get_the_permalink( ); ?>">
                                            <h5><?php echo the_title(); ?> </span></h5>
                                        </a>
                                        <div class="tour-detail">
                                            <div class="bottom-section">
                                                <div class="price">
                                                     <?php $maxPrice           = get_post_meta($post->ID, 'product_max_price',       true); ?>
                                                    <h6>$<?php echo $maxPrice;?></h6>
                                                    <span>price per person</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        <?php 
                            endwhile; 
                        }
                        ?>
                    </div>
                   <!-- <nav aria-label="Page navigation example" class="pagination-section mt-0">
                        <ul class="pagination">
                            <li class="page-item">
                                <a class="page-link" href="javascript:void(0)" aria-label="Previous">
                                    <span aria-hidden="true">&laquo;</span>
                                    <span class="sr-only">Previous</span>
                                </a>
                            </li>
                            <li class="page-item active"><a class="page-link" href="javascript:void(0)">1</a></li>
                            <li class="page-item"><a class="page-link" href="javascript:void(0)">2</a></li>
                            <li class="page-item"><a class="page-link" href="javascript:void(0)">3</a></li>
                            <li class="page-item">
                                <a class="page-link" href="#" aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                    <span class="sr-only">Next</span>
                                </a>
                            </li>
                        </ul>
                    </nav>-->
                </div>
            </div>
        </div>
    </section>
    <!-- section End -->

</article><!-- #post-<?php the_ID(); ?> -->
