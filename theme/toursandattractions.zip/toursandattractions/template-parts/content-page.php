<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package toursandattractions
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<section class="section-b-space bg-white" style="padding-top:50px">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="blog-single-detail">
                        <div class="title-part">
                        	<ul class="post-detail">
                                <li><?php echo get_the_date('d F Y'); ?></li>
                                <li>Posted By : <?php echo get_the_author_meta('display_name')?></li>
                                <?php 
                                $posttags = get_the_tags();
									if ($posttags) { ?>
									<li>tags : 
									<?php 
									  foreach($posttags as $tag) {
									    echo "'".$tag->name . "' "; 
									  } ?>
									</li>
								<?php 
									}
								?>
                            </ul>
                            <h3><?php echo get_the_title(); ?></h3>
						</div>
                       <div class="detail-part">
                       <?php

                       the_content();

                       ?>
                       <div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php 
    $p_search_array = array();
    //Get related posts
    $products = get_post_meta($post->ID, 'narnoo_products_in_post',       true);

    if($products){
      //Break up the products here.
      $p_array = explode(',', $products);
      foreach ($p_array as $itm) {

          $t_p_search['key']      = 'narnoo_product_id';
          $t_p_search['value']    = $itm;
          $t_p_search['compare']  = '=';
          array_push($p_search_array, $t_p_search);

        
      }

      $pargs = array(
        'post_type'     => array( 'narnoo_product'),
        'post_status'   => array('publish'),
        'meta_key'      => 'narnoo_product_id',
        'meta_query'    => array(                  //(array) - Custom field parameters (available with Version 3.1).
          'relation'    => 'OR',
          array(
             'key'      => 'narnoo_product_id',    //(string) - Custom field key.
             'value'    => '535535493',            //(string/array) - Custom field value (Note: Array support is limited to a compare value of 'IN', 'NOT IN', 'BETWEEN', or 'NOT BETWEEN') Using WP < 3.9? Check out this page for details: http://codex.wordpress.org/Class_Reference/WP_Query#Custom_Field_Parameters
             'compare'  => '=',                    //(string) - Operator to test. Possible values are '=', '!=', '>', '>=', '<', '<=', 'LIKE', 'NOT LIKE', 'IN', 'NOT IN', 'BETWEEN', 'NOT BETWEEN', 'EXISTS' (only in WP >= 3.5), and 'NOT EXISTS' (also only in WP >= 3.5). Default value is '='.
           ),
          array(
             'key'      => 'narnoo_product_id',    //(string) - Custom field key.
             'value'    => '795107742',            //(string/array) - Custom field value (Note: Array support is limited to a compare value of 'IN', 'NOT IN', 'BETWEEN', or 'NOT BETWEEN') Using WP < 3.9? Check out this page for details: http://codex.wordpress.org/Class_Reference/WP_Query#Custom_Field_Parameters
             'compare'  => '=',                    //(string) - Operator to test. Possible values are '=', '!=', '>', '>=', '<', '<=', 'LIKE', 'NOT LIKE', 'IN', 'NOT IN', 'BETWEEN', 'NOT BETWEEN', 'EXISTS' (only in WP >= 3.5), and 'NOT EXISTS' (also only in WP >= 3.5). Default value is '='.
           ),
          //$p_search_array,
        ),
      );
      //print_r($pargs);
      //print_r($p_search_array);
      $p_query = new WP_Query( $pargs );

    }
    

    ?>

    <?php if( !empty( $products ) && !empty( $p_query->have_posts() ) ){ ?>
    <!-- category 3 start -->
    <section class="category-wrapper pt-0 section-b-space">
        <div class="container">
            <div class="title-1 title-5">
                <span class="title-label">featured</span>
                <h2>Products featured in this post</h2>
                <p>Trips, experiences, and places. All in one service.</p>
            </div>
            <div class="row">
                <div class="col">
                    <div class="slide-2 arrow-classic">
                    <?php while ( $p_query->have_posts() ) : $p_query->the_post(); ?>
                      <?php 
                                $thumbnail         = get_the_post_thumbnail_url();
                                $minPrice           = get_post_meta($post->ID, 'product_min_price',       true);
                       ?>
                        <div>
                            <div class="category-wrap wow fadeInUp">
                                <div class="category-img">
                                    <a href="<?php echo get_the_permalink( ); ?>">
                                    <img src="<?php echo $thumbnail; ?>'" alt="" class="img-fluid blur-up lazyload"></a>
                                    <div class="side-effect"></div>
                                </div>
                                <div class="category-content">
                                    <div>
                                        <div class="top">
                                            <a href="<?php echo get_the_permalink( ); ?>">
                                                <h3><?php echo the_title(); ?></h3>
                                            </a>
                                            <!--<div class="like-cls">
                                                <i class="fas fa-heart"><span class="effect"></span></i>
                                            </div>-->
                                        </div>
                                        <?php $check = checkVcEditorContent( get_the_content() ); ?>
                                        <p><?php 
                                        if(!empty($check)){
                                            echo wp_trim_words( wp_strip_all_tags( get_the_excerpt() ), 10, '...' ); 
                                        }else{
                                            echo wp_trim_words( wp_strip_all_tags( get_the_content() ), 10, '...' ); 
                                        }
                                        ?></p>
                                        <div class="bottom">
                                            <h3>from $<?php echo $minPrice;?>*</h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                      <?php endwhile; wp_reset_query(); ?>
                    </div>
                </div>
            </div>
            <div><small><p>*All prices subject to change based on availability and date</p></small></div>
        </div>
    </section>
    <!-- category 3 end -->
    <?php } ?>
</article><!-- #post-<?php the_ID(); ?> -->
