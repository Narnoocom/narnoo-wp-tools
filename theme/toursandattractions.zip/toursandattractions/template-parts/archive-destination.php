<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package toursandattractions
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?> bere>

	<!--<section class="section-b-space bg-white">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                	<?php
                       the_content();
					?>
            	</div>
            </div>
        </div>
    </section>-->
<?php
$dst_icons   = array('fa-plane','fa-ticket-alt','fa-anchor');
shuffle($dst_icons);
$args = array(
	'post_type' 	=> array( 'destinations'),
	'post_status'	=> array('publish'),
    'orderby'       => 'menu_order', 
    'order'         => 'ASC',
	
);
$d_query = new WP_Query( $args );

if( $d_query->have_posts() ){?>

    <!-- tours section start -->
    <section class="category-sec ratio3_2 section-b-space">
        <div class="container">
            <div class="title-1 title-5">
                <h2>our popular destinations</h2>
                <p>Trips, experiences, and places. All in one service.</p>
            </div>
            <?php 
            $count = 1;
            while ( $d_query->have_posts() ) : $d_query->the_post();?>
            <?php if ($count%4 == 1){ ?>
            <div class="row">
            <?php } ?>
            	<?php $_i    = rand(0,2); ?>
                <div class="col-xl-3">
                    <a href="<?php echo get_the_permalink( ); ?>">
                        <div class="category-box">
                            <div class="img-category">
                            	<?php 
                            	$thumbnail = get_the_post_thumbnail_url( $post->ID );
                            	?>
                                <div>
                                    <img src="<?php echo $thumbnail; ?>" alt="" class="img-fluid blur-up lazyload bg-img">
                                </div>
                                <div class="top-bar">
                                    <h5><?php echo the_title();  ?></h5>
                                </div>
                                <div class="like-cls">
                                    <i class="fas <?php echo $dst_icons[$_i]; ?>"><span class="effect"></span></i>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            <?php if ($count%4 == 0){ ?>
            </div>
            <?php } $count++; ?>
            <?php endwhile; if ($count%4 != 1) echo "</div>"; ?>
        </div>
    </section>
    <!-- tours section end -->
<?php } wp_reset_query(); //close if ?>

</article><!-- #post-<?php the_ID(); ?> -->
