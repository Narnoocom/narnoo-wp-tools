<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package toursandattractions
 */
$tag_cloud_array = array();
$bg_img         = get_theme_mod( 'home_bg_setting_url' );
$bg_video       = get_theme_mod( 'home_bg_video_url' );
$videoDisplay   = get_theme_mod( 'media_select_id', true );
$ctaDisplay     = get_theme_mod( 'cta_select_id', true );

$subNonce          = wp_create_nonce("noo_email_subscribe_nonce");
$subLink           = admin_url('admin-ajax.php?action=noo_email_subscribe&nonce='.$subNonce);

global $wpdb;

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

<?php if( !empty($bg_video) && !empty($videoDisplay) ){ ?>
<!-- home section start -->
    <section class="home_section  p-0">
            <div class="home yt_bg_video">
                <div id="ytbg" data-youtube="<?php echo $bg_video; ?>"></div>
            </div>
    </section>
   
    <!-- home section end -->
<?php }elseif ( !empty($bg_img) ) { ?>
    <!-- home section start -->
    <section class="home_section  p-0">
            <?php 
                $home_img   = (!empty($bg_img)) ? (string) $bg_img :  (string) get_stylesheet_directory_uri().'/assets/images/tour-bg.jpg';
            ?>
            <div>
                <div class="home ripple-effect">
                    <img src="<?php echo $home_img; ?>" class="img-fluid blur-up lazyload bg-img" alt="">
                </div>
            </div>
            
    
        <div class="offer-text">
            <h6>
                <span>s</span>
                <span>t</span>
                <span>a</span>
                <span>r</span>
                <span>t</span>
                <span></span>
                <span>y</span>
                <span>o</span>
                <span>u</span>
                <span>r</span>
                <span></span>
                <span>j</span>
                <span>o</span>
                <span>u</span>
                <span>n</span>
                <span>e</span>
                <span>y</span>
            </h6>
        </div>
    </section>
    <div class="error"></div>
    <!-- home section end -->
<?php } ?>
<?php 
$args = array(
    'post_type'      => array( 'destinations'),
    'post_status'    => array('publish'),
    'orderby'        => 'menu_order', 
    'order'          => 'ASC',
    
);
$m_query = new WP_Query( $args );
?>
    <!-- book table section start -->
    <section class="book-table section-b-space p-0 single-table">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="table-form">
                        <form>
                            <div class="row w-100">
                                <div class="form-group col p-0">
                                    <div class="suggestion_box">
                                        <div class="form-group">
                                            <input type="text" class="form-control open-select" placeholder="Where do you want to explore?">
                                            <div class="selector-box">
                                                <h6 class="title">popular destinations</h6>
                                                <ul>
                                                <?php  if( $m_query->have_posts() ){ while ( $m_query->have_posts() ) : $m_query->the_post(); ?>

                                                    <li>
                                                        <a href="<?php echo get_the_permalink(); ?>">
                                                            <h5><?php echo get_the_title(); ?></h5>
                                                        </a>
                                                    </li>

                                                <?php   endwhile;  } wp_reset_query(); ?>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--<a href="#" class="btn btn-rounded color1">search</a>-->
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- book table section end -->
<?php
$args = array(
    'post_type'     => array( 'narnoo_product'),
    'post_status'   => array('publish'),
    'meta_key'      => 'narnoo_featured_product',
    'meta_value'    => 'on',
    'posts_per_page' => 12
    
);
$p_query = new WP_Query( $args );

if( $p_query->have_posts() ){?>
	<!-- tours section start -->
    <section class="category-sec ratio3_2 section-b-space" style="padding-bottom:0px">
        <div class="container">
            <div class="title-1 title-5">
                <span class="title-label">trending products</span>
                <h2>our most popular tours</h2>
                <p>Trips, experiences, and places. All in one service.</p>
            </div>
            <?php 
            $count = 1;
            while ( $p_query->have_posts() ) : $p_query->the_post();?>
            <?php  
                $temp_cloud_array = array(
                    'label'  => utf8_encode( get_the_title() ),
                    'link'   => get_the_permalink()
                );
                array_push($tag_cloud_array, $temp_cloud_array);
            ?>
            <?php if ($count%4 == 1){ ?>
            <div class="row">
            <?php } ?>
                <?php $maxPrice           = get_post_meta($post->ID, 'product_min_price',       true); ?>
                <div class="col-xl-3">
                    <a href="<?php echo get_the_permalink( ); ?>">
                        <div class="category-box">
                            <div class="img-category">
                                <?php 
                                $thumbnail = get_the_post_thumbnail_url();
                                ?>
                                <div>
                                    <img src="<?php echo $thumbnail; ?>" alt="" class="img-fluid blur-up lazyload bg-img">
                                </div>
                                <div class="top-bar">
                                    <h5>from $<?php echo $maxPrice;?>*</h5>
                                </div>
                                <div class="like-cls">
                                    <i class="fas fa-bolt"><span class="effect"></span></i>
                                </div>
                            </div>
                            <div class="content-category">
                                <div class="top">
                                    <h3><?php echo the_title(); ?></h3>
                                </div>
                                <?php $check = checkVcEditorContent( get_the_content() ); ?>
                                <p><?php 
                                if(!empty($check)){
                                    echo wp_trim_words( wp_strip_all_tags( get_the_excerpt() ), 10, '...' ); 
                                }else{
                                    echo wp_trim_words( wp_strip_all_tags( get_the_content() ), 10, '...' ); 
                                }
                                ?></p>
                            </div>
                        </div>
                    </a>
                </div>
            <?php if ($count%4 == 0){ ?>
            </div>
            <?php } $count++; ?>
            <?php endwhile;  if ($count%4 != 1) echo "</div>"; wp_reset_query(); ?>
        </div>
    </section>
    <!-- tours section end -->
<?php } //close if ?>


<?php
$dst_icons   = array('fa-plane','fa-ticket-alt','fa-anchor');
shuffle($dst_icons);

$destination = lcfirst( get_the_title() );
$args = array(
    'post_type'      => array( 'destinations'),
    'post_status'    => array('publish'),
    'posts_per_page' => 8,
    'orderby'        => 'rand',
    
);
$d_query = new WP_Query( $args );

if( $d_query->have_posts() ){?>
<!-- category 2 start -->
    <section class="category-sec ratio3_2 section-b-space" style="padding-top:3%">
        <div class="container">
            <div class="title-1 title-5">
                <h2>Popular Destinations</h2>
                <p>Trips, experiences, and places. All in one service.</p>
            </div>
            <div class="row grid">
                <div class="col">
                    <?php $_i = 0; while ( $d_query->have_posts() ) : $d_query->the_post(); ?>
                    <?php  
                        $temp_cloud_array = array(
                            'label'  => get_the_title(),
                            'link'   => get_the_permalink()
                        );
                        //array_push($tag_cloud_array, $temp_cloud_array);
                    ?>
                    <div class="grid-item wow fadeInUp col-lg-4 col-sm-6">
                        <a href="<?php echo get_the_permalink( ); ?>">
                        <div class="category-box">
                            <div class="img-category">
                                <?php 
                                $thumbnail = get_the_post_thumbnail_url( );
                                ?>
                                <div>
                                    <img src="<?php echo $thumbnail; ?>" alt="" class="img-fluid blur-up lazyload">
                                </div>
                                <div class="top-bar">
                                    <h5><?php echo the_title();  ?></h5>
                                </div>
                                <!--<div class="like-cls">
                                    <i class="fas <?php echo $dst_icons[$_i]; ?>"><span class="effect"></span></i>
                                </div>-->
                            </div>
                        </div>
                    </a>
                    </div>
                <?php  $_i++; endwhile;  ?>
                    
                </div>
            </div>
        </div>
    </section>
    <!-- category 2 end -->
<?php } wp_reset_query();//close if ?>

<?php
$args = array(
    'post_type'     => array( 'narnoo_product'),
    'post_status'   => array('publish'),
    'posts_per_page' => 8,
    'orderby'        => 'rand',
    
);
$ph_query = new WP_Query( $args );

if( $ph_query->have_posts() ){?>
    <!-- tours section start -->
    <section class="category-sec ratio3_2 section-b-space" style="padding-top:0px; padding-bottom:0px">
        <div class="container">
            <div class="title-1 title-5">
                <h2>local experiences you'll love</h2>
                <p>Trips, experiences, and places. All in one service.</p>
            </div>
            <?php 
            $count = 1;
            while ( $ph_query->have_posts() ) : $ph_query->the_post();?>
            <?php  
                $temp_cloud_array = array(
                    'label'  => utf8_encode( get_the_title() ),
                    'link'   => get_the_permalink()
                );
                //array_push($tag_cloud_array, $temp_cloud_array);
            ?>
            <?php if ($count%4 == 1){ ?>
            <div class="row">
            <?php } ?>
                <?php $maxPrice           = get_post_meta($post->ID, 'product_min_price',       true); ?>
                <div class="col-xl-3">
                    <a href="<?php echo get_the_permalink( ); ?>">
                        <div class="category-box">
                            <div class="img-category">
                                <?php 
                                $thumbnail = get_the_post_thumbnail_url();
                                ?>
                                <div>
                                    <img src="<?php echo $thumbnail; ?>" alt="" class="img-fluid blur-up lazyload bg-img">
                                </div>
                                <div class="top-bar">
                                    <h5>from $<?php echo $maxPrice;?>*</h5>
                                </div>
                                <!--<div class="like-cls">
                                    <i class="fas fa-bolt"><span class="effect"></span></i>
                                </div>-->
                            </div>
                            <div class="content-category">
                                <div class="top">
                                    <h3><?php echo the_title(); ?></h3>
                                </div>
                                <?php $check = checkVcEditorContent( get_the_content() ); ?>
                                <p><?php 
                                if(!empty($check)){
                                    echo wp_trim_words( wp_strip_all_tags( get_the_excerpt() ), 10, '...' ); 
                                }else{
                                    echo wp_trim_words( wp_strip_all_tags( get_the_content() ), 10, '...' ); 
                                }
                                ?></p>
                            </div>
                        </div>
                    </a>
                </div>
            <?php if ($count%4 == 0){ ?>
            </div>
            <?php } $count++; ?>
            <?php endwhile;  if ($count%4 != 1) echo "</div>"; wp_reset_query(); ?>
        </div>
    </section>
    <!-- tours section end -->
<?php } //close if ?>


<?php
if(!empty($ctaDisplay )){


$cta_bg_img     = get_theme_mod( 'home_cta_bg_setting_url' ); 
$cta_editor     = get_theme_mod( 'home_editor_setting' ); 
$cta_vimg       = get_theme_mod('home_cta_video_bg_setting_url');
$cta_video      = get_theme_mod( 'home_cta_video_setting' ); 
$cta_link       = get_theme_mod( 'home_cta_link_setting' ); //optional
$cta_catch      = get_theme_mod( 'home_cta_cta_setting' ); //optional

if(!empty($cta_bg_img) || !empty($cta_video)){

?>
<!-- video section start -->
    <section class="video_section parallax-img">
        <img src="<?php echo $cta_bg_img; ?>" alt="" class="img-fluid blur-up lazyload bg-img">
        <div class="container">
            <div class="row">
                <div class="col-xl-5 col-lg-6">
                    <div class="video-content">
                        <div>
                        <?php echo $cta_editor; ?>
                        <?php if(!empty($cta_link)){ 
                            $buttonText = (!empty($cta_catch)) ? $cta_catch : 'Learn More';
                        ?>
                        <div class="bottom-section">
                            <a href="<?php echo $cta_link; ?>" class="btn btn-rounded btn-sm color1"><?php echo $cta_catch; ?></a>
                        </div>
                        <?php } ?>
                        </div>
                    </div>
                </div>
                <?php if( !empty($cta_vimg) ){ ?>
                <div class="col-xl-6 offset-xl-1 col-lg-6 order-cls">
                    <div class="video-image">
                        <div class="side-effect"></div>
                        <img src="<?php echo $cta_vimg; ?>" class="img-fluid blur-up lazyload" alt="">
                        <div data-toggle="modal" data-target="#video" class="video-icon">
                            <span></span>
                        </div>
                    </div>
                </div>
                <?php } ?>
            </div>
        </div>
        <?php 
        if( !empty($cta_catch) ){ 
            $cta_array = str_split($cta_catch);
        ?>
        <div class="offer-text">
            <h6>
                <?php 
                    foreach ($cta_array as $itm) {
                        echo '<span>'.$itm.'</span>';
                    }
                ?>
            </h6>
        </div>
        <?php } ?>
    </section>
    <?php if(!empty($cta_video)){ ?>
    <div class="modal fade video-modal" id="video" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">×</span></button>
                    <iframe src="<?php echo $cta_video; ?>" allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </div>
    <!-- video section end -->
    <?php } ?>
<?php 
     }
    }
 ?>
<!-- cloudtags section start -->
<section style="padding-top:0px !important">
        <div class="container">
        <div class="row">
                <div class="col-xl-12">
                <div id="demo-link" width="100%"></div>
                </div>
            </div>
        </div>
</section>
<!-- cloudtags section end -->

<?php
$args = array(
    'post_type'      => array( 'testimonial'),
    'post_status'    => array('publish'),
    'posts_per_page' => 3,
    
);
$t_query = new WP_Query( $args );

if( $t_query->have_posts() ){?>
    <!-- testimonial section start -->
    <section class="testimonial-section">
        <div class="container">
            <div class="title-3 rounded">
                <span class="title-label">our</span>
                <h2>our happy customer<span>customers</span></h2>
            </div>
            <div class="slide-1">
            <?php while ( $t_query->have_posts() ) : $t_query->the_post(); ?> 
                <div>
                    <div class="row">
                        <div class="col-xl-8 offset-xl-2">
                            <div class="testimonial">
                                <div class="left-part">
                                    <?php 
                                        $thumbnail = get_the_post_thumbnail_url();
                                    ?>
                                    <img src="<?php echo $thumbnail; ?>" class="img-fluid blur-up lazyload" alt="">
                                    <div class="design">
                                        <i class="fas fa-comments"></i>
                                        <i class="fas fa-comments light"></i>
                                    </div>
                                </div>
                                <div class="right-part">
                                        <?php the_content(); ?>
                                    <div class="detail">
                                        <h6><?php the_title(); ?></h6>
                                    </div>
                                </div>
                                <div class="quote-icon">
                                    <i class="fas fa-quote-right"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
            </div>
        </div>
    </section>
    <!-- testimonial section end -->
<?php } wp_reset_query();//close if ?>



<?php 
//Generate Cloud Tags
$args = array(
    'post_type'      => array( 'narnoo_attraction','narnoo_accommodation','narnoo_dining', 'narnoo_service', 'destinations', ),
    'post_status'    => array('publish'),
    'post_parent'    => 0
    
);
$terms = new WP_Query( $args );
if( $terms->have_posts() ){
    while ( $terms->have_posts() ) : $terms->the_post();
            $temp_cloud_array = array(
                'label'  => get_the_title(),
                'link'   => get_the_permalink()
            );
            array_push($tag_cloud_array, $temp_cloud_array);
    endwhile;
}
wp_reset_query();
$final_cloud_tag = array();
shuffle($tag_cloud_array);
foreach ($tag_cloud_array as $tag) {
    $t_final = array(
        'text'      => utf8_encode( $tag['label'] ),
        'weight'    => rand(5,15),
        'link'      => $tag['link']
    );
    array_push($final_cloud_tag, $t_final);    
}

?>


<?php

if( is_user_logged_in() ){
$logged     = get_current_user_id();    
$select_sql = "SELECT * FROM noo_product_wishlist WHERE user = $logged";
$dbCheck    = $wpdb->get_results( $select_sql );

if( !empty($dbCheck) ){
    $posts_array = array();
   // if($wpdb->num_rows == 1 ){
     //   array_push($posts_array, $dbCheck->post);
    //}else{

      //  var_dump($dbCheck);

        foreach ($dbCheck as $wl_row) {
           array_push($posts_array, $wl_row->post);
        }
        
   // }
    
}



if(!empty($posts_array)){
    $args = array(
    'post_type'     => array( 'narnoo_product'),
    'post_status'   => array('publish'),
    'post__in'      => $posts_array,
    
    );
    $pw_query = new WP_Query( $args );
}

}

if( !empty($pw_query) && $pw_query->have_posts() ){?>
    <!-- tours section start -->
    <section class="category-sec ratio3_2 section-b-space" style="padding-top:0px; padding-bottom:0px">
        <div class="container">
            <div class="title-1 title-5">
                <h2>Your Product Wishlist</h2>
                <p>Trips, experiences, and places. All in one service.</p>
            </div>
            <?php 
            $count = 1;
            while ( $pw_query->have_posts() ) : $pw_query->the_post();?>
            <?php  
                $temp_cloud_array = array(
                    'label'  => utf8_encode( get_the_title() ),
                    'link'   => get_the_permalink()
                );
                //array_push($tag_cloud_array, $temp_cloud_array);
            ?>
            <?php if ($count%4 == 1){ ?>
            <div class="row">
            <?php } ?>
                <?php $maxPrice           = get_post_meta($post->ID, 'product_min_price',       true); ?>
                <div class="col-xl-3">
                    <a href="<?php echo get_the_permalink( ); ?>">
                        <div class="category-box">
                            <div class="img-category">
                                <?php 
                                $thumbnail = get_the_post_thumbnail_url();
                                ?>
                                <div>
                                    <img src="<?php echo $thumbnail; ?>" alt="" class="img-fluid blur-up lazyload bg-img">
                                </div>
                                <div class="top-bar">
                                    <h5>from $<?php echo $maxPrice;?>*</h5>
                                </div>
                            </div>
                            <div class="content-category">
                                <div class="top">
                                    <h3><?php echo the_title(); ?></h3>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            <?php if ($count%4 == 0){ ?>
            </div>
            <?php } $count++; ?>
            <?php endwhile;  if ($count%4 != 1) echo "</div>"; wp_reset_query(); ?>
        </div>
    </section>
    <!-- tours section end -->
<?php } //close if ?>


    <!-- subscribe section start -->
    <section class="subscribe_section medium-section">
        <div class="container">
            <div class="row">
                <div class="col-xl-5 col-lg-6">
                    <div class="subscribe-detail">
                        <div>
                            <h2>subscribe our news <span>our news</span></h2>
                            <p>Subscribe and receive our newsletters to follow the news about our fresh and fantastic
                                products</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-7 col-lg-6">
                    <div class="input-section">
                        <input type="text" class="form-control" placeholder="Enter Your Email" aria-label="Recipient's username" id="emailAddress">
                        <a href="<?php echo $subLink; ?>" id="noo_email_subscription" class="btn btn-rounded btn-sm color1" data-nonce="<?php echo $subNonce; ?>">subscribe</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- subscribe section end -->
    
</article>

<?php 
//Generate Cloud Tags Script
$script = '<script type="text/javascript">

jQuery(document).ready(function () {

var basic_words = '.json_encode( $final_cloud_tag ).'

jQuery(\'#demo-link\').jQCloud(basic_words,{
  height: 350,
  autoResize: true,
  center:{ x:0.5, y:0.5},
  //colors: ["#800026", "#bd0026", "#e31a1c", "#fc4e2a", "#fd8d3c", "#feb24c", "#fed976", "#ffeda0", "#ffffcc"]
},
);

});';

$script .= '</script>';

add_action( 'wp_footer', function() use( $script ){
        echo $script;
});

$yt_script = '<script type="text/javascript">
jQuery(document).ready(function () {
  jQuery(\'[data-youtube]\').youtube_background();
});';
$yt_script .='</script>';
add_action( 'wp_footer', function() use( $yt_script ){
        echo $yt_script;
});

$grid_script = '<script type="text/javascript">
jQuery(document).ready(function () {
jQuery(\'.grid\').isotope({
        itemSelector: \'.grid-item\',
    });
});';
$grid_script .='</script>';
add_action( 'wp_footer', function() use( $grid_script ){
        echo $grid_script;
});
?>
