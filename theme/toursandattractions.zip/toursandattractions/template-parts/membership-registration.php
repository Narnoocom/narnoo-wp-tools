<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package toursandattractions
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<!-- section start -->
    <section class="section-b-space dark-cls">
        <img src="<?php echo get_stylesheet_directory_uri(); ?>'/assets/images/cab/grey-bg.jpg" alt="" class="img-fluid blur-up lazyload bg-img">
        <div class="container">
            <div class="row">
                <div class="offset-lg-3 col-lg-6 offset-sm-2 col-sm-8 col-12">
                    <div class="account-sign-in">
                        <div class="title">
                            <h3>Register</h3>
                        </div>
                        <form action="<?php echo $_SERVER['REQUEST_URI']; ?>" method="post">
                            <div class="form-group">
                                <label for="name">Username</label>
                                <input type="text" class="form-control" id="username" name="username" placeholder="Enter your name">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Email address</label>
                                <input type="email" class="form-control" id="exampleInputEmail1" name="email" placeholder="Enter email address">
                                <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Password</label>
                                <input type="password" class="form-control" id="exampleInputPassword1" name="password" placeholder="Password">
                                <small id="passwordHelp" class="form-text text-muted">Min 6 characters.</small>
                            </div>
                            <div class="form-group form-check">
                                <input type="checkbox" class="form-check-input" id="exampleCheck1" name="terms" value="yes">
    							<label class="form-check-label" for="exampleCheck1">I agree to the terms of service</label>
                            </div>
                            <div class="button-bottom">
                                <button type="submit" class="w-100 btn btn-solid">create account</button>
                                <div class="divider">
                                    <h6>or</h6>
                                </div>
                                <a href="<?php echo home_url(); ?>/login-page/" class="w-100 btn btn-solid btn-outline" >login</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- section end -->
</article><!-- #post-<?php the_ID(); ?> -->
