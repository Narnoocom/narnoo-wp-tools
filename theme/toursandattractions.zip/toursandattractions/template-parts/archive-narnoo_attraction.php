<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package toursandattractions
 */

$tag_cloud_array    = array();
$op_product_post_id = array();
$op_details_post_id = array();

$range     = array();
$phone     = get_theme_mod( 'home_contact_phone' ); 
$hours     = get_theme_mod( 'noo_contact_opening_hours' );

$phone      = (!empty($phone)) ? $phone : "Store Phone";
$hours      = (!empty($hours)) ? $hours : "Store Hours";

$nonce = wp_create_nonce("noo_ajax_search_nonce");
$link = admin_url('admin-ajax.php?action=noo_product_category_search&nonce='.$nonce);

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?> bere>

	<!--<section class="section-b-space bg-white">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                	<?php
                       the_content();
					?>
            	</div>
            </div>
        </div>
    </section>-->
<?php 
$args = array(
    'post_type'     => array( 'narnoo_attraction'),
    'post_status'   => array('publish'),
    
);
$o_query = new WP_Query( $args );
while ( $o_query->have_posts() ) : $o_query->the_post();
if( $post->post_parent ){
//Do another query to get all the products by this operator ID
    $narnoo_op_id  = get_post_meta($post->ID, 'operator_id',       true);
    if( !empty( $narnoo_op_id ) ){
        array_push($op_product_post_id, $narnoo_op_id);
        $t_opdetails['label']   = get_the_title();
        $t_opdetails['link']    = get_the_permalink();
        $t_opdetails['noo_id']  = $narnoo_op_id;
        array_push($op_details_post_id, $t_opdetails);
    }
    
}
endwhile;
wp_reset_query();
?>
<?php 
if(!empty($op_product_post_id)){
    $pargs = array(
        'post_type'     => array( 'narnoo_product'),
        'post_status'   => array('publish'),
        'meta_key'      => 'narnoo_operator_id',
        'meta_value'    => $op_product_post_id,
        
    );
    $p_query = new WP_Query( $pargs );
}

?>
<?php if( $p_query->have_posts() ){ ?>
    
    <!-- section start -->
    <section class="small-section bg-inner">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="filter-panel right-filter open-cls">
                        <div class="left-filter">
                            <div class="respon-filter-btn ">
                                <h6> filter <i class="fas fa-sort-down"></i></h6>
                                <span class="according-menu"></span>
                            </div>
                            <div class="filters respon-filter-content filter-button-group">
                                <ul>
                                    <li class="active" data-filter="*">All</li>
                                    <!--<li data-filter=".popular">popular</li>
                                    <li data-filter=".latest">latest</li>
                                    <li data-filter=".trend">trend</li>-->
                                </ul>
                            </div>
                        </div>
                       <!-- <div class="right-panel">
                            <a href="javascript:void(0)" class="view-map"><i class="fas fa-search"></i> find tours</a>
                        </div> -->
                    </div>
                </div>
                <div class="col-xl-12 onclick-map">
                    <div class="book-table single-table bg-inner">
                        <div class="table-form classic-form">
                            <form>
                                <div class="row w-100">
                                    <div class="form-group col p-0">
                                        <input type="text" class="form-control" id="exampleFormControlInput1"
                                            placeholder="Starting from">
                                        <img src="<?php echo get_stylesheet_directory_uri();?>/assets/images/icon/table-no.png" class="img-fluid blur-up lazyload"
                                            alt="">
                                    </div>
                                    <div class="form-group col p-0">
                                        <input type="text" class="form-control" placeholder="Going to">
                                        <img src="<?php echo get_stylesheet_directory_uri();?>/assets/images/icon/table-no.png" class="img-fluid blur-up lazyload"
                                            alt="">
                                    </div>
                                </div>
                                <a href="#" class="btn btn-rounded color1">search</a>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="left-sidebar sticky-cls-top">
                        <div class="back-btn">
                            back
                        </div>
                       <!-- <div class="search-bar">
                            <input type="text" placeholder="Search here..">
                            <i class="fas fa-search"></i>
                        </div> -->
                        <div class="middle-part collection-collapse-block open">
                            <a href="javascript:void(0)" class="section-title collapse-block-title">
                                <h5>search filter</h5>
                                <img src="<?php echo get_stylesheet_directory_uri();?>/assets/images/icon/adjust.png" class="img-fluid blur-up lazyload" alt="">
                            </a>
                            <div class="collection-collapse-block-content ">
                                <?php 
                                $args = array(
                                    'post_type'      => array( 'narnoo_attraction','narnoo_accommodation'), //Can add more
                                    'post_status'    => array('publish'),
                                    'post_parent'    => 0
                                    
                                );
                                $subcategory = new WP_Query( $args );


                                    //$nonce = wp_create_nonce("noo_ajax_search_nonce");
                                    //$link = admin_url('admin-ajax.php?action=noo_product_search&nonce='.$nonce);
                                    //echo '<a class="user_like" data-nonce="' . $nonce . '" data-post_id="' . $post->ID . '" href="' . $link . '">Like this Post</a>';
                                
                                ?>
                                <div class="filter-block">
                                    <div class="collection-collapse-block open">
                                        <h6 class="collapse-block-title">Sub Category</h6>
                                        <div class="collection-collapse-block-content">
                                            <div class="collection-brand-filter">
                                            <?php while ( $subcategory->have_posts() ) : $subcategory->the_post(); ?>
                                                <div class="custom-control custom-checkbox collection-filter-checkbox">
                                                   <!-- <input type="checkbox" class="custom-control-input" id="<?php echo get_the_title(); ?>"> -->
                                                    <a href="<?php echo get_the_permalink(); ?>" class="custom-control-label"><?php echo get_the_title(); ?></a>
                                                </div>
                                            <?php  endwhile; wp_reset_query(); ?>   
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--<div class="filter-block">
                                    <div class="collection-collapse-block open">
                                        <h6 class="collapse-block-title">Suppliers</h6>
                                        <div class="collection-collapse-block-content">
                                            <div class="collection-brand-filter">
                                            <?php foreach ( $op_details_post_id as $item) { ?>
                                                <div class="custom-control custom-checkbox collection-filter-checkbox">
                                                   <!-- <input type="checkbox" class="custom-control-input" id="<?php echo get_the_title(); ?>"> 
                                                    <a href="<?php echo $link; ?>" data-nonce="<?php echo $nonce; ?>" data-filter="<?php echo get_the_title(); ?>" data-narnoo="<?php echo $item['noo_id']; ?>" data-business="<?php echo $item['label']; ?>" class="custom-control-label noo_product_search"><?php echo $item['label']; ?></a>
                                                </div>
                                           <?php  } ?>
                                            </div>
                                        </div>
                                    </div>
                                </div> -->
                                <div id="filter-range" class="filter-block">
                                    <div class="collection-collapse-block open">
                                        <h6 class="collapse-block-title">budget</h6>
                                        <div class="collection-collapse-block-content">
                                            <div class="wrapper">
                                                <div class="range-slider">
                                                    <input type="text" class="js-price-range-slider" value="" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                              
                            </div>
                        </div>
                        <div class="bottom-info">
                            <h5><span>i</span> need help</h5>
                            <h4><?php echo $phone; ?></h4>
                            <h6><?php echo $hours; ?></h6>
                        </div>
                    </div>
                </div>
                <!-- product content -->
                <div class="col-lg-9 ratio3_2">
                    <a href="javascript:void(0)" class="mobile-filter border-top-0">
                        <h5>latest filter</h5>
                        <img src="<?php echo get_stylesheet_directory_uri();?>/assets/images/icon/adjust.png" class="img-fluid blur-up lazyload" alt="">
                    </a>
                    <div class="product-wrapper-grid special-section grid-box">
                    <div id="checkVis" class="row content grid"></div>
                        <div id="productSearch" class="row content grid">
                           <?php
                                /*$args = array(
                                    'post_type'     => array( 'narnoo_product'),
                                    'post_status'   => array('publish'),
                                    'meta_key'      => 'noo_destination_select_id',
                                    'meta_value'    => $destination,
                                    
                                );
                                $d_query = new WP_Query( $args );*/
                           ?>
                           <?php //if( $d_query->have_posts() ){?>
                           <?php while ( $p_query->have_posts() ) : $p_query->the_post();?>
                            <?php 
                                $thumbnail          = get_the_post_thumbnail_url();
                                $minPrice           = get_post_meta($post->ID, 'product_min_price',       true); 
                                if(!empty($minPrice)){
                                    array_push($range, (float) $minPrice);
                                }
                            ?>
                            <div data-value="<?php echo $minPrice; ?>"  class="col-xl-4 col-sm-6 latest grid-item wow fadeInUp product-results" data-class="latest">
                                <div class="special-box p-0">
                                    <div class="special-img">
                                    
                                        <a href="<?php echo get_the_permalink( ); ?>">
                                            <img src="<?php echo $thumbnail; ?>"
                                                class="img-fluid blur-up lazyload bg-img" alt="">
                                        </a>
                                        <!--<div class="top-icon">
                                            <a href="#" class="" data-toggle="tooltip" data-placement="top" title=""
                                                data-original-title="Add to Wishlist">
                                                <i class="far fa-heart"></i>
                                            </a>
                                        </div>-->
                                    </div>
                                    <div class="special-content">
                                        <a href="<?php echo get_the_permalink( ); ?>">
                                            <h5><?php echo the_title(); ?> </span></h5>
                                        </a>
                                        <div class="tour-detail">
                                            <?php $check = checkVcEditorContent( get_the_content() ); ?>
                                            <p><?php 
                                            if(!empty($check)){
                                                echo wp_trim_words( wp_strip_all_tags( get_the_excerpt() ), 10, '...' ); 
                                            }else{
                                                echo wp_trim_words( wp_strip_all_tags( get_the_content() ), 10, '...' ); 
                                            }
                                            ?></p>
                                            <div class="bottom-section">
                                                <div class="price">
                                                     <h6>from $<?php echo $minPrice;?>*</h6>
                                                    <span>price per person</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        <?php 
                            endwhile; 
                       // }
                        ?>
                    </div>
                    <div><small><p>*All prices subject to change based on availability and date</p></small></div>
                   <!-- <nav aria-label="Page navigation example" class="pagination-section mt-0">
                        <ul class="pagination">
                            <li class="page-item">
                                <a class="page-link" href="javascript:void(0)" aria-label="Previous">
                                    <span aria-hidden="true">&laquo;</span>
                                    <span class="sr-only">Previous</span>
                                </a>
                            </li>
                            <li class="page-item active"><a class="page-link" href="javascript:void(0)">1</a></li>
                            <li class="page-item"><a class="page-link" href="javascript:void(0)">2</a></li>
                            <li class="page-item"><a class="page-link" href="javascript:void(0)">3</a></li>
                            <li class="page-item">
                                <a class="page-link" href="#" aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                    <span class="sr-only">Next</span>
                                </a>
                            </li>
                        </ul>
                    </nav>-->
                </div>
            </div>
        </div>
    </section>
    <!-- section End -->
    <?php
$args = array(
    'post_type'     => array( 'narnoo_attraction'),
    'post_status'   => array('publish'),
    'post_parent'   => 0,
    
);
$query = new WP_Query( $args );

if( $query->have_posts() ){

    while ( $query->have_posts() ) : $query->the_post();
                $temp_cloud_array = array(
                    'label'  => get_the_title(),
                    'link'   => get_the_permalink()
                );
                array_push($tag_cloud_array, $temp_cloud_array);
    endwhile;

wp_reset_query();
$final_cloud_tag = array();
shuffle($tag_cloud_array);
foreach ($tag_cloud_array as $tag) {
    $t_final = array(
        'text'      => $tag['label'],
        'weight'    => rand(10,15),
        'link'      => $tag['link']
    );
    array_push($final_cloud_tag, $t_final);    
}

?>

    <!-- tag Cloud -->
    <section class="category-sec ratio3_2 section-b-space">
        <div class="container">
            <!--<div class="title-1 title-5">
                <h2>our popular activities</h2>
                <p>Trips, experiences, and places. All in one service.</p>
            </div>-->  
            <div class="row">
                <div class="col-xl-12">
                    <div id="cloud-link" width="100%"></div>
                </div>
            </div>
        </div>
    </section>
    <!-- tag Cloud -->
<?php } //close if ?>

<?php } ?>
</article><!-- #post-<?php the_ID(); ?> -->

<?php 
//Generate Cloud Tags Script
$script = '<script type="text/javascript">

jQuery(document).ready(function () {

var basic_words = '.json_encode( $final_cloud_tag ).'

jQuery(\'#cloud-link\').jQCloud(basic_words,{
  height: 150,
  autoResize: true,
  center:{ x:0.5, y:0.5}
},
);

});';

$script .= '</script>';

add_action( 'wp_footer', function() use( $script ){
        echo $script;
});

?>
<?php 

if(!empty($range)){

$js_script = '';

$js_script = '<script type="text/javascript">

jQuery(function () {

    var $range = jQuery(".js-price-range-slider"),
    $inputFrom = jQuery(".js-input-from"),
    $inputTo = jQuery(".js-input-to"),
    instance,
    min = 0,
    max = '.max( $range ).',
    from = 0,
    to = 0;

    $range.ionRangeSlider({
        type: "double",
        min: min,
        max: max,
        from: 0,
        to: '.max( $range ).',
        prefix: \'$\',
        onStart: updateInputs,
        onChange: updateInputs,
        step: 10,
        prettify_enabled: true,
        prettify_separator: ".",
        values_separator: " - ",
        force_edges: true


    });

    instance = $range.data("ionRangeSlider");

    function updateInputs (data) {
        from    = data.from;
        to      = data.to;

        $inputFrom.prop("value", from);
        $inputTo.prop("value", to); 

        jQuery(".product-results").each(function(index){
          var dataPrice = jQuery(this).attr("data-value");
          if( dataPrice < from ||  dataPrice > to ){
                
            jQuery(this).hide();

        }else{
            jQuery(this).show();
        }
        checkVisible();
    });


    }

    $inputFrom.on("input", function () {
        var val = jQuery(this).prop("value");

    // validate
        if (val < min) {
            val = min;
        } else if (val > to) {
            val = to;
        }

        instance.update({
            from: val
        });
    });

    $inputTo.on("input", function () {
        var val = jQuery(this).prop("value");

    // validate
        if (val < from) {
            val = from;
        } else if (val > max) {
            val = max;
        }

        instance.update({
            to: val
        });
    });

    function checkVisible(){
       var checkVis = jQuery(".product-results:visible").length;
       var checkText = \' <div id="checkRangeVis" class="col-xl-12"><div class="alert alert-info">No products found</div></div>\';
       if(checkVis == 0){
            jQuery("#checkVis").show();
            jQuery("#checkVis").html( checkText );
       }else{
            jQuery("#checkVis").hide();
       }
    }

});';
$js_script .= '</script>';

add_action( 'wp_footer', function() use( $js_script ){
        echo $js_script;
});

}else{
    
    $js_script = '<script type="text/javascript">
    jQuery(function () {
        jQuery("#filter-range").hide();
    });';
    $js_script .= '</script>';
    add_action( 'wp_footer', function() use( $js_script ){
            echo $js_script;
    });
}

?>
