<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package toursandattractions
 */

$paged = (get_query_var('page')) ? get_query_var('page') : 1;
$exclude_posts = array();
//post query.
$args = array(
    'post_type'      => array( 'post'),
    'post_status'    => array('publish'),
    'orderby'        => 'date', 
    'order'          => 'DESC',
    'posts_per_page' => 8,
    'tag_id'            => $wp_query->get_queried_object_id(),
    'paged'          => $paged,
    
);
$query = new WP_Query( $args );
if( $query->have_posts() ){ 
    while ( $query->have_posts() ) : $query->the_post();
    array_push($exclude_posts, $post->ID);
    endwhile;
}

?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
 <!-- blog section start -->
    <section class="section-b-space bg-white">
        <div class="container">
            <div class="row">
                <!-- SIDE BAR -->
                <div class="col-lg-3">
                    <div class="sticky-cls-top">
                        <div class="blog-sidebar">
                           <!--<div class="blog-wrapper">
                                <div class="search-bar">
                                    <input type="text" placeholder="Search here..">
                                    <i class="fas fa-search"></i>
                                </div>
                            </div> -->
                            <?php 
                            $c_args     = array(
                                'orderby'        => 'rand',
                                'posts_per_page' => 6,
                            );
                            $categories = get_categories( $c_args ); ?>
                            <?php if( !empty($categories) ){ ?>
                            <div class="blog-wrapper">
                                <div class="sidebar-title">
                                    <h5>categories</h5>
                                </div>
                                <div class="sidebar-content">
                                    <ul class="sidebar-list">
                                    <?php foreach ($categories as $cat) { ?>
                                        <li class="">
                                            <a href="<?php echo get_category_link( $cat->term_id ); ?>">
                                                <i aria-hidden="true" class="fa fa-angle-right"></i><?php echo $cat->name; ?>
                                            </a>
                                        </li>
                                    <?php } ?>
                                    </ul>
                                </div>
                            </div>
                            <?php wp_reset_query(); } ?>

                            <?php 

                            //post query.
                            $sargs = array(
                                'post_type'      => array( 'post'),
                                'post_status'    => array('publish'),
                                'orderby'        => 'rand', 
                                'posts_per_page' => 4,

                                
                            );
                            if( !empty($exclude_posts) ){
                                $sargs['post__not_in'] = $exclude_posts;
                            }
                            $side_query = new WP_Query( $sargs );

                            ?>
                            <?php if( $side_query->have_posts() ){ ?>
                            <div class="blog-wrapper">
                                <div class="sidebar-title">
                                    <h5>popular post</h5>
                                </div>
                                <div class="sidebar-content">
                                    <ul class="blog-post">
                                         <?php while ( $side_query->have_posts() ) : $side_query->the_post(); ?>
                                          <?php $thumbnail         = get_the_post_thumbnail_url(); ?>
                                        <li>
                                            <a href="<?php echo get_the_permalink(); ?>">
                                            <div class="media">
                                                <img class="img-fluid blur-up lazyload"
                                                    src="<?php echo $thumbnail; ?>"
                                                    alt="Generic placeholder image">
                                                <div class="media-body align-self-center">
                                                    <div>
                                                        <h6><?php echo get_the_date('d M Y'); ?></h6>
                                                        <p><?php echo wp_trim_words( wp_strip_all_tags( get_the_title() ), 4, '...' ); ?></p>
                                                    </div>
                                                </div>
                                            </div>
                                            </a>
                                        </li>
                                         <?php   endwhile; wp_reset_query(); ?>
                                    </ul>
                                </div>
                            </div>
                            <?php } ?>
                            <?php 
                            $t_args     = array(
                                'orderby'        => 'rand',
                                'posts_per_page' => 15,
                            );
                            $tags = get_tags( $t_args );
                            ?>
                            <?php if( !empty($tags) ){ ?>
                            <div class="blog-wrapper">
                                <div class="sidebar-title">
                                    <h5>popular tags</h5>
                                </div>
                                <div class="sidebar-content">
                                    <ul class="tags">
                                        <?php foreach ($tags as $tag) { ?>
                                        <li><a href="<?php echo get_tag_link( $tag->term_id ); ?>"><?php echo $tag->name; ?></a></li>
                                        <?php } ?>
                                    </ul>
                                </div>
                            </div>
                            <?php wp_reset_query(); } ?>
                        </div> 
                    </div>
                </div>
                <!-- CONTENTS AREA -->
                <div class="col-lg-9">
                    <div class="blog_section blog-inner ratio_55">
                        <div class="row">
                          <?php  if( $query->have_posts() ){ while ( $query->have_posts() ) : $query->the_post(); ?>
                            <?php $thumbnail         = get_the_post_thumbnail_url(); ?>
                            <?php $destinationsList  = get_post_meta($post->ID, 'narnoo_blog_destination_id',       true);?>
                        <!-- Blog Post -->
                            <div class="col-md-6">
                                <div class="blog-wrap wow fadeInUp">
                                    <div class="blog-image">
                                        <a href="<?php echo get_the_permalink(); ?>">
                                            <img src="<?php echo $thumbnail;?>"
                                                class="img-fluid blur-up lazyload bg-img" alt="">
                                        </a>
                                        <div class="blog-label">
                                            <div>
                                                <h3><?php echo get_the_date('d'); ?></h3>
                                                <h6><?php echo get_the_date('M'); ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="blog-details">
                                        <?php if(!empty($destinationsList)){ ?>
                                        <h6><i class="fas fa-map-marker-alt"></i><?php echo implode(",", $destinationsList); ?></h6>
                                        <?php } ?>
                                        <a href="<?php echo get_the_permalink(); ?>">
                                            <h5><?php echo get_the_title(); ?> </h5>

                                        </a>
                                        <p><?php echo wp_trim_words( wp_strip_all_tags( get_the_content() ), 10, '...' ); ?></p>
                                    </div>
                                </div>
                            </div>
                            <!-- Blog Post -->
                             <?php   endwhile;  


                             }  // end if

                             $total_pages   = $query->max_num_pages;
                             $current_page  = max(1, get_query_var('page'));

                             wp_reset_query(); ?>
                            
                        </div>
                        <?php if($total_pages > 1){ ?>
                        <div class="row">    
                        <nav aria-label="Page navigation example" class="pagination-section mt-0">

                        <?php 
                            narnoo_pagination( $total_pages );
                        ?>
                        </nav>
                       </div>
                       <?php } ?>
                </div>
            </div>
        </div>
    </section>
    <!-- blog section end -->
</article><!-- #post-<?php the_ID(); ?> -->
