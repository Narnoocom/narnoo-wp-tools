<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package toursandattractions
 */


$logged     = get_current_user_id();
if(empty($logged)){
	header( 'Location:' . home_url('/').'login-page' );
} 
$userData 	     = get_userdata( $logged );
$displayName    = (!empty($userData->display_name)) ? $userData->display_name : $userData->user_login;
$firstName      = (!empty($userData->first_name)) ? $userData->first_name : "First Name";
$lastName       = (!empty($userData->last_name)) ? $userData->last_name : "Last Name";

/*
nickname
first_name
last_name
*/
if(!empty($_GET['e'])){
    $error  = ($_GET['e'] == 'true') ? "Passwords must be 6 characters and must match to the confirmed password" : NULL;
}

$wishnonce   = wp_create_nonce("noo_ajax_wishlist_nonce");
$wishlink    = admin_url('admin-ajax.php?action=noo_product_wishlist_remove&nonce='.$wishnonce);

$bookingnonce   = wp_create_nonce("noo_ajax_booking_nonce");
$bookinglink    = admin_url('admin-ajax.php?action=noo_booking_list&nonce='.$bookingnonce);

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<!-- section start-->
    <section class="small-section dashboard-section bg-inner" data-sticky_parent>
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="pro_sticky_info" data-sticky_column>
                        <div class="dashboard-sidebar">
                            <div class="profile-top">
                            <?php 
                            $avatar = get_avatar_url( $userData->user_email );
                            ?>
                            <?php if(!empty($avatar)){ ?>
                            	<div class="profile-image">
                                    <img src="<?php echo $avatar; ?>" class="img-fluid blur-up lazyload" alt="">
                                </div>
                             <?php } ?>
                                <div class="profile-detail">
                                    <h5><?php echo $userData->user_login; ?></h5>
                                    <p><small><?php echo $userData->user_registered; ?></small></p>
                                    <h6><?php echo $userData->user_email; ?></h6>
                                </div>
                            </div>
                            <div class="faq-tab">
                                <ul class="nav nav-tabs" id="top-tab" role="tablist">
                                    <li class="nav-item"><a data-toggle="tab" class="nav-link active" href="#profile">profile</a></li>
                                    <li class="nav-item"><a data-toggle="tab" class="nav-link" href="#bookmark">wishlist</a></li>
                                    <li class="nav-item"><a id="noo_bookings_load" data-nonce="<?php echo $bookingnonce; ?>" data-toggle="tab" class="nav-link" href="#bookings">bookings</a></li>
                                    <li class="nav-item"><a data-toggle="tab" class="nav-link" href="#security">security</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-9">
                    <div class="product_img_scroll" data-sticky_column>
                        <div class="faq-content tab-content" id="top-tabContent">
                            <div class="tab-pane fade show active" id="profile">
                                <div class="dashboard-box">
                                    <div class="dashboard-title">
                                        <h4>profile</h4>
                                        <span data-toggle="modal" data-target="#edit-profile">edit</span>
                                    </div>
                                    <div class="dashboard-detail">
                                        <ul>
                                        	<li>
                                                <div class="details">
                                                    <div class="left">
                                                        <h6>Username</h6>
                                                    </div>
                                                    <div class="right">
                                                        <h6><?php echo $userData->user_login; ?></h6>
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="details">
                                                    <div class="left">
                                                        <h6>display name</h6>
                                                    </div>
                                                    <div class="right">
                                                        <h6><?php echo $displayName; ?></h6>
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="details">
                                                    <div class="left">
                                                        <h6>first name</h6>
                                                    </div>
                                                    <div class="right">
                                                        <h6><?php echo $firstName; ?></h6>
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="details">
                                                    <div class="left">
                                                        <h6>last name</h6>
                                                    </div>
                                                    <div class="right">
                                                        <h6><?php echo $lastName; ?></h6>
                                                    </div>
                                                </div>
                                            </li>
                                            
                                        </ul>
                                    </div>
                                </div>
                                <div class="dashboard-box">
                                    <div class="dashboard-title">
                                        <h4>login details</h4>
                                    </div>
                                    <?php if(!empty($error)){ ?>
                                    <div class="alert alert-warning"><?php echo $error; ?></div>
                                    <?php } ?>
                                    <div class="dashboard-detail">
                                        <ul>
                                            <li>
                                                <div class="details">
                                                    <div class="left">
                                                        <h6>email address</h6>
                                                    </div>
                                                    <div class="right">
                                                        <p><?php echo $userData->user_email; ?></p>
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="details">
                                                    <div class="left">
                                                        <h6>password</h6>
                                                    </div>
                                                    <div class="right">
                                                        <p>&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;</p>
                                                        <span data-toggle="modal" data-target="#edit-password">edit</span>
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="bookings">
                                <div class="dashboard-box">
                                <div id="customer-booking-details"></div>
                                </div>
                               
                              
                            </div>
                            <div class="tab-pane fade" id="bookmark">
                                <div class="dashboard-box">
                                    <div class="dashboard-title">
                                        <h4>my wishlist</h4>
                                    </div>
                                    <div class="product-wrapper-grid ratio3_2 special-section grid-box">
                                        <div class="row content grid">
                                        <?php 
                                        $select_sql = "SELECT * FROM noo_product_wishlist WHERE user = $logged";
										$dbCheck    = $wpdb->get_results( $select_sql );

										if( !empty($dbCheck) ){
										    $posts_array = array();
										   foreach ($dbCheck as $wl_row) {
										           array_push($posts_array, $wl_row->post);
										    }
										    
										}

										if(!empty($posts_array)){
										    $args = array(
										    'post_type'     => array( 'narnoo_product'),
										    'post_status'   => array('publish'),
										    'post__in'      => $posts_array,
										    
										    );
										    $pw_query = new WP_Query( $args );
										}

                                        ?>
                                        <?php if( !empty($pw_query) && $pw_query->have_posts() ){ ?>
                                        <?php while ( $pw_query->have_posts() ) : $pw_query->the_post(); ?>
                                            <div class="col-xl-4 col-sm-6 grid-item pro-item-<?php echo $post->ID; ?>">
                                                <div class="special-box">
                                                    <div class="special-img">
                                                    <?php 
					                                $thumbnail = get_the_post_thumbnail_url();
					                                ?>
                                                        <a href="<?php echo get_the_permalink(); ?>">
                                                            <img src="<?php echo $thumbnail; ?>" class="img-fluid blur-up lazyload bg-img" alt="">
                                                        </a>
                                                        <div class="content_inner">
                                                            <a href="<?php echo get_the_permalink(); ?>">
                                                                <h5><?php echo the_title(); ?></h5>
                                                            </a>
                                                        </div>
                                                        <div class="top-icon">
                                                            <a href="<?php echo $wishlink; ?>" data-nonce="<?php echo $wishnonce; ?>" class="cls-remove-like" data-product="<?php echo $post->ID; ?>" title="Remove from Wishlist"><i class="fas fa-times"></i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                          <?php endwhile;  wp_reset_query(); }?> 

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="security">
                                <div class="dashboard-box">
                                    <div class="dashboard-title">
                                        <h4>delete your accont</h4>
                                    </div>
                                    <div class="dashboard-detail">
                                        <div class="delete-section">
                                            <p>Hi <span class="text-bold"><?php echo $displayName; ?></span>,</p>
                                            <p>we are sorry to here you would like to delete your account.</p>
                                            <p><span class="text-bold">note:</span></p>
                                            <p>deleting your account will permanently remove your profile, personal
                                                settings, and all other associated information.
                                                once your account is deleted, you will be logged out and will be unable
                                                to log back in.
                                            </p>
                                            <p>if you understand and agree to the above statement, and would still like
                                                to delete your account, than click below</p>
                                            <a href="#" data-toggle="modal" data-target="#delete-account" class="btn btn-solid">delete my account</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- section end-->

    <!-- edit profile modal start -->
    <div class="modal fade edit-profile-modal" id="edit-profile" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Profile</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo $_SERVER['REQUEST_URI']; ?>" method="post">
                <div class="modal-body">
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="first">first name</label>
                                <input type="text" class="form-control" id="first" placeholder="<?php echo $firstName; ?>" name="first_name">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="last">last name</label>
                                <input type="text" class="form-control" id="last" placeholder="<?php echo $lastName; ?>" name="last_name">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="display">Display Name</label>
                                <input type="text" class="form-control" id="display" placeholder="<?php echo $displayName; ?>" name="display_name">
                            </div>
                        </div>
                    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-solid">Save changes</button>
                </div>
                </form>
            </div>
        </div>
    </div>
    <!-- edit profile modal start -->


    


    <!-- edit phone no modal start
    <div class="modal fade edit-profile-modal" id="edit-phone" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">change phone no</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="form-row">
                            <div class="form-group col-12">
                                <label for="ph-o">old phone no</label>
                                <input type="number" class="form-control" id="ph-o">
                            </div>
                            <div class="form-group col-12">
                                <label for="ph-n">enter new phone no</label>
                                <input type="number" class="form-control" id="ph-n">
                            </div>
                            <div class="form-group col-12">
                                <label for="ph-c">confirm your phone no</label>
                                <input type="number" class="form-control" id="ph-c">
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-solid">Save changes</button>
                </div>
            </div>
        </div>
    </div>
    edit phone no modal start -->


    <!-- edit password modal start -->
    <div class="modal fade edit-profile-modal" id="edit-password" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">change email address</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                 <form action="<?php echo $_SERVER['REQUEST_URI']; ?>" method="post">
                <div class="modal-body">
                        <div class="form-row">
                            <div class="form-group col-12">
                                <label for="p-n">enter new password</label>
                                <input type="password" class="form-control" id="p-n" name="new_password">
                            </div>
                            <div class="form-group col-12">
                                <label for="p-c">confirm your password</label>
                                <input type="password" class="form-control" id="p-c" name="confirm_password">
                            </div>
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-solid">Save changes</button>
                </div>
                </form>
            </div>
        </div>
    </div>
    <!-- edit password modal start -->


    <!-- add card modal start -->
    <div class="modal fade edit-profile-modal" id="delete-account" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Account deletion request</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p class="text-dark">Before you leave, please tell us why you'd like to delete your account.
                        This information will help us improve. (optional)</p>
                    <form>
                        <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-solid">delete my account</button>
                </div>
            </div>
        </div>
    </div>
    <!-- edit password modal start -->
</article><!-- #post-<?php the_ID(); ?> -->
