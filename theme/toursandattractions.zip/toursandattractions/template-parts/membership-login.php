<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package toursandattractions
 */
$login_check        = (!empty( $_GET['login'] )) ? TRUE : FALSE;
$registration_check = (!empty( $_GET['u'] )) ? $_GET['u'] : FALSE;
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<!-- section start -->
    <section class="section-b-space dark-cls">
        <img src="<?php echo get_stylesheet_directory_uri(); ?>'/assets/images/cab/grey-bg.jpg" alt="" class="img-fluid blur-up lazyload bg-img">
        <div class="container">
            <div class="row">
                <div class="offset-lg-3 col-lg-6 offset-sm-2 col-sm-8 col-12">
                    <div class="account-sign-in">
                        <div class="title">
                            <h3>Login</h3>
                        </div>
                        <?php if(!empty($login_check)){ ?>
                        <div class="alert alert-warning">Your login username and password is incorrect</div>
                        <?php } ?>
                        <form id="login1" name="form" action="<?php echo home_url(); ?>/login-page/" method="post">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Username</label>
                                <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter username" name="username" <?php echo (!empty($registration_check)) ?  'value="'.$registration_check.'"' : NULL; ?> >
                                
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Password</label>
                                <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password" name="password">
                            </div>
                            <div class="form-group form-check">
                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                <label class="form-check-label" for="exampleCheck1" name="rememberme">remember me</label>
                            </div>
                            <div class="button-bottom">
                                <input class="w-100 btn btn-solid" id="submit" type="submit" name="submit" value="login">
                                <div class="divider">
                                    <h6>or</h6>
                                </div>
                                <a href="<?php echo home_url(); ?>/register/" class="w-100 btn btn-solid btn-outline" >create account</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- section end -->
</article><!-- #post-<?php the_ID(); ?> -->
