<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package toursandattractions
 */
/*
* Load relevant style scripts and stylesheets for this page. [start]
*/
function noo_loadSingleScript(){

    wp_register_script( 'noo-product-category-search', get_template_directory_uri().'/js/ajax_product_search.js', array('jquery','script','lazy'), NULL, TRUE );
    wp_localize_script( 'noo-product-category-search', 'myAjax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));

    wp_enqueue_script("jquery");
    wp_enqueue_script( 'price-range', get_template_directory_uri().'/assets/js/price-range.js' ,  'jquery' , NULL , TRUE);
    wp_enqueue_script( 'wow', get_template_directory_uri().'/assets/js/wow.min.js' ,  'jquery' , NULL , TRUE);
    wp_enqueue_script( 'noo-product-category-search' );
    
}
add_action( 'wp_enqueue_scripts', 'noo_loadSingleScript' );

get_header();

$thumbnail = get_the_post_thumbnail_url(NULL, 'page-header');
$args = array(
    'post_type'     => array( 'narnoo_attraction'),
    'post_status'   => array('publish'),
    'post_parent'   => 0,
    'orderby'        => 'menu_order', 
    'order'          => 'ASC',
    
);
$m_query = new WP_Query( $args ); 
?>
<!-- breadcrumb start -->
    <section class="order-food-section  pt-0">
        <img src="<?php echo $thumbnail;?>" class="bg-img img-fluid blur-up lazyload" alt="">
        <div class="order-food">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <div class="book-table section-b-space p-0 single-table">
                            <h3>Find more tours and attractions here</h3>
                            <div class="table-form">
                                <form>
                                    <div class="row w-100">
                                <div class="form-group col p-0">
                                    <div class="suggestion_box">
                                        <div class="form-group">
                                            <input type="text" class="form-control open-select" placeholder="Select an Activity">
                                            <div class="selector-box">
                                                <h6 class="title">popular activities</h6>
                                                <ul>
                                                <?php  if( $m_query->have_posts() ){ while ( $m_query->have_posts() ) : $m_query->the_post(); ?>

                                                    <li>
                                                        <a href="<?php echo get_the_permalink(); ?>">
                                                            <h5><?php echo get_the_title(); ?></h5>
                                                        </a>
                                                    </li>

                                                <?php   endwhile;  } wp_reset_query(); ?>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- breadcrumb end -->
<main id="primary" class="site-main">

	<?php
		get_template_part( 'template-parts/content', 'narnoo_attraction' );
	?>

</main><!-- #main -->

<?php
get_footer();
?>
