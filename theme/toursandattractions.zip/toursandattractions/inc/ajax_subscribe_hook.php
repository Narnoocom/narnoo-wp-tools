<?php // used here only for enabling syntax highlighting. Leave this out if it's already included in your plugin file.

global $post;

// define the actions for the two hooks created, first for logged in users and the next for logged out users
add_action("wp_ajax_noo_email_subscribe", "noo_email_subscribe");
add_action("wp_ajax_nopriv_noo_email_subscribe", "noo_email_subscribe");

// define the function to be fired for logged in users
function noo_email_subscribe() {
   global $wpdb;
   // nonce check for an extra layer of security, the function will exit if it fails
   if ( !wp_verify_nonce( $_REQUEST['nonce'], "noo_email_subscribe_nonce")) {
      die();
   } 

   
     $email     = $_REQUEST["email"]; //subcategory
    
     $select_sql  = "SELECT * FROM noo_email_list WHERE email = '$email'";
     $rowCheck    = $wpdb->get_row( $select_sql );
     if(empty($rowCheck)){

        $wpdb->insert( 
            'noo_email_list', 
            array( 
              'email'    => $email
            ), 
            array( 
              '%s'
            ) 
          );
        $result['type']   = 'success';
        $text = "Thanks for saving to our subscribe list";
        $result['output'] = $text;
     
     }else{
      
        $result['type']   = 'error';
        $text = "Your email is already in our subscribe list";
        $result['output'] = $text;
     
     }


   

   // Check if action was fired via Ajax call. If yes, JS code will be triggered, else the user is redirected to the post page
   if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
      $result = json_encode($result);
      echo $result;
   }
   
   die();
}




