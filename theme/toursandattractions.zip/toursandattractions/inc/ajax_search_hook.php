<?php // used here only for enabling syntax highlighting. Leave this out if it's already included in your plugin file.

global $post;
// define the actions for the two hooks created, first for logged in users and the next for logged out users
add_action("wp_ajax_noo_product_search", "noo_product_search");
add_action("wp_ajax_nopriv_noo_product_search", "noo_product_search");

// define the function to be fired for logged in users
function noo_product_search() {
   
   // nonce check for an extra layer of security, the function will exit if it fails
   if ( !wp_verify_nonce( $_REQUEST['nonce'], "noo_ajax_search_nonce")) {
      die();
   } 

   $text = '';

   //Get information from the request
   $type       = $_REQUEST["type"];
   $filter     = $_REQUEST["filter"];
   $location   = (!empty($_REQUEST["loc"])) ? $_REQUEST["loc"] : NULL;

   $args = array(
    'post_type'      => array( 'narnoo_product'),
    'post_status'    => array('publish'),
    'meta_query' => array(
        array(
            'key'     => 'noo_destination_select_id',
            'value'   => $location,
        ),
        array(
            'key'     => 'narnoo_listing_subcategory',
            'value'   => $filter,
        ),
    ),
   );




   $query = new WP_Query( $args );

   if( $query->have_posts() ){

      while ( $query->have_posts() ) : $query->the_post();
        $maxPrice           = get_post_meta(get_the_ID(), 'product_min_price',       true);
        $text .= '<div class="col-xl-4 col-sm-6 latest grid-item wow fadeInUp product-results" data-value="'.$maxPrice.'" data-class="latest">
              <div class="special-box p-0">
                  <div class="special-img">';
                  
                      $thumbnail = get_the_post_thumbnail_url();
                 
                      $text .= '<a href="'.get_the_permalink().'">
                          <img src="'.$thumbnail.'"
                              class="img-fluid blur-up lazyload bg-img" alt="">
                      </a>
                      <!--<div class="top-icon">
                          <a href="#" class="" data-toggle="tooltip" data-placement="top" title=""
                              data-original-title="Add to Wishlist">
                              <i class="far fa-heart"></i>
                          </a>
                      </div>-->
                  </div>
                  <div class="special-content">
                      <a href="'.get_the_permalink().'">
                          <h5>'.get_the_title().'</span></h5>
                      </a>
                      <div class="tour-detail">
                          <div>
                              <p>'.wp_trim_words( wp_strip_all_tags( get_the_content() ), 10, '...' ).'</p>
                          </div>
                          <div class="bottom-section">
                              <div class="price"> ';
                                  $text .= '<h6>from $'.$maxPrice.'*</h6>
                                  <span>price per person</span>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>';

      endwhile;

      $result['type']   = 'success';
      $result['output'] = $text;

      wp_reset_query();
   }else{


      $result['type']   = 'success';
      $result['output'] = ' <div class="col-xl-12"><div class="alert alert-info">No products found</div></div>';

   }

   
   // Check if action was fired via Ajax call. If yes, JS code will be triggered, else the user is redirected to the post page
   if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
      $result = json_encode($result);
      echo $result;
   }
   //else {
    //  header("Location: ".$_SERVER["HTTP_REFERER"]);
  // }

   // don't forget to end your scripts with a die() function - very important
   die();
}




// define the actions for the two hooks created, first for logged in users and the next for logged out users
add_action("wp_ajax_noo_product_category_search", "noo_product_category_search");
add_action("wp_ajax_nopriv_noo_product_category_search", "noo_product_category_search");

// define the function to be fired for logged in users
function noo_product_category_search() {
   
   // nonce check for an extra layer of security, the function will exit if it fails
   if ( !wp_verify_nonce( $_REQUEST['nonce'], "noo_ajax_search_nonce")) {
      die();
   } 

   $text = '';

   //Get information from the request
   
   //supplier ID.
   //sub_category


   $type       = $_REQUEST["type"];
   $filter     = $_REQUEST["filter"]; //subcategory
   $noo_id     = (!empty($_REQUEST["noo"])) ? $_REQUEST["noo"] : NULL;

   $args = array(
    'post_type'      => array( 'narnoo_product'),
    'post_status'    => array('publish'),
    'meta_query' => array(
        array(
            'key'     => 'narnoo_operator_id',
            'value'   => $noo_id,
        ),
        array(
            'key'     => 'narnoo_listing_subcategory',
            'value'   => $filter,
        ),
    ),
   );




   $query = new WP_Query( $args );

   if( $query->have_posts() ){

      while ( $query->have_posts() ) : $query->the_post();
        $maxPrice           = get_post_meta(get_the_ID(), 'product_min_price',       true);
        $text .= '<div class="col-xl-4 col-sm-6 latest grid-item wow fadeInUp product-results" data-value="'.$maxPrice.'" data-class="latest">
              <div class="special-box p-0">
                  <div class="special-img">';
                  
                      $thumbnail = get_the_post_thumbnail_url();
                 
                      $text .= '<a href="'.get_the_permalink().'">
                          <img src="'.$thumbnail.'"
                              class="img-fluid blur-up lazyload bg-img" alt="">
                      </a>
                      <!--<div class="top-icon">
                          <a href="#" class="" data-toggle="tooltip" data-placement="top" title=""
                              data-original-title="Add to Wishlist">
                              <i class="far fa-heart"></i>
                          </a>
                      </div>-->
                  </div>
                  <div class="special-content">
                      <a href="'.get_the_permalink().'">
                          <h5>'.get_the_title().'</span></h5>
                      </a>
                      <div class="tour-detail">
                          <div>
                              <p>'.wp_trim_words( wp_strip_all_tags( get_the_content() ), 10, '...' ).'</p>
                          </div>
                          <div class="bottom-section">
                              <div class="price"> ';
                                  $text .= '<h6>from $'.$maxPrice.'*</h6>
                                  <span>price per person</span>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>';

      endwhile;

      $result['type']   = 'success';
      $result['output'] = $text;

      wp_reset_query();
   }else{


      $result['type']   = 'success';
      $result['output'] = ' <div class="col-xl-12"><div class="alert alert-info">No products found</div></div>';

   }

   
   // Check if action was fired via Ajax call. If yes, JS code will be triggered, else the user is redirected to the post page
   if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
      $result = json_encode($result);
      echo $result;
   }
   //else {
    //  header("Location: ".$_SERVER["HTTP_REFERER"]);
  // }

   // don't forget to end your scripts with a die() function - very important
   die();
}


// define the actions for the two hooks created, first for logged in users and the next for logged out users
add_action("wp_ajax_noo_product_wishlist", "noo_product_wishlist");
add_action("wp_ajax_nopriv_noo_product_wishlist", "noo_product_wishlist");

// define the function to be fired for logged in users
function noo_product_wishlist() {
   global $wpdb;
   // nonce check for an extra layer of security, the function will exit if it fails
   if ( !wp_verify_nonce( $_REQUEST['nonce'], "noo_ajax_wishlist_nonce")) {
      die();
   } 

   if( is_user_logged_in() ){
    $logged = get_current_user_id();

    //is user logged in
     $product     = $_REQUEST["product"]; //subcategory
    
     $select_sql  = "SELECT * FROM noo_product_wishlist WHERE user = $logged AND post = $product";
     $rowCheck    = $wpdb->get_row( $select_sql );
     if(empty($rowCheck)){

        $wpdb->insert( 
            'noo_product_wishlist', 
            array( 
              'user'    => $logged, 
              'post'    => $product 
            ), 
            array( 
              '%d', 
              '%d' 
            ) 
          );
        $text = "Saved to wishlist";
     
     }else{
     
        $text = "Product already in your wishlist";
     
     }


   }else{
    
    $text = "Please create an account";
   
   }


   $result['type']   = 'success';
   $result['output'] = $text;

   // Check if action was fired via Ajax call. If yes, JS code will be triggered, else the user is redirected to the post page
   if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
      $result = json_encode($result);
      echo $result;
   }
   
   die();
}


// define the actions for the two hooks created, first for logged in users and the next for logged out users
add_action("wp_ajax_noo_product_wishlist_remove", "noo_product_wishlist_remove");
add_action("wp_ajax_nopriv_noo_product_wishlist_remove", "noo_product_wishlist_remove");

// define the function to be fired for logged in users
function noo_product_wishlist_remove() {
   global $wpdb;
   // nonce check for an extra layer of security, the function will exit if it fails
   if ( !wp_verify_nonce( $_REQUEST['nonce'], "noo_ajax_wishlist_nonce")) {
      die();
   } 

   if( is_user_logged_in() ){
    $logged = get_current_user_id();

    //is user logged in
     $product     = $_REQUEST["product"]; //subcategory
     $select_sql  = "SELECT * FROM noo_product_wishlist WHERE user = $logged AND post = $product";
     $rowCheck    = $wpdb->get_row( $select_sql );
     if(!empty($rowCheck)){

        $wpdb->delete( 
            'noo_product_wishlist', 
            array( 
              'user'    => $logged, 
              'post'    => $product 
            ), 
            array( 
              '%d', 
              '%d' 
            ) 
          );
        $text = "Removed from wishlist";
     
     }else{
     
        $text = "Product not in your wishlist";
     
     }
     $result['type']   = 'success';

   }else{
   
    $result['type']   = 'error';
    $text = "Please create an account";
   
   }


   
   $result['output'] = $text;

   // Check if action was fired via Ajax call. If yes, JS code will be triggered, else the user is redirected to the post page
   if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
      $result = json_encode($result);
      echo $result;
   }
   
   die();
}





