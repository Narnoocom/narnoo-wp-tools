<?php
/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package toursandattractions
 */

/**
 * Imports the main CSS files.
 *
 */

function noo_loadScripts(){
wp_enqueue_script("jquery");
wp_enqueue_script( 'script', get_template_directory_uri().'/assets/js/script.js' , array('jquery','slick'), NULL , TRUE);
wp_enqueue_script( 'slick', get_template_directory_uri().'/assets/js/slick.js' , 'jquery' , NULL , TRUE );
wp_enqueue_script( 'bootstrap', get_template_directory_uri().'/assets/js/bootstrap.js', 'jquery' , NULL , TRUE );
wp_enqueue_script( 'lazy', get_template_directory_uri().'/assets/js/lazysizes.min.js', 'jquery' , NULL , TRUE );
wp_enqueue_script( 'toast', get_template_directory_uri().'/assets/js/jquery.toast.min.js', 'jquery' , NULL , TRUE );
}
// Add the functions to WP loading list.
add_action( 'wp_enqueue_scripts', 'noo_loadScripts' );