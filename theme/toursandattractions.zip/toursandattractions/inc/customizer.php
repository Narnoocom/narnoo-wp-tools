<?php
/**
 * toursandattractions Theme Customizer
 *
 * @package toursandattractions
 */

/**
 * Script to import Kirki customizer.
 */
require get_template_directory() . '/inc/kirki/kirki.php';

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function toursandattractions_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';
	$wp_customize->get_setting( 'custom_logo' )->transport = 'postMessage';

	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial(
			'blogname',
			array(
				'selector'        => '.site-title a',
				'render_callback' => 'toursandattractions_customize_partial_blogname',
			)
		);
		$wp_customize->selective_refresh->add_partial(
			'blogdescription',
			array(
				'selector'        => '.site-description',
				'render_callback' => 'toursandattractions_customize_partial_blogdescription',
			)
		);
	}
}
add_action( 'customize_register', 'toursandattractions_customize_register' );

/**
 * Render the site title for the selective refresh partial.
 *
 * @return void
 */
function toursandattractions_customize_partial_blogname() {
	bloginfo( 'name' );
}

/**
 * Render the site tagline for the selective refresh partial.
 *
 * @return void
 */
function toursandattractions_customize_partial_blogdescription() {
	bloginfo( 'description' );
}

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function toursandattractions_customize_preview_js() {
	wp_enqueue_script( 'toursandattractions-customizer', get_template_directory_uri() . '/js/customizer.js', array( 'customize-preview' ), '20151215', true );
}
add_action( 'customize_preview_init', 'toursandattractions_customize_preview_js' );

/*
*
*		Deal with customizer library
*
*/
//Configure
Kirki::add_config( 'toursandattractions_customizer', array(
	'capability'    => 'edit_theme_options',
	'option_type'   => 'theme_mod',
) );


/*
* Managing social media channels for the icon section - start
*/
Kirki::add_panel( 'noo_social', array(
    'priority'    => 100,
    'title'       => esc_html__( 'Social Media', 'toursandattractions' ),
    'description' => esc_html__( 'Your social media account information', 'toursandattractions' ),
) );
Kirki::add_section( 'noo_social_section', array(
    'title'          => esc_html__( 'Social Media Accounts', 'toursandattractions' ),
    'description'    => esc_html__( 'Enter information for these social media accounts.', 'toursandattractions' ),
    'panel'          => 'noo_social',
    'priority'       => 160,
) );
Kirki::add_field( 'toursandattractions_customizer', [
	'type'     => 'text',
	'settings' => 'noo_facebook_link',
	'label'    => esc_html__( 'Facebook Link', 'toursandattractions' ),
	'section'  => 'noo_social_section',
	'default'  => esc_html__( 'https://www.facebook.com/link', 'toursandattractions' ),
	'priority' => 10,
] );
Kirki::add_field( 'toursandattractions_customizer', [
	'type'     => 'text',
	'settings' => 'noo_instagram_link',
	'label'    => esc_html__( 'Instgram Link', 'toursandattractions' ),
	'section'  => 'noo_social_section',
	'default'  => esc_html__( 'https://www.instagram.com/link', 'toursandattractions' ),
	'priority' => 10,
] );
Kirki::add_field( 'toursandattractions_customizer', [
	'type'     => 'text',
	'settings' => 'noo_twitter_link',
	'label'    => esc_html__( 'Twitter Link', 'toursandattractions' ),
	'section'  => 'noo_social_section',
	'default'  => esc_html__( 'https://www.twitter.com/link', 'toursandattractions' ),
	'priority' => 10,
] );
Kirki::add_field( 'toursandattractions_customizer', [
	'type'     => 'text',
	'settings' => 'noo_youtube_link',
	'label'    => esc_html__( 'YouTube Link', 'toursandattractions' ),
	'section'  => 'noo_social_section',
	'default'  => esc_html__( 'https://www.youtube.com/link', 'toursandattractions' ),
	'priority' => 10,
] );
/*
* Managing social media channels for the icon section - end
*/

/*
*
*/
/*
* Managing social media channels for the icon section - start
*/
Kirki::add_panel( 'noo_home_bg', array(
    'priority'    => 100,
    'title'       => esc_html__( 'Home Page', 'toursandattractions' ),
    'description' => esc_html__( 'Manage Home Page Items', 'toursandattractions' ),
) );
//Items:
//Main hero image
Kirki::add_section( 'noo_home_section', array(
    'title'          => esc_html__( 'Home Page Media', 'toursandattractions' ),
    'description'    => esc_html__( 'This information manages your home page media', 'toursandattractions' ),
    'panel'          => 'noo_home_bg',
    'priority'       => 160,
) );
Kirki::add_field( 'noo_home_bd_id', [
	'type'        => 'image',
	'settings'    => 'home_bg_setting_url',
	'label'       => esc_html__( 'Home Page Image', 'toursandattractions' ),
	'description' => esc_html__( 'The background image that is set on your home page.', 'toursandattractions' ),
	'section'     => 'noo_home_section',
	'default'     => '',
] );
Kirki::add_field( 'noo_home_video_id', [
	'type'     => 'text',
	'settings' => 'home_bg_video_url',
	'label'    => esc_html__( 'YouTube Video Background', 'toursandattractions' ),
	'description' => esc_html__( 'The you can set a YouTube video as your home page background.', 'toursandattractions' ),
	'section'  => 'noo_home_section',
	'default'  => '',
	//'priority' => 9,
] );
Kirki::add_field( 'home_media_switch_id', [
	'type'        => 'switch',
	'settings'    => 'media_select_id',
	'label'       => esc_html__( 'Turn the video on', 'toursandattractions' ),
	'section'     => 'noo_home_section',
	'default'     => '1',
	//'priority'    => 10,
	'choices'     => [
		'on'  => esc_html__( 'Display', 'toursandattractions' ),
		'off' => esc_html__( 'Hide', 'toursandattractions' ),
	],
] );
//Editor
Kirki::add_section( 'noo_home_editor', array(
    'title'          => esc_html__( 'Home Page CTA', 'toursandattractions' ),
    'description'    => esc_html__( 'This information manages your home page CTA', 'toursandattractions' ),
    'panel'          => 'noo_home_bg',
    'priority'       => 160,
) );
Kirki::add_field( 'noo_home_cta_bd_id', [
	'type'        => 'image',
	'settings'    => 'home_cta_bg_setting_url',
	'label'       => esc_html__( 'Home CTA Page Image', 'toursandattractions' ),
	'description' => esc_html__( 'The background image that is set on your CTA home page.', 'toursandattractions' ),
	'section'     => 'noo_home_editor',
	'default'     => '',
] );
Kirki::add_field( 'noo_home_editor_id', [
	'type'        => 'editor',
	'settings'    => 'home_editor_setting',
	'label'       => esc_html__( 'Home Page CTA Editor', 'toursandattractions' ),
	'description' => esc_html__( 'The information to go in your hoome page about us.', 'toursandattractions' ),
	'section'     => 'noo_home_editor',
	'default'     => '',
] );
Kirki::add_field( 'noo_home_cta_id', [
	'type'     => 'text',
	'settings' => 'home_cta_cta_setting',
	'label'    => esc_html__( 'CTA Catch', 'toursandattractions' ),
	'section'  => 'noo_home_editor',
	'default'  => esc_html__( 'This the catch phrase', 'toursandattractions' ),
	'priority' => 9,
] );
Kirki::add_field( 'noo_home_cta_vimg_id', [
	'type'        => 'image',
	'settings'    => 'home_cta_video_bg_setting_url',
	'label'       => esc_html__( 'Home CTA Video Image', 'toursandattractions' ),
	'description' => esc_html__( 'The background image that supports the video frame.', 'toursandattractions' ),
	'section'     => 'noo_home_editor',
	'default'     => '',
] );
Kirki::add_field( 'noo_home_video_id', [
	'type'     => 'text',
	'settings' => 'home_cta_video_setting',
	'label'    => esc_html__( 'Video Embed Link', 'toursandattractions' ),
	'section'  => 'noo_home_editor',
	'default'  => esc_html__( 'This is for your video embed link', 'toursandattractions' ),
	'priority' => 10,
] );
Kirki::add_field( 'noo_home_link_id', [
	'type'     => 'text',
	'settings' => 'home_cta_link_setting',
	'label'    => esc_html__( 'CTA Link', 'toursandattractions' ),
	'section'  => 'noo_home_editor',
	'default'  => esc_html__( 'This a link for this page to navigate to', 'toursandattractions' ),
	'priority' => 11,
] );
Kirki::add_field( 'home_editor_switch_id', [
	'type'        => 'switch',
	'settings'    => 'cta_select_id',
	'label'       => esc_html__( 'Hide this section', 'toursandattractions' ),
	'section'     => 'noo_home_editor',
	'default'     => '1',
	'priority'    => 12,
	'choices'     => [
		'on'  => esc_html__( 'Display', 'toursandattractions' ),
		'off' => esc_html__( 'Hide', 'toursandattractions' ),
	],
] );


/*
* Managing archive pages
*/
Kirki::add_panel( 'noo_archive_bg', array(
    'priority'    => 100,
    'title'       => esc_html__( 'Archive Pages', 'toursandattractions' ),
    'description' => esc_html__( 'Manage Archive Pages', 'toursandattractions' ),
) );
//Items:
//Main hero image
Kirki::add_section( 'noo_archive_section', array(
    'title'          => esc_html__( 'Destination Archive Page', 'toursandattractions' ),
    'description'    => esc_html__( 'This information manages your destiantion archive page', 'toursandattractions' ),
    'panel'          => 'noo_archive_bg',
    'priority'       => 160,
) );
Kirki::add_field( 'noo_destination_archive_bd_id', [
	'type'        => 'image',
	'settings'    => 'destination_header_archive_url',
	'label'       => esc_html__( 'Page Header Image', 'toursandattractions' ),
	'description' => esc_html__( 'The background image that is set on your destination archive page.', 'toursandattractions' ),
	'section'     => 'noo_archive_section',
	'default'     => '',
] );
//Main hero image
Kirki::add_section( 'noo_archive_attraction_section', array(
    'title'          => esc_html__( 'Attraction Archive Page', 'toursandattractions' ),
    'description'    => esc_html__( 'This information manages your attraction archive page', 'toursandattractions' ),
    'panel'          => 'noo_archive_bg',
    'priority'       => 160,
) );
Kirki::add_field( 'noo_attraction_archive_bd_id', [
	'type'        => 'image',
	'settings'    => 'attraction_header_archive_url',
	'label'       => esc_html__( 'Page Header Image', 'toursandattractions' ),
	'description' => esc_html__( 'The background image that is set on your attraction archive page.', 'toursandattractions' ),
	'section'     => 'noo_archive_attraction_section',
	'default'     => '',
] );
Kirki::add_section( 'noo_archive_blog_section', array(
    'title'          => esc_html__( 'Latest Blog Header Image', 'toursandattractions' ),
    'description'    => esc_html__( 'This information manages your blog listings page', 'toursandattractions' ),
    'panel'          => 'noo_archive_bg',
    'priority'       => 160,
) );
Kirki::add_field( 'noo_blog_blog_bd_id', [
	'type'        => 'image',
	'settings'    => 'latest_header_blog_url',
	'label'       => esc_html__( 'Blog Header Image', 'toursandattractions' ),
	'description' => esc_html__( 'The background image that is set on your lastest blog page.', 'toursandattractions' ),
	'section'     => 'noo_archive_blog_section',
	'default'     => '',
] );

/*
* Managing archive pages
*/
Kirki::add_panel( 'noo_contacts_', array(
    'priority'    => 80,
    'title'       => esc_html__( 'Contact Details', 'toursandattractions' ),
    'description' => esc_html__( 'Manage Contact Details', 'toursandattractions' ),
) );
//Items:
//Main hero image
Kirki::add_section( 'noo_contact_section', array(
    'title'          => esc_html__( 'Contact Information', 'toursandattractions' ),
    'description'    => esc_html__( 'This information manages your contact information', 'toursandattractions' ),
    'panel'          => 'noo_contacts_',
    'priority'       => 100,
) );
Kirki::add_field( 'noo_contact_phone_id', [
	'type'     => 'text',
	'settings' => 'home_contact_phone',
	'label'    => esc_html__( 'Phone Number', 'toursandattractions' ),
	'section'  => 'noo_contact_section',
	//'default'  => esc_html__( 'This a link for this page to navigate to', 'toursandattractions' ),
	'priority' => 11,
] );
Kirki::add_field( 'noo_contact_email_id', [
	'type'     => 'text',
	'settings' => 'home_contact_email',
	'label'    => esc_html__( 'Support Email', 'toursandattractions' ),
	'section'  => 'noo_contact_section',
	//'default'  => esc_html__( 'This a link for this page to navigate to', 'toursandattractions' ),
	'priority' => 12,
] );
Kirki::add_field( 'noo_contact_opening_hours_id', [
	'type'     => 'textarea',
	'settings' => 'noo_contact_opening_hours',
	'label'    => esc_html__( 'Opening Hours', 'toursandattractions' ),
	'section'  => 'noo_contact_section',
	//'default'  => esc_html__( 'This is a default value', 'toursandattractions' ),
	'priority' => 13,
] );


