<?php

add_action('add_meta_boxes', 	'add_destination_meta_box');
add_action( 'save_post', 		'save_destination_meta_box');
/*
*
*	title: Narnoo add narnoo album to a page
*	date created: 15-09-16
*/
function add_destination_meta_box()
{

            add_meta_box(
                'noo-destination-box-class',      						// Unique ID
			    'Select A Destination', 		 		    			// Title
			    'box_display_destination_information',   				// Callback function
			    array('narnoo_product'),         						// Admin page (or post type)
			    'side',         										// Context
			    'low'         											// Priority
             );

}

/*
*
*	title: Display the album select box
*	date created: 15-09-16
*/
function box_display_destination_information( $post )
{

global $post;
$backup = $post; //store the original post data so we can continue on after the wp_query used later on.
$selected = get_post_meta($post->ID,'noo_destination_select_id',true);



// We'll use this nonce field later on when saving.
wp_nonce_field( 'destination_meta_box_nonce', 'box_display_destination_information_nonce' );

	//WORDPRESS Query here.
$m_args = array(
	'post_type' 	=> array( 'destinations'),
	'post_status'	=> array('publish'),
    'orderby'       =>'menu_order', 
    'order'         => 'ASC',
);
$menu_d_query       = new WP_Query( $m_args );	


?><p>
    <label for="my_meta_box_select">Destination:</label>
    <select name="noo_destination_select" id="noo_destination_select">
    	<option value="">None</option>
        <?php if( $menu_d_query->have_posts() ){ ?>
        		<?php 
                while ( $menu_d_query->have_posts() ) : $menu_d_query->the_post(); 

                ?>
        			<option value="<?php echo the_title(); ?>" <?php selected( $selected, get_the_title()); ?>><?php echo ucwords( the_title() ); ?></option>
        		<?php endwhile; $menu_d_query->reset_postdata(); $post = $backup;  ?>
        <?php } ?>
    </select>
    <p><small><em>Select an destination to set for this product.</em></small></p>
</p>
<?php

}

function save_destination_meta_box( $post_id ){

	// Bail if we're doing an auto save
    if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

    // if our nonce isn't there, or we can't verify it, bail
    if( !isset( $_POST['box_display_destination_information_nonce'] ) || !wp_verify_nonce( $_POST['box_display_destination_information_nonce'], 'destination_meta_box_nonce' ) ) return;

    // if our current user can't edit this post, bail
    if( !current_user_can( 'edit_post' ) ) return;

    if( isset( $_POST['noo_destination_select'] ) ){
    	update_post_meta( $post_id, 'noo_destination_select_id', esc_attr( $_POST['noo_destination_select'] ) );
	}

}


add_action( 'cmb2_admin_init', 'narnoo_highlight_subheading' );
function narnoo_highlight_subheading() {

    // Start with an underscore to hide fields from custom fields list
    $prefix = 'narnoo_';

    /*
     * Initiate the metabox
     */
    $cmb = new_cmb2_box( array(
        'id'            => 'highlight_sub_heading',
        'title'         => __( 'Highlight sub heading', 'toursandattractions' ),
        'object_types'  => array( 'highlight' ), // Post type
        //'context'       => 'side',
        'priority'      => 'low',
        'show_names'    => true,
    ) );

    $cmb->add_field( array(
    'name' => 'Set a sub heading for this highlight',
    //'desc' => 'Check to set product (optional)',
    'id'   => $prefix.'highlight_subheading',
    'type' => 'text_medium',
    ) );

}

add_action( 'cmb2_admin_init', 'narnoo_highlight_link' );
function narnoo_highlight_link() {

    // Start with an underscore to hide fields from custom fields list
    $prefix = 'narnoo_';

    /*
     * Initiate the metabox
     */
    $cmb = new_cmb2_box( array(
        'id'            => 'highlight_link',
        'title'         => __( 'Highlight link', 'toursandattractions' ),
        'object_types'  => array( 'highlight' ), // Post type
        //'context'       => 'side',
        'priority'      => 'low',
        'show_names'    => true,
    ) );

    $cmb->add_field( array(
    'name' => 'Set a manual link for this highlight',
    'desc' => 'If set this link will overide the link to this page. (optional)',
    'id'   => $prefix.'highlight_link',
    'type' => 'text_medium',
    ) );

}


add_action( 'cmb2_admin_init', 'narnoo_post_destinations_list' );
function narnoo_post_destinations_list() {

    $destinationListArray = [];
       //WordPress Query
    $dxargs = array(
    'post_type'     => array( 'destinations'),
    'post_status'   => array('publish'),
    'orderby'       => 'menu_order', 
    'order'         => 'ASC',
    
    );
    $dx_query = new WP_Query( $dxargs );
    if( $dx_query->have_posts() ){
        while ( $dx_query->have_posts() ) : $dx_query->the_post();
        $destinationListArray[get_the_title()] = get_the_title();
        endwhile;
        wp_reset_query();
    }

    // Start with an underscore to hide fields from custom fields list
    $prefix = 'narnoo_';

    /*
     * Initiate the metabox
     */
    $cmb = new_cmb2_box( array(
        'id'            => 'blog_destination_list',
        'title'         => __( 'Destination Link', 'toursandattractions' ),
        'object_types'  => array( 'post' ), // Post type
        'context'       => 'side',
        'priority'      => 'low',
        'show_names'    => true,
    ) );

    $cmb->add_field( array(
    'name'    => 'Destination Link Checkbox',
    'desc'    => 'Select any destinations that match this post',
    'id'      => $prefix.'blog_destination_id',
    'type'    => 'multicheck',
    'options' => $destinationListArray,
    ) );

}

add_action( 'cmb2_admin_init', 'narnoo_post_product_list' );
function narnoo_post_product_list() {

    // Start with an underscore to hide fields from custom fields list
    $prefix = 'narnoo_';

    /*
     * Initiate the metabox
     */
    $cmb = new_cmb2_box( array(
        'id'            => 'post_product_list',
        'title'         => __( 'Products In Post', 'toursandattractions' ),
        'object_types'  => array( 'post' ), // Post type
        'context'       => 'side',
        'priority'      => 'low',
        'show_names'    => true,
    ) );

    $cmb->add_field( array(
    'name' => 'Related Products',
    'desc' => __( 'Enter Narnoo product IDs for products that appear in this post, seperator with a comma (optional)', 'toursandattractions' ),
    'id'   => $prefix.'products_in_post',
    'type' => 'text_medium',
    ) );

}

/**********************************************
*       -- Review Grouping --
**********************************************/

add_action( 'cmb2_admin_init', 'narnoo_review_product' );
function narnoo_review_product() {

    // Start with an underscore to hide fields from custom fields list
    $prefix = 'narnoo_';

    /*
     * Initiate the metabox
     */
    $cmb = new_cmb2_box( array(
        'id'            => 'noo_review_product',
        'title'         => __( 'Product Reviews', 'toursandattractions' ),
        'object_types'  => array( 'narnoo_product' ), // Post type
        'priority'      => 'low',
        'show_names'    => true,
    ) );

    $group_field_id = $cmb->add_field( array(
        'id'          => 'noo_review_product_repeat_group',
        'type'        => 'group',
        'description' => __( 'Create product reviews from customers', 'toursandattractions' ),
        'options'     => array(
            'group_title'       => __( 'Review {#}', 'toursandattractions' ), // since version 1.1.4, {#} gets replaced by row number
            'add_button'        => __( 'Add Another Review', 'toursandattractions' ),
            'remove_button'     => __( 'Remove Review', 'toursandattractions' ),
            'sortable'          => true,
            ),
    ) );

    $cmb->add_group_field( $group_field_id, array(
    'name' => 'Enter Customer Name',
    'id'   => $prefix.'_review_name',
    'type' => 'text',
    ) );

    $cmb->add_group_field( $group_field_id, array(
    'name' => 'Enter Review Title',
    'id'   => $prefix.'_review_title',
    'type' => 'text',
    ) );

    $cmb->add_group_field( $group_field_id, array(
    'name' => 'Entry Date',
    'id'   => $prefix.'_review_date',
    'type' => 'text_date',
    ) );

    $cmb->add_group_field( $group_field_id, array(
    'name' => 'Enter Customer Rating',
    'desc' => 'Enter a whole value between 1 to 5',
    'id'   => $prefix.'_review_rating',
    'type' => 'text_small',
    ) );

    $cmb->add_group_field( $group_field_id, array(
    'name' => 'Description',
    'description' => 'Write a short description for this entry',
    'id'   => $prefix.'_review_description',
    'type' => 'textarea_small',
) );

}
