<?php


function cpt_destinations_init() {

register_post_type(
	'destinations',
	array(
		'label' => 'Destinations',
		'labels' => array(
			'singular_name' => 'Destination',
		),
		'hierarchical' => true,
		'description' => 'Used to add destinations to the website',
		'public' => true,
		'exclude_from_search' => true,
		'has_archive' => true,
		'publicly_queryable' => true,
		'show_ui' => true,
		'menu_icon'	=> 'dashicons-admin-site-alt2',
		'menu_position'	=> 15,
		'show_in_nav_menus'	=> TRUE,
		'show_in_admin_bar' => true,
		'supports' => array( 'title', 'excerpt', 'thumbnail', 'editor', 'author', 'revisions', 'page-attributes' ),
	)
);

}
add_action( 'init', 'cpt_destinations_init' );

function cpt_testimonals_init() {

register_post_type(
	'testimonial',
	array(
		'label' => 'Testimonials',
		'labels' => array(
			'singular_name' => 'Testimonial',
		),
		'hierarchical' => true,
		'description' => 'Used to add testimonials to the website',
		'public' => true,
		'exclude_from_search' => true,
		'has_archive' => true,
		'publicly_queryable' => true,
		'show_ui' => true,
		'menu_icon'	=> 'dashicons-testimonial',
		'menu_position'	=> 16,
		'show_in_nav_menus'	=> TRUE,
		'show_in_admin_bar' => true,
		'supports' => array( 'title', 'thumbnail', 'editor', 'author', 'revisions', 'page-attributes' ),
	)
);

}
add_action( 'init', 'cpt_testimonals_init' );

function cpt_highlights_init() {

register_post_type(
	'highlight',
	array(
		'label' => 'Highlights',
		'labels' => array(
			'singular_name' => 'highlight',
		),
		'hierarchical' => true,
		'description' => 'Used to add service highlights',
		'public' => true,
		'exclude_from_search' => true,
		'has_archive' => true,
		'publicly_queryable' => true,
		'show_ui' => true,
		'menu_icon'	=> 'dashicons-awards',
		'menu_position'	=> 17,
		'show_in_nav_menus'	=> TRUE,
		'show_in_admin_bar' => true,
		'supports' => array( 'title', 'excerpt', 'thumbnail', 'editor', 'author', 'revisions', 'page-attributes' ),
	)
);

}
add_action( 'init', 'cpt_highlights_init' );

?>
