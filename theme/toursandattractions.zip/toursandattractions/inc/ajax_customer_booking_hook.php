<?php // used here only for enabling syntax highlighting. Leave this out if it's already included in your plugin file.

global $post;
// define the actions for the two hooks created, first for logged in users and the next for logged out users
add_action("wp_ajax_noo_booking_list", "noo_booking_list");
add_action("wp_ajax_nopriv_noo_booking_list", "noo_booking_list");

// define the function to be fired for logged in users
function noo_booking_list() {

   // nonce check for an extra layer of security, the function will exit if it fails
   if ( !wp_verify_nonce( $_REQUEST['nonce'], "noo_ajax_booking_nonce")) {
      //die();
     $result['type']   = 'success';
     $result['output'] = ' <div class="col-xl-12"><div class="alert alert-info">No bookings found nonce</div></div>';
   }else{ 

    $bookingDetailnonce   = wp_create_nonce("noo_ajax_booking_details_nonce");
    $bookingDetaillink    = admin_url('admin-ajax.php?action=noo_booking_detail&nonce='.$bookingDetailnonce);

    //Update these to profile data
    $data['email']    = 'wellzie.james@gmail.com';
    $data['lastName'] = 'Wells';


    $request = Narnoo_Distributor_Helper::init_api('new');
    //$cache      = Narnoo_Distributor_Helper::init_noo_cache();
    

    if ( ! is_null( $request ) ) {
      try {
            
            $list     = $request->searchReports( $data );//$request->getReports();
           
            $reports  = $list->data;


        if ( ! is_array( $reports ) ) {
          throw new Exception( sprintf( __( "Error retrieving operators. Unexpected format in response page #%d.", NARNOO_DISTRIBUTOR_I18N_DOMAIN ), $current_page ) );
        }

      } catch ( Exception $ex ) {
         $result['type']   = 'success';
         $result['output'] = $ex;
         $result = json_encode($result);
         echo $result;
         die();
      }


    }
    $html = "";
    $html .= '<div class="dashboard-title">
                <h4>bookings</h4>
            </div>';
    //LOOP through them
    foreach ($reports as $item) {

      if(ucfirst( $item->status ) == 'Confirmed'){
        $badge = 'badge-info';
      }elseif(ucfirst( $item->status ) == 'Warning'){
        $badge = 'badge-warning';
      }else{
        $badge = 'badge-danger';
      }

      $html .= '
                <div class="dashboard-detail">
                <div class="booking-box">
                    <div class="date-box">
                        <span class="day">'.date( 'D', strtotime($item->dateCreated) ).'</span>
                        <span class="date">'.date( 'd', strtotime($item->dateCreated) ).'</span>
                        <span class="month">'.date( 'M', strtotime($item->dateCreated) ).'</span>
                        <span class="year">'.date( 'Y', strtotime($item->dateCreated) ).'</span>
                    </div>
                    <div class="detail-middle">
                        <div class="media">
                            <div class="media-body">
                                <h6 class="media-heading">'.$item->customerFirstName.' '. $item->customerLastName .'</h6>
                                <p>amount paid: <span>$'.$item->orderTotal.'</span></p>
                            </div>
                            <div class="media-body">
                                <h6 class="media-heading">ID: '.$item->orderId.'</h6>
                                <span class="badge '.$badge.'">'.$item->status.'</span>
                            </div>
                        </div>
                    </div>
                    <div class="detail-last">
                        <a href="#" class="btn btn-solid cls-booking-details-btn" data-nonce="'.$bookingDetailnonce.'" data-order-id="'.$item->orderId.'">View</a>
                    </div>
                </div>
            </div>';
           
    }


    $result['type']   = 'success';
    $result['output'] = $html;

  }

   
   // Check if action was fired via Ajax call. If yes, JS code will be triggered, else the user is redirected to the post page
   if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
      $result = json_encode($result);
      echo $result;
   }
   // don't forget to end your scripts with a die() function - very important
   die();
}


// define the actions for the two hooks created, first for logged in users and the next for logged out users
add_action("wp_ajax_noo_booking_detail", "noo_booking_detail");
add_action("wp_ajax_nopriv_noo_booking_detail", "noo_booking_detail");

function noo_booking_detail() {

   // nonce check for an extra layer of security, the function will exit if it fails
   if ( !wp_verify_nonce( $_REQUEST['nonce'], "noo_ajax_booking_details_nonce")) {
      //die();
     $result['type']   = 'success';
     $result['output'] = ' <div class="col-xl-12"><div class="alert alert-info">No bookings found nonce</div></div>';

   }else{ 


    $bookingId = $_REQUEST['booking'];

    $request = Narnoo_Distributor_Helper::init_api('new');
    //$cache      = Narnoo_Distributor_Helper::init_noo_cache();
    

    if ( ! is_null( $request ) ) {
      try {
            
            $list     = $request->getReportDetails( $bookingId );//$request->getReports();
            $reports  = $list->data;

      } catch ( Exception $ex ) {
         $result['type']   = 'success';
         $result['output'] = $ex;
         $result = json_encode($result);
         echo $result;
         die();
      }

    }
    //Get bookingData information
    $order   = $reports->orderData;
    $booking = $reports->bookingData;
    

    $html = "";
    //$html ='<pre>'.json_encode( $reports ).'</pre>'; check that booking is confirmed..
    $html .= '<!-- section start -->
    <section class="bg-inner section-b-space success-section" style="background-color:#FFFFFF">
        <div class="container">
            <div class="row success-detail mt-0">
                <div class="col">
                    <h2>Booking '.ucfirst($reports->status).' !</h2>
                    <p>thank you for you booking. we have processed this booking. your booking ID is
                        <strong>"'.$reports->orderId.'"</strong>, you will get an email voucher shortly!</p>
                </div>
            </div>
        </div>
    </section>
    <!-- section End -->';
    $html .= '<div class="container">
    <div class="row">';
    $html .= '<div class="col-lg-12 booking-order">
    <div class="summery-box">
        <h2>booking summery</h2>';

        $html .= '<div class="hotel-section">
            <div class="hotel-detail" style="margin-left:0px">';
            foreach ($booking->product as $pro => $it) {
                $html .= '<h6>'.$it->productName.'</h6>';
            }
            
              
        $html .= '</div>';

    
        foreach ($order->products as $product => $item) {
            
        $html .= '</div>
        <div class="summery-section">
            <div class="box">
                <div class="left">
                    <div class="down">
                        <h6>Booking Date</h6>
                        <h5>'.date('d M Y', strtotime( $item->bookingDate) ).'</h5>
                    </div>
                </div>
            </div>
        </div>';

        foreach ($item->option as $opt => $op) {
            $html .= '<div class="summery-section"><h6 class="mb-0">'.$op->quantity.' x '.$op->label.' @ price: $'.number_format($op->price, 2, ".", ",").'</h6></div>';
        }
        if( !empty($item->pickUp->label) ){
            $html .= '<div class="summery-section"><h6 class="mb-0">Pickup Information: '.$item->pickUp->label.'</h6></div>';
        }
       
        } //loop through products

        $html .= '<div class="summery-section">
        <div class="summery-section">
            <div class="payment-details">
                <table>
                    <tbody>
                        <tr>
                            <td>booking amount</td>
                            <td class="amount">$'.$reports->orderTotal.'</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>';
    $html .= '</div>
    </div>';//row - container

    $result['type']   = 'success';
    $result['output'] = $html;

  }

  // Check if action was fired via Ajax call. If yes, JS code will be triggered, else the user is redirected to the post page
   if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
      $result = json_encode($result);
      echo $result;
   }
   // don't forget to end your scripts with a die() function - very important
   die();

}




