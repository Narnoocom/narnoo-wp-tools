<?php
/**
 * Setup suggested plugin system.
 *
 * Include the Tours_And_Attractions_Plugin_Manager class and add
 * an interface for users to to manage suggested
 * plugins.
 *
 * @since x.x.x
 *
 * @see  Tours_And_Attractions_Plugin_Manager
 * @link http://mypluginmanager.com
 */
function toursandattractions_plugin_manager() {

	if ( ! is_admin() ) {
		return;
	}

	/**
	 * Include plugin manager class.
	 *
	 * No other includes are needed. The Tours_And_Attractions_Plugin_Manager
	 * class will handle including any other files needed.
	 *
	 * If you want to move the "plugin-manager" directory to
	 * a different location within your theme, that's totally
	 * fine; just make sure you adjust this include path to
	 * the plugin manager class accordingly.
	 */
	require_once( get_template_directory() . '/inc/plugin-manager/class-tours-and-attractions-plugin-manager.php' );

	/*
	 * Setup suggested plugins.
	 *
	 * It's a good idea to have a filter applied to this so your
	 * loyal users running child themes have a way to easily modify
	 * which plugins show as suggested for the site they're setting
	 * up for a client.
	 */
	$plugins = apply_filters( 'toursandattractions_plugins', array(
		array(
			'name'    => 'Narnoo Distributor Plugin',
			'slug'    => 'narnoo-distributor',
			'version' => '2.5+',
			'url'     => 'https://github.com',
		),
		array(
			'name'    => 'Narnoo Widget',
			'slug'    => 'narnoo_widget',
			'version' => '2.0.0',
			'url'     => 'https://github.com/Narnoocom/Narnoo-Widget-WordPress-Plugin',
		),
		array(
			'name'    => 'Real Simple SSL',
			'slug'    => 'real-simple-ssl',
			'version' => '3.3.4',
		),
		array(
			'name'    => 'Yoast SEO',
			'slug'    => 'wordpress-seo',
			'version' => '14.7',
		),
		array(
			'name'    => 'Wordfence Security',
			'slug'    => 'Wordfence',
			'version' => '7.4+',
		),
		array(
			'name'    => 'Cookie Notice',
			'slug'    => 'cookie-notice',
			'version' => '1.3+',
		)
	));

	/*
	 * Setup optional arguments for plugin manager interface.
	 *
	 * See the set_args() method of the Tours_And_Attractions_Plugin_Manager
	 * class for full documentation on what you can pass in here.
	 */
	$args = array(
		'page_title' => __( 'Required and Suggested Plugins', 'toursandattractions' ),
		'menu_slug'  => 'toursandattractions-suggested-plugins',
	);

	/*
	 * Create plugin manager object, passing in the suggested
	 * plugins and optional arguments.
	 */
	$manager = new Tours_And_Attractions_Plugin_Manager( $plugins, $args );

}
add_action( 'after_setup_theme', 'toursandattractions_plugin_manager' );

?>