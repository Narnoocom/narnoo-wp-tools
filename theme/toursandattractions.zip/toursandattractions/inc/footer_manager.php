<?php
/**
 * Functions which manages the w
 *
 * @package toursandattractions
 */

function register_noo_widget_areas() {

        register_sidebar( array(
            'name'          => 'Footer area one',
            'id'            => 'noo_footer_area_one',
            'description'   => 'This widget is the first widget that would show up in the footer 4 column set up',
            'before_widget' => '<div class="footer-area footer-area-one">',
            'after_widget'  => '</div>',
            'before_title'  => '<div class="footer-title"><h5>',
            'after_title'   => '</h5></div>',
        ));

        register_sidebar( array(
            'name'          => 'Footer area two',
            'id'            => 'noo_footer_area_two',
            'description'   => 'This widget is the second widget that would show up in the footer 4 column set up',
            'before_widget' => '<div class="footer-area footer-area-two">',
            'after_widget'  => '</div>',
            'before_title'  => '<div class="footer-title"><h5>',
            'after_title'   => '</h5></div>',
        ));

        register_sidebar( array(
            'name'          => 'Footer area three',
            'id'            => 'noo_footer_area_three',
            'description'   => 'This widget is the thrid widget that would show up in the footer 4 column set up',
            'before_widget' => '<div class="footer-area footer-area-three">',
            'after_widget'  => '</div>',
            'before_title'  => '<div class="footer-title"><h5>',
            'after_title'   => '</h5></div>',
        ));

        register_sidebar( array(
            'name'          => 'Footer area four',
            'id'            => 'noo_footer_area_four',
            'description'   => 'This widget is the forth widget that would show up in the footer 4 column set up',
            'before_widget' => '<div class="footer-area footer-area-three">',
            'after_widget'  => '</div>',
            'before_title'  => '<div class="footer-title"><h5>',
            'after_title'   => '</h5></div>',
        ));

    }
add_action( 'widgets_init', 'register_noo_widget_areas' );