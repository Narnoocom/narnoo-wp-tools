<?php
/**
 * Narnoo Operator - Categories table.
 **/
class Narnoo_Subscribers_Table extends WP_List_Table {


	function get_current_page_data() {
		global $wpdb;

		$data = array( 'total_pages' => 1, 'items' => array() );

		$sql 	 = "SELECT * FROM noo_email_list";
		$results = $wpdb->get_results( $sql );

		if(!empty($results)){
			$data['total_pages'] = max( 1, intval( 1 ) );

			foreach ($results as $sub) {
				$item['date'] 				= date( 'd  M  Y', strtotime( $sub->date_created) ) ;
				$item['email'] 				= $sub->email;
				$data['items'][] 			= $item;
			}



		}else{
			//Throw error

			

			
			$data = NULL;
		}
		//Call DB 


		return $data;
	}



	function get_columns(){
	  $columns = array(
	    'date' 		=> 'Date Created',
	    'email'     => 'Subscriber\'s Email Address'
	  );
	  return $columns;
	}

	function column_default( $item, $column_name ) {
	  switch( $column_name ) { 
	    case 'date':
	    case 'email':
	     return $item[ $column_name ];
	    default:
	      return print_r( $item, true ) ; //Show the whole array for troubleshooting purposes
	  }
	}

    /**
	 * Process any actions (displaying forms for the actions as well).
	 * If the table SHOULD be rendered after processing (or no processing occurs), prepares the data for display and returns true. 
	 * Otherwise, returns false.
	 **/
	function prepare_items() {
		  $columns = $this->get_columns();
		  $hidden = array();
		  $sortable = array();
		  $this->_column_headers = array($columns, $hidden, $sortable);
		  $data = $this->get_current_page_data();

		  if(empty($data)){

		  	echo '<div class="notice notice-warning is-dismissible"><p>There are currently no subscribed users</p></div>';
		 	$this->items = NULL;
		 	$this->set_pagination_args( array(
				'total_items'	=> 0,
				'total_pages'	=> 0
			) ); 

		  }else{
		  	$this->items = $data['items'];
		  	$this->set_pagination_args( array(
				'total_items'	=> count( $data['items'] ),
				'total_pages'	=> $data['total_pages']
			) ); 
		  }
		  
		}
	
	/**
	 * Add screen options for images page.
	 **/
	static function add_screen_options() {
		global $narnoo_distributor_operator_images_table;
		$narnoo_distributor_operator_images_table = new Narnoo_Distributor_Operator_Images_Table();
	}
    



}//class

if ( is_admin() ) {

function subscriber_add_menu_items(){
    add_menu_page( 'Subscribers', 'Subscriber List', 'activate_plugins', 'narnoo-subscribers', 'subscriber_render_list_page', 'dashicons-groups', 15 );
}
add_action( 'admin_menu', 'subscriber_add_menu_items' );

function subscriber_render_list_page(){
  $myListTable = new Narnoo_Subscribers_Table();
  $subNonce          = wp_create_nonce("noo_email_subscribe_nonce_dl");
  $subLink           = admin_url('admin-ajax.php?action=noo_email_subscribe_dl&nonce='.$subNonce);
  ?>
  <div class="wrap"><h2>Email List <a id="subscriber-list-dl" class="add-new-h2" data-nonce="<?php echo $subNonce; ?>" href="<?php echo $subLink; ?>"><?php _e( "Email A CSV file", 'toursandattractions' ); ?></a></h2>
  <?php  
  $myListTable->prepare_items(); 
  $myListTable->display(); 
  echo '</div>'; 
}

function noo_Subcriber_dl(){

    wp_register_script( 'noo-email-subscription-dl', get_template_directory_uri().'/js/ajax_email_subscription.js', 'jquery', NULL, TRUE );
    wp_localize_script( 'noo-email-subscription-dl', 'myAjax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));  

    wp_enqueue_script( 'noo-email-subscription-dl' );
    
}
add_action( 'admin_enqueue_scripts', 'noo_Subcriber_dl' );

add_action('wp_ajax_noo_email_subscribe_dl', 'noo_email_subscribe_dl');

// define the function to be fired for logged in users
function noo_email_subscribe_dl() {
   global $wpdb;
   // nonce check for an extra layer of security, the function will exit if it fails
  if ( !wp_verify_nonce( $_REQUEST['nonce'], "noo_email_subscribe_nonce_dl")) {
      die();
   } 

   
    $sql 	 = "SELECT * FROM noo_email_list";
	$results = $wpdb->get_results( $sql , ARRAY_A );

	fputcsv( $output, array('Date', 'Email'));
	if(!empty($results)){

		$filename 	= 'subscribers';
    	$date 		= date("Y-m-d H:i:s");
    	$output 	= fopen('php://output', 'w');
    	foreach ( $results as $key => $value ) {
	        $modified_values = array(
	                        $value['date_created'],
	                        $value['email']
	        );
	        fputcsv( $output, $modified_values );
    	}
        /*header("Pragma: public");
	    header("Expires: 0");
	    header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
	    header("Cache-Control: private", false);
	    header('Content-Type: text/csv; charset=utf-8');
	    header("Content-Disposition: attachment; filename=\"" . $filename . " " . $date . ".csv\";" );
	    header("Content-Transfer-Encoding: binary");*/
	   	
	   	//$result['type']   = 'success';
	    $body = "Please find attached your subscriber CSV file";
	   	send_csv_mail( $output, $body, get_option('admin_email'), NULL, get_option('admin_email')  );
	   	
	   	$result['type']   = 'success';
        $text = "CSV file has been generated and sent to the blog admin email address";
        $result['output'] = $text;
	   
    }else{
    	$result['type']   = 'error';
        $text = "Issue generating CSV file";
        $result['output'] = $text;
    }

   // Check if action was fired via Ajax call. If yes, JS code will be triggered, else the user is redirected to the post page
   if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
      $result = json_encode($result);
      echo $result;
   }
   
   die();
}


function send_csv_mail($csvData, $body, $to = 'email@example.com', $subject = 'Subscriber List', $from = 'noreply@carlofontanos.com') {

    // This will provide plenty adequate entropy
    $multipartSep = '-----'.md5(time()).'-----';

    // Arrays are much more readable
    $headers = array(
        "From: $from",
        "Reply-To: $from",
        "Content-Type: multipart/mixed; boundary=".$multipartSep.""
    );

    // Make the attachment
    $attachment = chunk_split(base64_encode($csvData));

    // Make the body of the message
    $body = "--$multipartSep\r\n"
        . "Content-Type: text/plain; charset=ISO-8859-1; format=flowed\r\n"
        . "Content-Transfer-Encoding: 7bit\r\n"
        . "\r\n"
        . "$body\r\n"
        . "--$multipartSep\r\n"
        . "Content-Type: text/csv\r\n"
        . "Content-Transfer-Encoding: base64\r\n"
        . "Content-Disposition: attachment; filename=\"Website-Report-\" ". date("F-j-Y") .".csv\r\n"
        . "\r\n"
        . $attachment."\r\n"
        . "--$multipartSep--";

    // Send the email, return the result
    return @mail($to, $subject, $body, implode("\r\n", $headers));

}


}




