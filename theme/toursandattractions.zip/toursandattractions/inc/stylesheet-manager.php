<?php
/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package toursandattractions
 */

/**
 * Imports the main CSS files.
 *
 */
function noo_loadStyles(){
wp_enqueue_style( 'animate', get_template_directory_uri().'/assets/css/animate.css' ,  'bootstrap');
wp_enqueue_style( 'font-awesome', get_template_directory_uri().'/assets/css/font-awesome.css' ,  'bootstrap');
wp_enqueue_style( 'slick', get_template_directory_uri().'/assets/css/slick.css' , 'bootstrap' );
wp_enqueue_style( 'slick-theme', get_template_directory_uri().'/assets/css/slick-theme.css', 'slick' );
wp_enqueue_style( 'bootstrap', get_template_directory_uri().'/assets/css/bootstrap.css' );
wp_enqueue_style( 'colour', get_template_directory_uri().'/assets/css/color1.css' , 'bootstrap' );
wp_enqueue_style( 'toast', get_template_directory_uri().'/assets/css/jquery.toast.min.css' , 'bootstrap' );
}
// Add the functions to WP loading list.
add_action( 'wp_enqueue_scripts', 'noo_loadStyles' );