<?php
/**
 * The template for the home page.
 *
 * Template Name: Home Page
 *
 * @package toursandattractions
 */
function noo_loadRippleScript(){

    wp_register_script( 'noo-email-subscription', get_template_directory_uri().'/js/ajax_email_subscription.js', 'jquery', NULL, TRUE );
    wp_localize_script( 'noo-email-subscription', 'myAjax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));  

    wp_enqueue_script("jquery");
    wp_enqueue_script( 'ripples', get_template_directory_uri().'/assets/js/jquery.ripples.js' ,  'jquery' , NULL , TRUE);
    wp_enqueue_script( 'cloud', get_template_directory_uri().'/assets/js/jqcloud.min.js' ,  'jquery' , NULL , TRUE);
    wp_enqueue_script( 'ytBg', get_template_directory_uri().'/assets/js/jquery.youtube-background.js' ,  'jquery' , NULL , TRUE);
    wp_enqueue_script( 'isotope', get_template_directory_uri().'/assets/js/isotope.min.js' ,  'jquery' , NULL , TRUE);
    wp_enqueue_script( 'noo-email-subscription' );
}
add_action( 'wp_enqueue_scripts', 'noo_loadRippleScript' );

function noo_loadCloudStyles(){
wp_enqueue_style( 'cloud', get_template_directory_uri().'/assets/css/jqcloud.min.css' ,  'bootstrap');
}
// Add the functions to WP loading list.
add_action( 'wp_enqueue_scripts', 'noo_loadCloudStyles' );

get_header();
?>

	<main id="primary" class="site-main">

		<?php
		while ( have_posts() ) :
			the_post();

			get_template_part( 'template-parts/content', 'home' );

		endwhile; // End of the loop.
		?>

	</main><!-- #main -->

</div><!-- #page header.php line 25 -->

<?php //wp_footer();
get_footer()
?>
<script>
        jQuery(document).ready(function () {
            try {
                jQuery('.ripple-effect').ripples({
                    resolution: 256,
                    perturbance: 0.005
                });
            } catch (e) {
                jQuery('.error').show().text(e);
            }
        });
        
</script>
</body>
</html>
</footer>
