<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package toursandattractions
 */

/*
if 1 active: class = 6 (min size)
if 2 active: class = 6
if 3 active: class = 4
if 4 active: class = 3
if (   ! is_active_sidebar( 'noo_footer_area_one'  )
        && ! is_active_sidebar( 'noo_footer_area_two' )
        && ! is_active_sidebar( 'noo_footer_area_three'  )
        && ! is_active_sidebar( 'noo_footer_area_four' )
    )
*/
?>
	
	<!-- footer start -->
    <footer>
    <?php
    if (   is_active_sidebar( 'noo_footer_area_one'  )
        && is_active_sidebar( 'noo_footer_area_two' )
        && is_active_sidebar( 'noo_footer_area_three'  )
        && is_active_sidebar( 'noo_footer_area_four' )
    ){ ?>
        <div class="footer section-b-space section-t-space">
            <div class="container">
                <div class="row order-row">
                    <div class="col-xl-3 col-md-6 order-cls">
                        <div class="footer-content">
                        <?php dynamic_sidebar( 'noo_footer_area_one' ); ?>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-6">
                        <div class="footer-content">
                        <?php dynamic_sidebar( 'noo_footer_area_two' ); ?>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-6">
                        <div class="footer-content">
                        <?php dynamic_sidebar( 'noo_footer_area_three' ); ?>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-6">
                        <div class="footer-content">
                        <?php dynamic_sidebar( 'noo_footer_area_four' ); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    <?php 
    }elseif(  is_active_sidebar( 'noo_footer_area_one'  )
        && is_active_sidebar( 'noo_footer_area_two' )
        && is_active_sidebar( 'noo_footer_area_three'  )
        && !is_active_sidebar( 'noo_footer_area_four' )
    ){ ?>  

    <div class="footer section-b-space section-t-space">
            <div class="container">
                <div class="row order-row">
                    <div class="col-xl-4 col-md-4 order-cls">
                        <div class="footer-content">
                        <?php dynamic_sidebar( 'noo_footer_area_one' ); ?>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-4">
                        <div class="footer-content">
                        <?php dynamic_sidebar( 'noo_footer_area_two' ); ?>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-4">
                        <div class="footer-content">
                        <?php dynamic_sidebar( 'noo_footer_area_three' ); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    <?php 
    }elseif(
           is_active_sidebar( 'noo_footer_area_one'  )
        && is_active_sidebar( 'noo_footer_area_two' )
        && !is_active_sidebar( 'noo_footer_area_three'  )
        && !is_active_sidebar( 'noo_footer_area_four' )
    ){  ?>
    <div class="footer section-b-space section-t-space">
            <div class="container">
                <div class="row order-row">
                    <div class="col-xl-6 col-md-6 order-cls">
                        <div class="footer-content">
                        <?php dynamic_sidebar( 'noo_footer_area_one' ); ?>
                        </div>
                    </div>
                    <div class="col-xl-6 col-md-6">
                        <div class="footer-content">
                        <?php dynamic_sidebar( 'noo_footer_area_two' ); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    <?php 
    }elseif(
            is_active_sidebar( 'noo_footer_area_one'  )
        && !is_active_sidebar( 'noo_footer_area_two' )
        && !is_active_sidebar( 'noo_footer_area_three'  )
        && !is_active_sidebar( 'noo_footer_area_four' )
    ){ ?>
   
    <div class="footer section-b-space section-t-space">
            <div class="container">
                <div class="row order-row">
                    <div class="col-xl-12 col-md-12 order-cls">
                        <div class="footer-content">
                        <?php dynamic_sidebar( 'noo_footer_area_one' ); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    <?php } ?>
        
    <?php 
        $fb_link        = get_theme_mod( 'noo_facebook_link' );
        $insta_link     = get_theme_mod( 'noo_instagram_link' );
        $youtube_link   = get_theme_mod( 'noo_youtube_link' );
        $twitter_link   = get_theme_mod( 'noo_twitter_link' );
        if(
            !empty($fb_link) 
            || !empty($insta_link)
            || !empty($youtube_link)
            || !empty($twitter_link)
        ){
    ?>
        <div class="sub-footer">
            <div class="container">
                <div class="row ">
                    <div class="col-xl-6 col-md-6 col-sm-12">
                        <div class="footer-social">
                            <ul>
                               <?php (!empty($fb_link)) ?> <li><a href="<?php echo $fb_link; ?>"><i class="fab fa-facebook-f"></i></a></li>
                               <?php (!empty($insta_link)) ?> <li><a href="<?php echo $insta_link; ?>"><i class="fab fa-instagram"></i></a></li>
                               <?php (!empty($twitter_link)) ?> <li><a href="<?php echo $twitter_link; ?>"><i class="fab fa-twitter"></i></a></li>
                               <?php (!empty($youtube_link)) ?> <li><a href="<?php echo $youtube_link; ?>"><i class="fab fa-youtube"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php 
        }
    ?>
    </footer>
    <!-- footer end -->

</div><!-- #page header.php line 25 -->

<?php wp_footer(); ?>

</body>
</html>
