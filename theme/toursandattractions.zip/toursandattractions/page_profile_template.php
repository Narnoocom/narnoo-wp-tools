<?php
/**
 * The template for the home page.
 *
 * Template Name: Member profile page
 *
 * @package toursandattractions
 */

//get the user data:
global $wpdb;

$logged     = get_current_user_id();
if(empty($logged)){
    header( 'Location:' . home_url('/').'login-page' );
} 

/***
*  UPDATE THE PROFILE INFORMATION
***/

if ( 'POST' == $_SERVER['REQUEST_METHOD'] ) {

//first_name
if(!empty($_POST['first_name'])){
    $up_user_array['first_name'] = esc_attr( $_POST['first_name'] );
}   
//last_name
if(!empty($_POST['last_name'])){
    $up_user_array['last_name'] = esc_attr( $_POST['last_name'] );
}  
//display_name
if(!empty($_POST['display_name'])){
    $up_user_array['display_name'] = esc_attr( $_POST['display_name'] );
}

//password
if(!empty( $_POST['new_password'] )){

        // Check password is valid  
        if(0 === preg_match("/.{6,}/", $_POST['new_password']))
        {  
         $passCheck = false; 

        }else{
          $passCheck = true;  
        }  

        if ( !empty($_POST['new_password'] ) && !empty( $_POST['confirm_password'] ) && !empty($passCheck) ) {
            if ( $_POST['new_password'] == $_POST['confirm_password'] ){
                $up_user_array['user_pass'] = esc_attr( $_POST['new_password'] );
            }
        }else{
             header( 'Location:' . home_url('/').'profile?e=true' );
        }

}


if(!empty($up_user_array)){
    $up_user_array['ID'] = $logged;
    wp_update_user( $up_user_array );
    wp_redirect( get_permalink() );
    exit;
}  

}





function noo_loadWishlistScript(){

    wp_register_script( 'noo-product-wishlist', get_template_directory_uri().'/js/ajax_product_search.js', array('jquery','script','lazy'), NULL, TRUE );
    wp_localize_script( 'noo-product-wishlist', 'myAjax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));

     wp_register_script( 'noo-customer-booking', get_template_directory_uri().'/js/ajax_admin_bookings.js', array('jquery'), NULL, TRUE );

    wp_enqueue_script("jquery");
    wp_enqueue_script( 'noo-product-wishlist' );
    wp_enqueue_script( 'noo-customer-booking' );
    
}
add_action( 'wp_enqueue_scripts', 'noo_loadWishlistScript' );

global $current_user, $wp_roles;

if( !is_user_logged_in() ){
     header( 'Location:' . home_url('/').'login-page' );
}

get_header();
$thumbnail = get_the_post_thumbnail_url(NULL, 'page-header');
?>

<!-- breadcrumb start -->
    <section class="breadcrumb-section effect-cls pt-0">
        <img src="<?php echo $thumbnail;?>" class="bg-img img-fluid blur-up lazyload" alt="">
        <div class="breadcrumb-content pt-0">
            <div>
                <h2><?php echo get_the_title(); ?></h2>
                <nav aria-label="breadcrumb" class="theme-breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo get_the_title(); ?></li>
                    </ol>
                </nav>
            </div>
        </div>
    </section>
    <!-- breadcrumb end -->

	<main id="primary" class="site-main">

		<?php
		while ( have_posts() ) :
			the_post();

			get_template_part( 'template-parts/membership', 'profile' );

		endwhile; // End of the loop.
		?>

	</main><!-- #main -->

<?php
get_footer();
?>
