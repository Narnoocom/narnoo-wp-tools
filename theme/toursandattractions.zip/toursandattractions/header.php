<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package toursandattractions
 */
//http://localhost:8888/narnoo-tours/wp-content/themes/toursandattractions/assets/images/icon/footer-logo.png
$custom_logo_id = get_theme_mod( 'custom_logo' );
$image = wp_get_attachment_image_src( $custom_logo_id , 'full' );
$siteUrl = get_site_url();

$logo  = !(empty($image[0])) ? $image[0] : $siteUrl."/wp-content/themes/toursandattractions/assets/images/icon/footer-logo.png";


//User management
global $siteuserId;
if( is_user_logged_in() ){
    //var_dump("Logged In");
    $siteuserId = get_current_user_id();
    $logoutLink = wp_logout_url( $siteUrl );
}else{
    $loginLink = $siteUrl.'/login-page';
};

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div id="page" class="site">
	<!--<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'toursandattractions' ); ?></a> -->

	<!-- pre-loader start -->
    <div class="loader-wrapper img-gif">
        <img src="<?php echo get_stylesheet_directory_uri();?>/assets/images/loader.gif" alt="">
    </div>
    <!-- pre-loader end -->


    <!-- header start -->
    <header class="overlay-black">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="menu">
                        <div class="brand-logo">
                            <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
                            <?php 
                            
                            ?>
                                <img src="<?php echo $logo; ?>" alt="<?php bloginfo( 'name' ); ?>" class="img-fluid blur-up lazyload">
                            </a>
                        </div>
                        <nav>
                            <div class="main-navbar">
                                <div id="mainnav">
                                    <div class="toggle-nav"><i class="fa fa-bars sidebar-bar"></i></div>
                                    <div class="menu-overlay"></div>
                                    
                                    <?php wp_nav_menu( 
                                        array(
                                            'menu'           => 'Primary',
                                            'menu_class'     => 'nav-menu',
                                            'walker'         => new Noo_Nav_Menu(),
                                            ) 
                                    );  ?>
                                    
                                </div>
                            </div>
                        </nav>
                        <ul class="header-right">
                            

                            <?php if(empty($logoutLink)){ ?>
                            <li class="user user-light bg_dark">
                                <a href="<?php echo $loginLink; ?>" title="Sign In">
                                    <i class="fas fa-sign-in-alt"></i>
                                </a>
                            </li>
                            <?php }else{ ?>
                            <li class="user user-light bg_dark">
                                <a href="<?php echo home_url(); ?>/profile/" title="Profile">
                                    <i class="fas fa-user"></i>
                                </a>
                            </li>
                            <li class="user user-light bg_dark">
                                <a href="<?php echo $logoutLink; ?>">
                                    <i class="fas fa-sign-out-alt"></i>
                                </a>
                            </li>
                            <?php } ?>
                        
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!--  header end -->
