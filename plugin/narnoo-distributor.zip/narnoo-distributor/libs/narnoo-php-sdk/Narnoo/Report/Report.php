<?php

namespace Narnoo\Report;
/**
*
*/
class Report extends \Narnoo\Base
{
    /**************************************************
    *
    *                --- Reports ---
    *
    **************************************************/
    
    /**
    *   @title: Get Reports
    *   @date: 25.06.2018
    *   @param: int business ID [optional]
    *   @result: JSON
    */
    public function getReports( $value = NULL)
    {   
        
        try{


            $url = "/report/agent_booking_list";
            if( !empty($value) ){
                $url .= "/".$value;
            }else{
                $url .= "/live";
            }
            $response = $this->callNarnooAPI("get",$url);

            return $response;
        } catch (Exception $e) {
            $response = array("error" => $e->getMessage());
            return $response;
        }
    }

     /**
    *   @title: Get Reports Details
    *   @date: 25.06.2018
    *   @param: int Reports ID [ required ]
    *   @param: int Reports ID [ required if calling an Reports product ID]
    *   @result: JSON
    */
    public function getReportDetails( $id )
    {   
        
        try{
            $url = "/report/agent_booking_details/".$id;

            $response = $this->callNarnooAPI("get",$url);
            return $response;
        } catch (Exception $e) {
            $response = array("error" => $e->getMessage());
            return $response;
        }
    }

    /*
    *
    *   {"email":"Narnoo","lastName":"Doe"}
    */
    public function searchReports($value)
    {
        try{
            $url = "/report/agent_booking_search/";
            $response = $this->callNarnooAPI("post",$url,NULL,$value);
            return $response;
        } catch (Exception $e) {
            $response = array("error" => $e->getMessage());
            return $response;
        }
    }


    
    /**************************************************
    *
    *                --- .Products ---
    *
    **************************************************/



}

?>