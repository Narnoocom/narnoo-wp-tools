<?php
/**
 * Extract the shortcode data
 */
extract( shortcode_atts( array(
    'lastName'  => '',
), $atts ) );
    
   //We need to get the widget settings from the database
   $option = get_option( 'narnoo_widget_settings' );
   //If the access keys don't exist we have to return false
   if(empty($option['widget_access_key'])){
       $msg = "<div id=\"noo-availability\">";
       $msg .= "<p>No Narnoo API Access key has been provided</p>";
       $msg .= "</div>";
       echo $msg;
       return false;
   }

    //Get the access key from the stored local db
    $access_key = $option['widget_access_key'];
    

   /**
     * Add the script to the footer of the page to increase page load time.
     */
    $script = '<script src="https://d2amq67wh0wnea.cloudfront.net/manage/css/app.css"></script>';
    add_action( 'wp_footer', function() use( $script ){
        echo $script;
    });

    echo '<link href="https://d2amq67wh0wnea.cloudfront.net/manage/js/app.js" rel="stylesheet" />
    <narnoo-booking-management-widget
    access_key = "'.$access_key.'"
    >
    </narnoo-booking-management-widget>';
?>
